package com.wu.compliance.iwatch.orchestrator.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * We need to define maternal/paternal names in this block
 */


@JsonInclude(JsonInclude.Include.NON_NULL)
public class Name {

	private String title;


	private String firstName;

	private String lastName;

	private String middleName;

	private String nameType;

	private String nameTypeCode;

	private String fullLegalName;

	private String alternateName;

	private String alternateShipToName;


	public String getTitle() {
		return title;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public String getNameType() {
		return nameType;
	}

	public String getNameTypeCode() {
		return nameTypeCode;
	}

	public String getFullLegalName() {
		return fullLegalName;
	}

	public String getAlternateName() {
		return alternateName;
	}

	public String getAlternateShipToName() {
		return alternateShipToName;
	}

	public Name(String title, String firstName, String lastName, String middleName, String nameType, String nameTypeCode, String fullLegalName, String alternateName, String alternateShipToName) {
		this.title = title;
		this.firstName = firstName;
		this.lastName = lastName;
		this.middleName = middleName;
		this.nameType = nameType;
		this.nameTypeCode = nameTypeCode;
		this.fullLegalName = fullLegalName;
		this.alternateName = alternateName;
		this.alternateShipToName = alternateShipToName;
	}

	public Name() {
	}
}
