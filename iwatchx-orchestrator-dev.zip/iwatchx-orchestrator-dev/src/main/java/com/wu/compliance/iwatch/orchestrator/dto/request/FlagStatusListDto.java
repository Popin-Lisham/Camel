package com.wu.compliance.iwatch.orchestrator.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class FlagStatusListDto {
	
	private String  type;
	private String  subType;
	private String  value;
	private String  subStatus;
	private String  expiryDate;
	private AttributesDto  attributes;
	
    public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public AttributesDto getAttributes() {
		return attributes;
	}

	public void setAttributes(AttributesDto attributes) {
		this.attributes = attributes;
	}

@Override
  public String toString() {
    return "FlagStatusListDto [type=" + type + ", subType=" + subType + ", value=" + value + ", subStatus=" + subStatus + ", expiryDate=" + expiryDate + ", attributes="
      + attributes + "]";
  }

}
