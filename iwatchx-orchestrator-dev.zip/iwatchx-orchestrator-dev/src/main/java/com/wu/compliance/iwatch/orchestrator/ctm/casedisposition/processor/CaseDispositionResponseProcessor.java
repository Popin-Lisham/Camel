package com.wu.compliance.iwatch.orchestrator.ctm.casedisposition.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import wu.ei.cis.csc.core.gsi.xsd.gsi.gsitxndecisionresponse_2016_12.GSITxnDecisionResponse20161212;

@Component
public class CaseDispositionResponseProcessor implements Processor {
    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange) throws Exception {
        GSITxnDecisionResponse20161212 gsiTxnDecisionResponse = exchange.getIn().getBody(GSITxnDecisionResponse20161212.class);
        exchange.getIn().setBody(gsiTxnDecisionResponse);
        logger.info("Successfully send Case disposition decision to CTM for caseId  : "+ gsiTxnDecisionResponse.getIWatchCaseID());
    }
}
