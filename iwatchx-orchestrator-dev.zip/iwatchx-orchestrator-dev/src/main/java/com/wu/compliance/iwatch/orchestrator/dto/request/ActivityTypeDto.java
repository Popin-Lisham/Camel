package com.wu.compliance.iwatch.orchestrator.dto.request;

public class ActivityTypeDto {
    private Integer id;

    private String value;

    public void setId(Integer id){
        this.id = id;
    }

    public Integer getId(){
        return id;
    }

    public void setValue(String value){
        this.value = value;
    }

    public String getValue(){
        return value;
    }
}
