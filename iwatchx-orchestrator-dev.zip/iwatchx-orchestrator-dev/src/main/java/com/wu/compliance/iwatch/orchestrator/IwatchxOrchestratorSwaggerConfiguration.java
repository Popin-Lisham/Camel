package com.wu.compliance.iwatch.orchestrator;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.wu.compliance.iwatch")
public class IwatchxOrchestratorSwaggerConfiguration {
}
