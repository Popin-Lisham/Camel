package com.wu.compliance.iwatch.orchestrator.dto.type;

public class Phone extends AbstractPair{
}
