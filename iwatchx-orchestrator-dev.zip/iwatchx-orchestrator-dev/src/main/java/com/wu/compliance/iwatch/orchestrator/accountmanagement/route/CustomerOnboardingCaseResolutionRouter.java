package com.wu.compliance.iwatch.orchestrator.accountmanagement.route;

import java.util.Objects;
import java.util.concurrent.TimeoutException;

import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import org.apache.camel.*;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.builder.ValueBuilder;
import org.apache.camel.component.mock.AssertionClause;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestParamType;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wu.compliance.iwatch.orchestrator.accountmanagement.processor.CustomerOnboardingCaseResolutionExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.accountmanagement.processor.CustomerOnboardingCaseResolutionRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.accountmanagement.processor.CustomerOnboardingCaseResolutionResponseProcessor;
import com.wu.compliance.iwatch.orchestrator.dto.request.PharosCaseResolutionRequestDto;


@Component
public class CustomerOnboardingCaseResolutionRouter extends RouteBuilder{
  Logger logger = LogManager.getLogger(this.getClass());
  private final CustomerOnboardingCaseResolutionRequestProcessor customerOnboardingCaseResolutionRequestProcessor;
  private final CustomerOnboardingCaseResolutionResponseProcessor customerOnboardingCaseResolutionResponseProcessor;
  private final CustomerOnboardingCaseResolutionExceptionProcessor customerOnboardingCaseResolutionExceptionProcessor;
  private final SanitizationProcessor sanitizationProcessor;
  private final XssDataExceptionProcessor xssDataExceptionProcessor;

  public CustomerOnboardingCaseResolutionRouter(CustomerOnboardingCaseResolutionRequestProcessor customerOnboardingCaseResolutionRequestProcessor, CustomerOnboardingCaseResolutionResponseProcessor customerOnboardingCaseResolutionResponseProcessor,
    CustomerOnboardingCaseResolutionExceptionProcessor customerOnboardingCaseResolutionExceptionProcessor,
    SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor) {
    Objects.requireNonNull(customerOnboardingCaseResolutionRequestProcessor, "accountOnboardingRequestProcessor is null");
    Objects.requireNonNull(customerOnboardingCaseResolutionResponseProcessor, "accountOnboardingResponseProcessor is null");
    Objects.requireNonNull(customerOnboardingCaseResolutionExceptionProcessor, "accountOnboardingExceptionProcessor is null");
    Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
    Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");
    this.customerOnboardingCaseResolutionRequestProcessor = customerOnboardingCaseResolutionRequestProcessor;
    this.customerOnboardingCaseResolutionResponseProcessor = customerOnboardingCaseResolutionResponseProcessor;
    this.customerOnboardingCaseResolutionExceptionProcessor = customerOnboardingCaseResolutionExceptionProcessor;
    this.sanitizationProcessor = sanitizationProcessor;
    this.xssDataExceptionProcessor = xssDataExceptionProcessor;
  }

 
  
  @Override
   public void configure() {

       interceptSendToEndpoint("direct:route-customer-onboarding-caseresolution-input")
        .process(sanitizationProcessor);

       onException(Exception.class)
        .handled(true)
        .process(customerOnboardingCaseResolutionExceptionProcessor);

       onException(XssDataException.class)
        .handled(true)
        .process(xssDataExceptionProcessor)
        .marshal().json(JsonLibrary.Jackson);

       onException(HttpHostConnectException.class, TimeoutException.class)
        .handled(true)
        .maximumRedeliveries("{{app.context.retry.count}}").redeliveryDelay("{{app.context.retry.delay}}")
        .retryAttemptedLogLevel(LoggingLevel.WARN)
        .process(customerOnboardingCaseResolutionExceptionProcessor);
       
       rest().tag("Post Customer Onboarding Caseresolution")
        .description("Customer Onboarding Caseresolution from Pharos")
        .post("{{app.context.mule.customer.onboarding.caseresolution.post}}")
           .produces("application/json")
           .consumes("application/json")
        .type(PharosCaseResolutionRequestDto.class)
        .param().name("x-wu-externalRefId").type(RestParamType.header).dataType("string").description("External Ref Id.").required(false).endParam()
        .param().name("Authorization").type(RestParamType.header).dataType("string").description("AuthToken").required(false).endParam()
        .param().name("x-api-key").type(RestParamType.header).dataType("string").description("API Key").required(false).endParam()
        .clientRequestValidation(true)
        .to("direct:route-customer-onboarding-caseresolution-input");   
       
       from("direct:route-customer-onboarding-caseresolution-input")
        .routeId("Onboarding_CaseResolution_01")
        .setExchangePattern(ExchangePattern.InOut)
        .unmarshal().json(JsonLibrary.Jackson, PharosCaseResolutionRequestDto.class)
        .log("Request header info is   ${headers}")
        .log(LoggingLevel.INFO, "${body}")
        .to("direct:route-customer-onboarding-caseresolution");

       from("direct:route-customer-onboarding-caseresolution")
       .streamCaching()
       .process(customerOnboardingCaseResolutionRequestProcessor)
       .marshal().json(JsonLibrary.Jackson)
       .log(LoggingLevel.INFO, "Request is routed to Account Management Interface for customer onboarding  caseresolution request.")
       .choice()
       .when(simple("{{app.ami.interface.customer.onboarding.caseresolution.flag}}").contains("true"))
       .log(LoggingLevel.INFO,
       "Request is routed to Account Management Interface New URL for customer onboarding caseresolution request.")
       .to("{{app.ami.interface.customer.onboarding.caseresolution.url}}")
       .otherwise()
       .log(LoggingLevel.INFO,
        "Request is routed to Account Management Interface Old URL for customer onboarding caseresolution request.")
       .to("{{app.ami.interface.customer.onboarding.caseresolution.old.url}}")
       .to("direct:route-customer-onboarding-caseresolution-response");
       
       from("direct:route-customer-onboarding-caseresolution-response")
        .id("Onboarding_CaseResolution__02")
        .process(customerOnboardingCaseResolutionResponseProcessor).end();


       logger.info("Customer Onboarding CaseResolution router started.");
   }

}
