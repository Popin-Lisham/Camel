package com.wu.compliance.iwatch.orchestrator.dto.response;

import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.microcommonapi.dto.ErrorDetail;
import com.wu.compliance.iwatch.microcommonapi.dto.Message;

import java.util.List;

public class ResponseBuilder {
    private String traceId;
    private String code;
    private String description;
    private Message message;
    private List<ErrorDetail> errorDetails;

    private ResponseBuilder() {
    }

    public static DefaultResponse buildSuccessResponse(String traceId) {
        return new ResponseBuilder()
                .code("WUIWXORCH2000")
                .message(new Message("iWatchX", "Message successfully published to the queue."))
                .traceId(traceId)
                .description("")
                .build();
    }

    public static DefaultResponse buildUnknownErrorResponse(String traceId, String errorDescription) {
        return new ResponseBuilder()
                .traceId(traceId)
                .code("WUIWXORCH5000")
                .description(errorDescription)
                .message(new Message("iWatchX", "Internal Server Error"))
                .build();
    }

    public static DefaultResponse buildBadRequestResponse(String traceId, List<ErrorDetail> errorDetails) {
        return new ResponseBuilder()
                .traceId(traceId)
                .code("WUIWXORCH4000")
                .message(new Message("iWatchX", "Bad request"))
                .description("")
                .errorDetails(errorDetails)
                .build();
    }


    public static DefaultResponse buildExteranlFailureResponse(String traceId, String errorDescription) {
        return new ResponseBuilder()
                .traceId(traceId)
                .code("WUIWXORCH4000")
                .message(new Message("iWatchX", "Error while calling external service."))
                .description(errorDescription)
                .build();
    }

    public static DefaultResponse buildBadRequestResponse(String traceId, String description) {
        return new ResponseBuilder()
                .traceId(traceId)
                .code("WUIWXORCH4000")
                .message(new Message("iWatchX", "Bad request"))
                .description(description)
                .build();
    }

    public ResponseBuilder traceId(String traceId) {
        this.traceId = traceId;
        return this;
    }

    public ResponseBuilder code(String code) {
        this.code = code;
        return this;
    }

    public ResponseBuilder description(String description) {
        this.description = description;
        return this;
    }

    public ResponseBuilder message(Message message) {
        this.message = message;
        return this;
    }

    public ResponseBuilder errorDetails(List<ErrorDetail> errorDetails) {
        this.errorDetails = errorDetails;
        return this;
    }

    public DefaultResponse build() {
        return new DefaultResponse(traceId, code, description, message, errorDetails);
    }
}
