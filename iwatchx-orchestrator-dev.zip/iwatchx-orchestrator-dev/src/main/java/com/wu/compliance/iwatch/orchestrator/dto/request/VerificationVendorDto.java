package com.wu.compliance.iwatch.orchestrator.dto.request;

import java.time.OffsetDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;



/**
 * Defines Vendor verification details
 */



@JsonInclude(JsonInclude.Include.NON_NULL)
public class VerificationVendorDto {

	private String vendor;

	
	private OffsetDateTime statusDate;

	private String referenceNumber;

	private String source;

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public OffsetDateTime getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(OffsetDateTime statusDate) {
		this.statusDate = statusDate;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

}
