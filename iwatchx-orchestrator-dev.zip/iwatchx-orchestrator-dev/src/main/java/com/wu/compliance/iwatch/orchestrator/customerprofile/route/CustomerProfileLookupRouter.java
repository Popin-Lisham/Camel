package com.wu.compliance.iwatch.orchestrator.customerprofile.route;

import java.util.Objects;
import java.util.concurrent.TimeoutException;

import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import org.apache.camel.ExchangePattern;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestParamType;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wu.compliance.iwatch.orchestrator.customerprofile.processor.CustomerProfileExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.customerprofile.processor.CustomerProfileRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.customerprofile.processor.CustomerProfileResponseProcessor;
import com.wu.compliance.iwatch.orchestrator.dto.request.LookupCustomerRequestDto;

@Component
public class CustomerProfileLookupRouter extends RouteBuilder {
	Logger logger = LogManager.getLogger(this.getClass());

	private final CustomerProfileRequestProcessor customerProfileRequestProcessor;
	private final CustomerProfileExceptionProcessor customerProfileExceptionProcessor;
	private final CustomerProfileResponseProcessor customerProfileResponseProcessor;
	private final SanitizationProcessor sanitizationProcessor;
	private final XssDataExceptionProcessor xssDataExceptionProcessor;

	public CustomerProfileLookupRouter(CustomerProfileRequestProcessor customerProfileRequestProcessor,
									   CustomerProfileExceptionProcessor customerProfileExceptionProcessor,
									   CustomerProfileResponseProcessor customerProfileResponseProcessor,
									   SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor) {
		Objects.requireNonNull(customerProfileRequestProcessor, "customerProfileRequestProcessor is null");
		Objects.requireNonNull(customerProfileExceptionProcessor, "customerProfileExceptionProcessor is null");
		Objects.requireNonNull(customerProfileResponseProcessor, "customerProfileResponseProcessor is null");
		Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
		Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");

		this.customerProfileRequestProcessor = customerProfileRequestProcessor;
		this.customerProfileExceptionProcessor = customerProfileExceptionProcessor;
		this.customerProfileResponseProcessor = customerProfileResponseProcessor;
		this.sanitizationProcessor = sanitizationProcessor;
		this.xssDataExceptionProcessor = xssDataExceptionProcessor;
	}

	@Override
    public void configure() {

		interceptSendToEndpoint("direct:route-cpi-profile-lookup-input")
				.process(sanitizationProcessor);

        onException(Exception.class)
                .handled(true)
                .process(customerProfileExceptionProcessor);

        onException(HttpHostConnectException.class, TimeoutException.class)
                .handled(true)
                .maximumRedeliveries("{{app.context.retry.count}}").redeliveryDelay("{{app.context.retry.delay}}")
                .retryAttemptedLogLevel(LoggingLevel.WARN)
                .process(customerProfileExceptionProcessor);

		onException(XssDataException.class)
				.handled(true)
				.process(xssDataExceptionProcessor)
				.marshal().json(JsonLibrary.Jackson);

        rest().tag("Post Customer Profile")
                .description("Customer Profile lookup from Pharos")
                .post("{{app.context.cpi.lookup.post}}")
                .produces("application/json")
                .consumes("application/json")
                .type(LookupCustomerRequestDto.class)
                .param().name("x-wu-externalRefId").type(RestParamType.header).dataType("string").description("External Ref Id.").required(true).endParam()
                .param().name("Authorization").type(RestParamType.header).dataType("string").description("AuthToken").required(true).endParam()
            	.param().name("x-api-key").type(RestParamType.header).dataType("string").description("API Key").required(true).endParam()
                .clientRequestValidation(true)
                .to("direct:route-cpi-profile-lookup-input");
        
        from("direct:route-cpi-profile-lookup-input")
    			.routeId("CPI_Profile_Lookup_01")
    			.setExchangePattern(ExchangePattern.InOut)
    			.unmarshal().json(JsonLibrary.Jackson, LookupCustomerRequestDto.class)
    			.log("Request header info is   ${headers}")
    			.log(LoggingLevel.INFO, "${body}")
    			.to("direct:route-cpi-profile-lookup"); 

	    from("direct:route-cpi-profile-lookup")
		    	.streamCaching()
		    	.process(customerProfileRequestProcessor)
		    	.marshal().json(JsonLibrary.Jackson)
		     	.log(LoggingLevel.INFO, "Request is routed to RAC for customer profile lookup request.")
		     	.to("{{app.cpi.interface.lookup.service.url}}")
		     	.to("direct:route-cpi-profile-lookup-response");
	    
	    from("direct:route-cpi-profile-lookup-response")
	    		.id("CPI_Profile_Lookup_02")
	    		.process(customerProfileResponseProcessor).end();

        logger.info("RAC Customer Profile lookup router started.");
    }
}
