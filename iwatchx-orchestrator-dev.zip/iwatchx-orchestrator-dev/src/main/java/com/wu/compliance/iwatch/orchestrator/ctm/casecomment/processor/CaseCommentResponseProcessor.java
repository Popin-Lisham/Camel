package com.wu.compliance.iwatch.orchestrator.ctm.casecomment.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import wu.ei.cis.csc.core.gsi.xsd.gsi.addcommentsresponse_2016_12.AddCommentsResponse20161212;

@Component
public class CaseCommentResponseProcessor   implements Processor {
    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange) {
        AddCommentsResponse20161212 addCommentsResponse = exchange.getIn().getBody(AddCommentsResponse20161212.class);
        exchange.getIn().setBody(addCommentsResponse);
        logger.info("Successfully added case comments for caseId : "+addCommentsResponse.getIWatchCaseID());
    }
}
