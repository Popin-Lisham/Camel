package com.wu.compliance.iwatch.orchestrator.transaction.lookup.configuration;


import com.westernunion.transactionlookupservice.TransactionLookupService;
import org.apache.camel.component.cxf.CxfEndpoint;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TransactionLookupConfiguration {

    @Bean(name = "rtraTransactionLookupCxfEndpoint")
    @ConfigurationProperties(prefix = "cxf-transaction-lookup")
    public CxfEndpoint rtraTransactionLookupCxfEndpoint() {
        CxfEndpoint cxfEndpoint = new CxfEndpoint();
        cxfEndpoint.setServiceClass(TransactionLookupService.class);
        return cxfEndpoint;
    }

}
