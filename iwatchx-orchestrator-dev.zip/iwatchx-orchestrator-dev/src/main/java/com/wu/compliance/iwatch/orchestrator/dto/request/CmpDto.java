package com.wu.compliance.iwatch.orchestrator.dto.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class CmpDto {

	private List<FlagStatusListDto> flags;
	

    public List<FlagStatusListDto> getFlags() {
		return flags;
	}


	public void setFlags(List<FlagStatusListDto> flags) {
		this.flags = flags;
	}


@Override
  public String toString() {
    return "CmpDto [flags=" + flags + "]";
  }
}
