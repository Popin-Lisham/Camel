package com.wu.compliance.iwatch.orchestrator.activity.processor;

import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.orchestrator.dto.response.ResponseBuilder;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class ActivityResponseProcessor implements Processor {
    @Override
    public void process(Exchange exchange) throws Exception {
        final DefaultResponse response = ResponseBuilder.buildSuccessResponse(exchange.getIn().getHeader(HeaderKey.CORRELATION_ID.getValue()).toString());
        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.OK.value());
        exchange.getIn().setBody(response);
    }
}