package com.wu.compliance.iwatch.orchestrator.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ActivityStatusRequestDto {

    @JsonProperty("TRNS_SUR_KEY")
    private String txnSurKey;
    @JsonProperty("MTCN16")
    private String refId;
    @JsonProperty("MTCN")
    private String shrtRefId;
    @JsonProperty("TRNS_TS")
    private String txnTimestamp;
    @JsonProperty("ATTEMPTID")
    private String attemptId;
    @JsonProperty("QUE_NAME")
    private String qName;
    @JsonProperty("TRANSACTIONSTATE")
    private String txnState;
    @JsonProperty("SEND_UPDATE_TIMESTAMP")
    private String sendTimestamp;
    @JsonProperty("PAY_UPDATE_TIMESTAMP")
    private String payTimestamp;
    @JsonProperty("GSI_CASE_CREATED")
    private String gsiCaseCreated;
    @JsonProperty("STATUS")
    private String txnStatus;
    @JsonProperty("ATTEMPT_TIMESTAMP")
    private String attemptTimestamp;

    public String getTxnSurKey() {
        return txnSurKey;
    }

    public void setTxnSurKey(String txnSurKey) {
        this.txnSurKey = txnSurKey;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getShrtRefId() {
        return shrtRefId;
    }

    public void setShrtRefId(String shrtRefId) {
        this.shrtRefId = shrtRefId;
    }

    public String getTxnTimestamp() {
        return txnTimestamp;
    }

    public void setTxnTimestamp(String txnTimestamp) {
        this.txnTimestamp = txnTimestamp;
    }

    public String getAttemptId() {
        return attemptId;
    }

    public void setAttemptId(String attemptId) {
        this.attemptId = attemptId;
    }

    public String getqName() {
        return qName;
    }

    public void setqName(String qName) {
        this.qName = qName;
    }

    public String getTxnState() {
        return txnState;
    }

    public void setTxnState(String txnState) {
        this.txnState = txnState;
    }

    public String getSendTimestamp() {
        return sendTimestamp;
    }

    public void setSendTimestamp(String sendTimestamp) {
        this.sendTimestamp = sendTimestamp;
    }

    public String getPayTimestamp() {
        return payTimestamp;
    }

    public void setPayTimestamp(String payTimestamp) {
        this.payTimestamp = payTimestamp;
    }

    public String getGsiCaseCreated() {
        return gsiCaseCreated;
    }

    public void setGsiCaseCreated(String gsiCaseCreated) {
        this.gsiCaseCreated = gsiCaseCreated;
    }

    public String getTxnStatus() {
        return txnStatus;
    }

    public void setTxnStatus(String txnStatus) {
        this.txnStatus = txnStatus;
    }

    public String getAttemptTimestamp() {
        return attemptTimestamp;
    }

    public void setAttemptTimestamp(String attemptTimestamp) {
        this.attemptTimestamp = attemptTimestamp;
    }
}
