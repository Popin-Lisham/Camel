package com.wu.compliance.iwatch.orchestrator.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wu.compliance.iwatch.microcommonapi.dto.OffsetDateTimeToString;
import com.wu.compliance.iwatch.microcommonapi.dto.StringToOffsetDateTime;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import java.time.OffsetDateTime;
import java.util.List;

/**
 * Defines document details
 */

@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class KycDetail {

	private String channel;

	private String documentNumber;

	private String documentType;

	private String documentSubType;

	private String issuingAgency;

	private String issuingCountry;

	private String issuingAuthority;

	@Valid
	private String issueDate;
	@Valid
	private String expirationDate;

	private String doesDocHaveExpDate;

	private String doesDocHaveIssueDate;

	private String verificationStatus;
	@Valid
	@JsonSerialize(converter = OffsetDateTimeToString.class)
	@JsonDeserialize(converter = StringToOffsetDateTime.class)
	private OffsetDateTime statusDate;

	@Valid
	private List<String> docRefNumber;

	private String source;

	private String txnRefId;
	@Valid
	@JsonSerialize(converter = OffsetDateTimeToString.class)
	@JsonDeserialize(converter = StringToOffsetDateTime.class)
	private OffsetDateTime txnDate;

	private String ocrFirstName;

	private String ocrLastName;

	private String ocrMiddleName;

	private String ocrName;
	@Valid
	private String ocrDateOfBirth;

	private String ocrNumber;

	private String ocrType;

	private String ocrIssuingAgency;

	private String ocrIssuingCountry;
	@Valid
	private String ocrIssueDate;
	@Valid
	private String ocrExpirationDate;

	private String ocrFirstNameMatch;

	private String ocrLastNameMatch;

	private String ocrMiddleNameMatch;

	private String ocrNameMatch;

	private String ocrDateOfBirthMatch;

	private String ocrNumberMatch;

	private String ocrTypeMatch;

	private String ocrIssuingAgencyMatch;

	private String ocrIssuingCountryMatch;

	@Override
	public String toString() {
		return "KycDetail{" +
				"channel='" + channel + '\'' +
				", documentNumber='" + documentNumber + '\'' +
				", documentType='" + documentType + '\'' +
				", documentSubType='" + documentSubType + '\'' +
				", issuingAgency='" + issuingAgency + '\'' +
				", issuingCountry='" + issuingCountry + '\'' +
				", issuingAuthority='" + issuingAuthority + '\'' +
				", issueDate='" + issueDate + '\'' +
				", expirationDate='" + expirationDate + '\'' +
				", doesDocHaveExpDate='" + doesDocHaveExpDate + '\'' +
				", doesDocHaveIssueDate='" + doesDocHaveIssueDate + '\'' +
				", verificationStatus='" + verificationStatus + '\'' +
				", statusDate=" + statusDate +
				", docRefNumber=" + docRefNumber +
				", source='" + source + '\'' +
				", txnRefId='" + txnRefId + '\'' +
				", txnDate=" + txnDate +
				", ocrFirstName='" + ocrFirstName + '\'' +
				", ocrLastName='" + ocrLastName + '\'' +
				", ocrMiddleName='" + ocrMiddleName + '\'' +
				", ocrName='" + ocrName + '\'' +
				", ocrDateOfBirth='" + ocrDateOfBirth + '\'' +
				", ocrNumber='" + ocrNumber + '\'' +
				", ocrType='" + ocrType + '\'' +
				", ocrIssuingAgency='" + ocrIssuingAgency + '\'' +
				", ocrIssuingCountry='" + ocrIssuingCountry + '\'' +
				", ocrIssueDate='" + ocrIssueDate + '\'' +
				", ocrExpirationDate='" + ocrExpirationDate + '\'' +
				", ocrFirstNameMatch='" + ocrFirstNameMatch + '\'' +
				", ocrLastNameMatch='" + ocrLastNameMatch + '\'' +
				", ocrMiddleNameMatch='" + ocrMiddleNameMatch + '\'' +
				", ocrNameMatch='" + ocrNameMatch + '\'' +
				", ocrDateOfBirthMatch='" + ocrDateOfBirthMatch + '\'' +
				", ocrNumberMatch='" + ocrNumberMatch + '\'' +
				", ocrTypeMatch='" + ocrTypeMatch + '\'' +
				", ocrIssuingAgencyMatch='" + ocrIssuingAgencyMatch + '\'' +
				", ocrIssuingCountryMatch='" + ocrIssuingCountryMatch + '\'' +
				", ocrIssueDateMatch='" + ocrIssueDateMatch + '\'' +
				", ocrExpirationDateMatch='" + ocrExpirationDateMatch + '\'' +
				'}';
	}

	private String ocrIssueDateMatch;

	private String ocrExpirationDateMatch;

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDocumentSubType() {
		return documentSubType;
	}

	public void setDocumentSubType(String documentSubType) {
		this.documentSubType = documentSubType;
	}

	public String getIssuingAgency() {
		return issuingAgency;
	}

	public void setIssuingAgency(String issuingAgency) {
		this.issuingAgency = issuingAgency;
	}

	public String getIssuingCountry() {
		return issuingCountry;
	}

	public void setIssuingCountry(String issuingCountry) {
		this.issuingCountry = issuingCountry;
	}

	public String getIssuingAuthority() {
		return issuingAuthority;
	}

	public void setIssuingAuthority(String issuingAuthority) {
		this.issuingAuthority = issuingAuthority;
	}

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getDoesDocHaveExpDate() {
		return doesDocHaveExpDate;
	}

	public void setDoesDocHaveExpDate(String doesDocHaveExpDate) {
		this.doesDocHaveExpDate = doesDocHaveExpDate;
	}

	public String getDoesDocHaveIssueDate() {
		return doesDocHaveIssueDate;
	}

	public void setDoesDocHaveIssueDate(String doesDocHaveIssueDate) {
		this.doesDocHaveIssueDate = doesDocHaveIssueDate;
	}

	public String getVerificationStatus() {
		return verificationStatus;
	}

	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}

	public OffsetDateTime getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(OffsetDateTime statusDate) {
		this.statusDate = statusDate;
	}

	public List<String> getDocRefNumber() {
		return docRefNumber;
	}

	public void setDocRefNumber(List<String> docRefNumber) {
		this.docRefNumber = docRefNumber;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getTxnRefId() {
		return txnRefId;
	}

	public void setTxnRefId(String txnRefId) {
		this.txnRefId = txnRefId;
	}

	public OffsetDateTime getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(OffsetDateTime txnDate) {
		this.txnDate = txnDate;
	}

	public String getOcrFirstName() {
		return ocrFirstName;
	}

	public void setOcrFirstName(String ocrFirstName) {
		this.ocrFirstName = ocrFirstName;
	}

	public String getOcrLastName() {
		return ocrLastName;
	}

	public void setOcrLastName(String ocrLastName) {
		this.ocrLastName = ocrLastName;
	}

	public String getOcrMiddleName() {
		return ocrMiddleName;
	}

	public void setOcrMiddleName(String ocrMiddleName) {
		this.ocrMiddleName = ocrMiddleName;
	}

	public String getOcrName() {
		return ocrName;
	}

	public void setOcrName(String ocrName) {
		this.ocrName = ocrName;
	}

	public String getOcrDateOfBirth() {
		return ocrDateOfBirth;
	}

	public void setOcrDateOfBirth(String ocrDateOfBirth) {
		this.ocrDateOfBirth = ocrDateOfBirth;
	}

	public String getOcrNumber() {
		return ocrNumber;
	}

	public void setOcrNumber(String ocrNumber) {
		this.ocrNumber = ocrNumber;
	}

	public String getOcrType() {
		return ocrType;
	}

	public void setOcrType(String ocrType) {
		this.ocrType = ocrType;
	}

	public String getOcrIssuingAgency() {
		return ocrIssuingAgency;
	}

	public void setOcrIssuingAgency(String ocrIssuingAgency) {
		this.ocrIssuingAgency = ocrIssuingAgency;
	}

	public String getOcrIssuingCountry() {
		return ocrIssuingCountry;
	}

	public void setOcrIssuingCountry(String ocrIssuingCountry) {
		this.ocrIssuingCountry = ocrIssuingCountry;
	}

	public String getOcrIssueDate() {
		return ocrIssueDate;
	}

	public void setOcrIssueDate(String ocrIssueDate) {
		this.ocrIssueDate = ocrIssueDate;
	}

	public String getOcrExpirationDate() {
		return ocrExpirationDate;
	}

	public void setOcrExpirationDate(String ocrExpirationDate) {
		this.ocrExpirationDate = ocrExpirationDate;
	}

	public String getOcrFirstNameMatch() {
		return ocrFirstNameMatch;
	}

	public void setOcrFirstNameMatch(String ocrFirstNameMatch) {
		this.ocrFirstNameMatch = ocrFirstNameMatch;
	}

	public String getOcrLastNameMatch() {
		return ocrLastNameMatch;
	}

	public void setOcrLastNameMatch(String ocrLastNameMatch) {
		this.ocrLastNameMatch = ocrLastNameMatch;
	}

	public String getOcrMiddleNameMatch() {
		return ocrMiddleNameMatch;
	}

	public void setOcrMiddleNameMatch(String ocrMiddleNameMatch) {
		this.ocrMiddleNameMatch = ocrMiddleNameMatch;
	}

	public String getOcrNameMatch() {
		return ocrNameMatch;
	}

	public void setOcrNameMatch(String ocrNameMatch) {
		this.ocrNameMatch = ocrNameMatch;
	}

	public String getOcrDateOfBirthMatch() {
		return ocrDateOfBirthMatch;
	}

	public void setOcrDateOfBirthMatch(String ocrDateOfBirthMatch) {
		this.ocrDateOfBirthMatch = ocrDateOfBirthMatch;
	}

	public String getOcrNumberMatch() {
		return ocrNumberMatch;
	}

	public void setOcrNumberMatch(String ocrNumberMatch) {
		this.ocrNumberMatch = ocrNumberMatch;
	}

	public String getOcrTypeMatch() {
		return ocrTypeMatch;
	}

	public void setOcrTypeMatch(String ocrTypeMatch) {
		this.ocrTypeMatch = ocrTypeMatch;
	}

	public String getOcrIssuingAgencyMatch() {
		return ocrIssuingAgencyMatch;
	}

	public void setOcrIssuingAgencyMatch(String ocrIssuingAgencyMatch) {
		this.ocrIssuingAgencyMatch = ocrIssuingAgencyMatch;
	}

	public String getOcrIssuingCountryMatch() {
		return ocrIssuingCountryMatch;
	}

	public void setOcrIssuingCountryMatch(String ocrIssuingCountryMatch) {
		this.ocrIssuingCountryMatch = ocrIssuingCountryMatch;
	}

	public String getOcrIssueDateMatch() {
		return ocrIssueDateMatch;
	}

	public void setOcrIssueDateMatch(String ocrIssueDateMatch) {
		this.ocrIssueDateMatch = ocrIssueDateMatch;
	}

	public String getOcrExpirationDateMatch() {
		return ocrExpirationDateMatch;
	}

	public void setOcrExpirationDateMatch(String ocrExpirationDateMatch) {
		this.ocrExpirationDateMatch = ocrExpirationDateMatch;
	}
}
