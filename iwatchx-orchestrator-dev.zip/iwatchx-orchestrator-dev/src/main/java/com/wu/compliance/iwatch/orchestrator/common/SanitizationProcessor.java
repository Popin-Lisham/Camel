package com.wu.compliance.iwatch.orchestrator.common;

import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.collections4.MapUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
public class SanitizationProcessor implements Processor {

    Logger logger = LogManager.getLogger(this.getClass());

    private List<String> xssBlackList;

    public SanitizationProcessor(@Value("#{'${app.security.xss.blacklist}'.split(',')}") List<String> xssBlackList) {
        Objects.requireNonNull(xssBlackList, "xssBlackList is null");
        this.xssBlackList = xssBlackList;
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        String requestHeader = null;
        String requestBody = exchange.getIn().getBody(String.class);
        //path variables and query params are captured in the headers itself
        Map<String, Object> headers = exchange.getIn().getHeaders();
        if(MapUtils.isNotEmpty(headers)) {
            requestHeader = headers.values().stream()
                    .filter(value -> value instanceof String)
                    .map(value -> String.valueOf(value).toLowerCase())
                    .collect(Collectors.joining());
        }
        for (String xss : xssBlackList) {
            if (requestHeader != null && requestHeader.contains(xss)) {
                logger.error("Request headers contains unsanitized data");
                throw new XssDataException("Request was rejected because the input contains untrusted data");
            }
            if (requestBody != null && requestBody.toLowerCase().contains(xss)) {
                logger.error("Request body contains unsanitized data");
                throw new XssDataException("Request was rejected because the input contains untrusted data");
            }
        }
        exchange.getIn().setBody(requestBody);
        exchange.getIn().setHeader("Content-Security-Policy","default-src 'self';base-uri 'self';block-all-mixed-content;font-src 'self' https: data:;frame-ancestors 'self';img-src 'self' data:;object-src 'none';script-src 'self';script-src-attr 'none';style-src 'self' https: 'unsafe-inline';upgrade-insecure-requests");
        exchange.getIn().setHeader("X-Content-Type-Options","nosniff");
        exchange.getIn().setHeader("Strict-Transport-Security","max-age=15552000; includeSubDomains");
        exchange.getIn().setHeader("X-XSS-Protection","1; mode=block");
    }

}
