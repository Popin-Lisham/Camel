package com.wu.compliance.iwatch.orchestrator.dto.type;

import java.util.List;

public class Entity {
	private List<String> addresses;
	private List<String> aliases;
	private String city;
	private ListSource listSource;
	private List<Phone> phones;
	private List<Constraint> constraints;
	private List<HitDetail> hitDetails;
	private List<String> dob;
	private String name;
	private String listType;
	private List<EntityId> entityIds;
	private String id;
	private Category category;
	private String hitType;
	private String info;
	
	public List<String> getAddresses() {
		return addresses;
	}
	public void setAddresses(List<String> addresses) {
		this.addresses = addresses;
	}
	public List<String> getAliases() {
		return aliases;
	}
	public void setAliases(List<String> aliases) {
		this.aliases = aliases;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public ListSource getListSource() {
		return listSource;
	}
	public void setListSource(ListSource listSource) {
		this.listSource = listSource;
	}
	public List<Phone> getPhones() {
		return phones;
	}
	public void setPhones(List<Phone> phones) {
		this.phones = phones;
	}
	public List<Constraint> getConstraints() {
		return constraints;
	}
	public void setConstraints(List<Constraint> constraints) {
		this.constraints = constraints;
	}
	public List<HitDetail> getHitDetails() {
		return hitDetails;
	}
	public void setHitDetails(List<HitDetail> hitDetails) {
		this.hitDetails = hitDetails;
	}
	public List<String> getDob() {
		return dob;
	}
	public void setDob(List<String> dob) {
		this.dob = dob;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getListType() {
		return listType;
	}
	public void setListType(String listType) {
		this.listType = listType;
	}
	public List<EntityId> getEntityIds() {
		return entityIds;
	}
	public void setEntityIds(List<EntityId> entityIds) {
		this.entityIds = entityIds;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public String getHitType() {
		return hitType;
	}
	public void setHitType(String hitType) {
		this.hitType = hitType;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}

	
}