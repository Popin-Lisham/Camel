package com.wu.compliance.iwatch.orchestrator.dto.request;

public class ValidationDto extends AbstractAttachmentQuality {
}
