package com.wu.compliance.iwatch.orchestrator.dto.request;

public class ProfileAttachmentDto {
    private String caseRefNo;
    private SubjectDto subject;
    private String customerId;
    private String docRefNum;
    private String name;
    private String size;
    private String mime;
    private String type;
    private String subType;
    private ValidationDto validation;
    private String source;
    private OCRDto ocr;

    public String getCaseRefNo() {
        return caseRefNo;
    }

    public void setCaseRefNo(String caseRefNo) {
        this.caseRefNo = caseRefNo;
    }

    public SubjectDto getSubject() {
        return subject;
    }

    public void setSubject(SubjectDto subject) {
        this.subject = subject;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getDocRefNum() {
        return docRefNum;
    }

    public void setDocRefNum(String docRefNum) {
        this.docRefNum = docRefNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getMime() {
        return mime;
    }

    public void setMime(String mime) {
        this.mime = mime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }

    public ValidationDto getValidation() {
        return validation;
    }

    public void setValidation(ValidationDto validation) {
        this.validation = validation;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public OCRDto getOcr() {
        return ocr;
    }

    public void setOcr(OCRDto ocr) {
        this.ocr = ocr;
    }
}
