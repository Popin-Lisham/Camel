package com.wu.compliance.iwatch.orchestrator.dto.request;

import java.util.List;

/**
 * This is the request model for Entity Clearing service.
 */


public class EntityClearingRequestDto {
	
	private HeaderDto header;

	private String galacticId;

	private String customerUmn;

	
	private String referenceType;

	
	private String referenceNumber;

	
	private List<ClearedEntityDto> clearedEntitiesList;

	private String comments;
	
	private String userId;
	
	private String userName;

	private String operationType;

	public HeaderDto getHeader() {
		return header;
	}

	public void setHeader(HeaderDto header) {
		this.header = header;
	}

	public String getGalacticId() {
		return galacticId;
	}

	public void setGalacticId(String galacticId) {
		this.galacticId = galacticId;
	}

	public String getCustomerUmn() {
		return customerUmn;
	}

	public void setCustomerUmn(String customerUmn) {
		this.customerUmn = customerUmn;
	}

	public String getReferenceType() {
		return referenceType;
	}

	public void setReferenceType(String referenceType) {
		this.referenceType = referenceType;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public List<ClearedEntityDto> getClearedEntitiesList() {
		return clearedEntitiesList;
	}

	public void setClearedEntitiesList(List<ClearedEntityDto> clearedEntitiesList) {
		this.clearedEntitiesList = clearedEntitiesList;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}
}
