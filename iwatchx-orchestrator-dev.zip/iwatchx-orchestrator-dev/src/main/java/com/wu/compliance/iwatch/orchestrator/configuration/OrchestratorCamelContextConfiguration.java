package com.wu.compliance.iwatch.orchestrator.configuration;

import com.wu.compliance.iwatch.orchestrator.common.unitofwork.CorrelationIdUnitOfWorkFactory;
import org.apache.camel.CamelContext;
import org.apache.camel.ExtendedCamelContext;
import org.apache.camel.spring.boot.CamelContextConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OrchestratorCamelContextConfiguration {
    @Bean
    CamelContextConfiguration contextConfiguration() {
        return new CamelContextConfiguration() {
            @Override
            public void beforeApplicationStart(CamelContext camelContext) {
                camelContext.adapt(ExtendedCamelContext.class).setUnitOfWorkFactory(new CorrelationIdUnitOfWorkFactory());
            }

            @Override
            public void afterApplicationStart(CamelContext camelContext) {
            }
        };
    }
}
