package com.wu.compliance.iwatch.orchestrator.ctm.casedisposition;

import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.ctm.casedisposition.processor.CaseDispositionExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.ctm.casedisposition.processor.CaseDispositionRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.ctm.casedisposition.processor.CaseDispositionResponseProcessor;
import org.apache.camel.ExchangePattern;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import wu.ei.cis.csc.core.gsi.xsd.gsi.gsitxndecisionrequest_2016_12.GSITxnDecisionRequest20161212;

import java.util.Objects;
import java.util.concurrent.TimeoutException;

@Component
public class CaseDispositionRouter extends RouteBuilder {

    Logger logger = LogManager.getLogger(this.getClass());

    private final CaseDispositionRequestProcessor caseDispositionRequestProcessor;

    private final CaseDispositionResponseProcessor caseDispositionResponseProcessor;

    private final CaseDispositionExceptionProcessor caseDispositionExceptionProcessor;

    private final SanitizationProcessor sanitizationProcessor;

    private final XssDataExceptionProcessor xssDataExceptionProcessor;

    public CaseDispositionRouter(CaseDispositionRequestProcessor caseDispositionRequestProcessor,
                                 CaseDispositionResponseProcessor caseDispositionResponseProcessor,
                                 CaseDispositionExceptionProcessor caseDispositionExceptionProcessor,
                                 SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor) {
        Objects.requireNonNull(caseDispositionRequestProcessor, "decisionRequestProcessor is null");
        Objects.requireNonNull(caseDispositionResponseProcessor, "decisionResponseProcessor is null");
        Objects.requireNonNull(caseDispositionExceptionProcessor, "decisionExceptionProcessor is null");
        Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
        Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");
        this.caseDispositionRequestProcessor = caseDispositionRequestProcessor;
        this.caseDispositionResponseProcessor = caseDispositionResponseProcessor;
        this.caseDispositionExceptionProcessor = caseDispositionExceptionProcessor;
        this.sanitizationProcessor = sanitizationProcessor;
        this.xssDataExceptionProcessor = xssDataExceptionProcessor;
    }

    @Override
    public void configure() {

        interceptSendToEndpoint("direct:process-case-disposition-input")
                .process(sanitizationProcessor);

        onException(Exception.class)
                .handled(true)
                .process(caseDispositionExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(HttpHostConnectException.class, TimeoutException.class)
                .handled(true)
                .maximumRedeliveries("{{app.context.retry.count}}").redeliveryDelay("{{app.context.retry.delay}}")
                .retryAttemptedLogLevel(LoggingLevel.WARN)
                .process(caseDispositionExceptionProcessor);

        onException(XssDataException.class)
                .handled(true)
                .process(xssDataExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        rest()
                .tag("Send Case Disposition Action")
                .description("send case disposition action to ctm endpoint")
                .post("{{app.context.case.disposition.post}}")
                .consumes("application/text")
                .type(String.class)
                .to("direct:process-case-disposition-input");

        from("direct:process-case-disposition-input")
                .routeId("CTM_Disposition_01")
                .streamCaching()
                .unmarshal().json(JsonLibrary.Jackson, GSITxnDecisionRequest20161212.class)
                .log(LoggingLevel.DEBUG,"Case disposition action request payload :\n${body}")
                .process(caseDispositionRequestProcessor)
                .setHeader(CxfConstants.OPERATION_NAME, constant("GSITxnDecision_v1_0_0"))
                .to("direct:call-case-disposition-decision");

        from("direct:call-case-disposition-decision")
                .to(ExchangePattern.InOut, "cxf:bean:ctmTibcoGSIServiceCxfEndpoint")
                .process(caseDispositionResponseProcessor)
                .marshal().json(JsonLibrary.Jackson);

        logger.info("Case Disposition router started.");
    }
}
