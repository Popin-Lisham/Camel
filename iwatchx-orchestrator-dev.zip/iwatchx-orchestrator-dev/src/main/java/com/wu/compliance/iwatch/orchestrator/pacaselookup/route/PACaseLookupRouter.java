package com.wu.compliance.iwatch.orchestrator.pacaselookup.route;

import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import com.wu.compliance.iwatch.orchestrator.common.CommonValidationException;
import com.wu.compliance.iwatch.orchestrator.common.InvalidHeaderProcessor;
import com.wu.compliance.iwatch.orchestrator.dto.request.PALookupRequestDto;
import com.wu.compliance.iwatch.orchestrator.pacaselookup.processor.PACaseLookupExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.pacaselookup.processor.PACaseLookupHeaderValidationProcessor;
import com.wu.compliance.iwatch.orchestrator.pacaselookup.processor.PACaseLookupRequestProcessor;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.Resilience4jConfigurationDefinition;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
public class PACaseLookupRouter extends RouteBuilder {

    private final PACaseLookupRequestProcessor paCaseLookupRequestProcessor;
    private final PACaseLookupExceptionProcessor paCaseLookupExceptionProcessor;
    private final PACaseLookupHeaderValidationProcessor paCaseLookupHeaderValidationProcessor;
    private final InvalidHeaderProcessor invalidHeaderProcessor;
    private final Resilience4jConfigurationDefinition resilience4jConfigurationDefinition;

    public PACaseLookupRouter(PACaseLookupRequestProcessor paCaseLookupRequestProcessor, PACaseLookupExceptionProcessor paCaseLookupExceptionProcessor,
                              PACaseLookupHeaderValidationProcessor paCaseLookupHeaderValidationProcessor, InvalidHeaderProcessor invalidHeaderProcessor,
                              Resilience4jConfigurationDefinition resilience4jConfigurationDefinition) {
        Objects.requireNonNull(paCaseLookupRequestProcessor, "paCaseLookupRequestProcessor is null");
        Objects.requireNonNull(paCaseLookupExceptionProcessor, "paCaseLookupExceptionProcessor is null");
        Objects.requireNonNull(paCaseLookupHeaderValidationProcessor, "paCaseLookupHeaderValidationProcessor is null");
        Objects.requireNonNull(invalidHeaderProcessor, "invalidHeaderProcessor is null");
        Objects.requireNonNull(resilience4jConfigurationDefinition, "resilience4jConfigurationDefinition is null");

        this.paCaseLookupRequestProcessor = paCaseLookupRequestProcessor;
        this.paCaseLookupExceptionProcessor = paCaseLookupExceptionProcessor;
        this.paCaseLookupHeaderValidationProcessor = paCaseLookupHeaderValidationProcessor;
        this.invalidHeaderProcessor = invalidHeaderProcessor;
        this.resilience4jConfigurationDefinition = resilience4jConfigurationDefinition;
    }

    @Override
    public void configure() {

        interceptSendToEndpoint("direct:pacaserequest-processor").process(paCaseLookupHeaderValidationProcessor);

        onException(Exception.class)
                .handled(true)
                .process(paCaseLookupExceptionProcessor);

        onException(CommonValidationException.class)
                .handled(true)
                .process(invalidHeaderProcessor)
                .marshal().json(JsonLibrary.Jackson);

        rest().tag("Post CaseRefNo based profile attachment").description("Post CRN based profile attachment request to notify workflow manager")
                .post("{{app.context.case.profileattachments.post}}")
                .produces("application/json")
                .consumes("application/json")
                .type(PALookupRequestDto.class)
                .param().name(HeaderKey.TENANT_PID.getValue()).type(RestParamType.header).dataType("string").description("Tenant Primary Id.").required(false).endParam()
                .param().name(HeaderKey.TENANT_SID.getValue()).type(RestParamType.header).dataType("string").description("Tenant Secondary Id.").required(false).endParam()
                .param().name(HeaderKey.USER_ID.getValue()).type(RestParamType.header).dataType("string").description("User Id").required(false).endParam()
                .param().name(HeaderKey.USER_EMAIL.getValue()).type(RestParamType.header).dataType("string").description("User Email").required(false).endParam()
                .param().name(HeaderKey.USER_NAME.getValue()).type(RestParamType.header).dataType("string").description("User Name").required(false).endParam()
                .param().name(HeaderKey.CORRELATION_ID.getValue()).type(RestParamType.header).dataType("string").description("Correlation Id").required(false).endParam()
                .clientRequestValidation(true)
                .to("direct:pacaserequest-processor");

        from("direct:pacaserequest-processor")
                .routeId("RT_PACaseLookup_01")
                .process(paCaseLookupRequestProcessor)
                .circuitBreaker()
                .resilience4jConfiguration(resilience4jConfigurationDefinition)
                .to("{{app.case.profileattachments.url}}")
                .end()
                .log(LoggingLevel.INFO, "CRN based Profile attachment message successfully sent to PA Case Lookup Manager.");
    }
}
