package com.wu.compliance.iwatch.orchestrator.entity.clearing.processor;

import com.westernunion.entityservice.EntityClearingResponse;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class EntityClearingResponseProcessor implements Processor {

    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange) {
        EntityClearingResponse entityClearingResponse = exchange.getIn().getBody(EntityClearingResponse.class);
        logger.info("Successfully cleared entities.");
        exchange.getIn().setBody(entityClearingResponse);
    }
}
