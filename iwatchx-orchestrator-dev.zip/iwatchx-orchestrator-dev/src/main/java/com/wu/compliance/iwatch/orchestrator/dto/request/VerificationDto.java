package com.wu.compliance.iwatch.orchestrator.dto.request;

public class VerificationDto extends AbstractAttachmentQuality {
}
