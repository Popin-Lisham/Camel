package com.wu.compliance.iwatch.orchestrator.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * This is the request model for ComplianceMapping service.
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class LookupCustomerRequestDto {

	private HeaderDto header;

	private String countryISO2;

	private CustomerIDDto customerId;

	private String channel;

	public HeaderDto getHeader() {
		return header;
	}

	public void setHeader(HeaderDto header) {
		this.header = header;
	}

	public String getCountryISO2() {
		return countryISO2;
	}

	public void setCountryISO2(String countryISO2) {
		this.countryISO2 = countryISO2;
	}

	public CustomerIDDto getCustomerId() {
		return customerId;
	}

	public void setCustomerId(CustomerIDDto customerId) {
		this.customerId = customerId;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}
	
}
