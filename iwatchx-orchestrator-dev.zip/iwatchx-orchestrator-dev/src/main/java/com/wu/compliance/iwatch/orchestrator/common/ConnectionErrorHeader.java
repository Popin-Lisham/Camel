package com.wu.compliance.iwatch.orchestrator.common;

import org.apache.camel.Exchange;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.cxf.transport.http.HTTPException;
import org.apache.http.conn.HttpHostConnectException;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeoutException;

@Component
public class ConnectionErrorHeader {

    public Exchange setConnectionErrorHeader(Exchange exchange, Exception exception)
    {
        if (ExceptionUtils.hasCause(exception, HttpHostConnectException.class)
                || ExceptionUtils.hasCause(exception, TimeoutException.class)
                || ExceptionUtils.hasCause(exception, HTTPException.class))
        {
            exchange.getIn().setHeader("Connection_Error","true");
        }
        return exchange;
    }
}
