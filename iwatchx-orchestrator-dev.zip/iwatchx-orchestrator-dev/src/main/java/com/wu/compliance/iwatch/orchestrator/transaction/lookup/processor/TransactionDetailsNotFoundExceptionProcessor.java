package com.wu.compliance.iwatch.orchestrator.transaction.lookup.processor;

import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.orchestrator.dto.response.ResponseBuilder;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class TransactionDetailsNotFoundExceptionProcessor implements Processor {
    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange) {
        logger.debug("No data found from transaction lookup service");
        DefaultResponse errorResponse = ResponseBuilder.buildExteranlFailureResponse((String) exchange.getIn().getHeader(HeaderKey.CORRELATION_ID.getValue()), "No data found from transaction lookup service");

        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.NOT_FOUND.value());
        exchange.getIn().setBody(errorResponse);
    }
}
