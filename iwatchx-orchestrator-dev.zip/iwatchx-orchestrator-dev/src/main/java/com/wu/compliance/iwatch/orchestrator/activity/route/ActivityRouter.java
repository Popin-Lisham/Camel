package com.wu.compliance.iwatch.orchestrator.activity.route;

import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.activity.processor.ActivityExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.activity.processor.ActivityRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.activity.processor.ActivityResponseProcessor;
import com.wu.compliance.iwatch.orchestrator.activity.processor.ActivityStatusHeaderValidationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.CommonValidationException;
import com.wu.compliance.iwatch.orchestrator.common.InvalidHeaderProcessor;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.dto.request.ActivityStatusRequestDto;
import org.apache.camel.ExchangePattern;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.Resilience4jConfigurationDefinition;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestParamType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.ConnectException;
import java.util.Objects;
import java.util.concurrent.TimeoutException;

@Component
public class ActivityRouter extends RouteBuilder {
    Logger logger = LogManager.getLogger(this.getClass());

    private final ActivityRequestProcessor activityRequestProcessor;

    private final ActivityResponseProcessor activityResponseProcessor;

    private final ActivityExceptionProcessor activityExceptionProcessor;

    private final Resilience4jConfigurationDefinition resilience4jConfigurationDefinition;

    private final ActivityStatusHeaderValidationProcessor activityStatusHeaderValidationProcessor;

    private final InvalidHeaderProcessor invalidHeaderProcessor;

    private final SanitizationProcessor sanitizationProcessor;

    private final XssDataExceptionProcessor xssDataExceptionProcessor;

    @Value("${secret.cmtcmpl.iwatchx.queue.cjrabbitmq.username}")
    private String rabbitMQUserName;

    @Value("${secret.cmtcmpl.iwatchx.queue.cjrabbitmq.password}")
    private String rabbitMQPassword;


    public ActivityRouter(ActivityRequestProcessor activityRequestProcessor, ActivityResponseProcessor activityResponseProcessor,
                          ActivityExceptionProcessor activityExceptionProcessor,
                          Resilience4jConfigurationDefinition resilience4jConfigurationDefinition,
                          ActivityStatusHeaderValidationProcessor activityStatusHeaderValidationProcessor,
                          InvalidHeaderProcessor invalidHeaderProcessor, SanitizationProcessor sanitizationProcessor,
                          XssDataExceptionProcessor xssDataExceptionProcessor) {
        Objects.requireNonNull(activityRequestProcessor, "activityRequestProcessor is null");
        Objects.requireNonNull(activityExceptionProcessor, "activityResponseProcessor is null");
        Objects.requireNonNull(activityExceptionProcessor, "activityExceptionProcessor is null");
        Objects.requireNonNull(resilience4jConfigurationDefinition, "resilience4jConfigurationDefinition is null");
        Objects.requireNonNull(activityStatusHeaderValidationProcessor, "headerValidationProcessor is null");
        Objects.requireNonNull(invalidHeaderProcessor, "headerValidationFailedProcessor is null");
        Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
        Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");

        this.activityRequestProcessor = activityRequestProcessor;
        this.activityExceptionProcessor = activityExceptionProcessor;
        this.activityResponseProcessor = activityResponseProcessor;
        this.resilience4jConfigurationDefinition = resilience4jConfigurationDefinition;
        this.activityStatusHeaderValidationProcessor = activityStatusHeaderValidationProcessor;
        this.invalidHeaderProcessor = invalidHeaderProcessor;
        this.sanitizationProcessor = sanitizationProcessor;
        this.xssDataExceptionProcessor = xssDataExceptionProcessor;

    }

    @Override
    public void configure() {

        interceptSendToEndpoint("direct:request-activity")
                .process(sanitizationProcessor)
                .process(activityStatusHeaderValidationProcessor);

        onException(CommonValidationException.class)
                .handled(true)
                .process(invalidHeaderProcessor).id("RT_Activity_Process_05")
                .marshal().json(JsonLibrary.Jackson);

        onException(Exception.class)
                .handled(true)
                .process(activityExceptionProcessor).id("RT_Activity_Process_04")
                .marshal().json(JsonLibrary.Jackson);

        onException(ConnectException.class, TimeoutException.class)
                .handled(true)
                .maximumRedeliveries("{{app.context.retry.count}}").redeliveryDelay("{{app.context.retry.delay}}")
                .retryAttemptedLogLevel(LoggingLevel.WARN)
                .process(activityExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(XssDataException.class)
                .handled(true)
                .process(xssDataExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);


        rest().tag("Post Activity Status").description("Post activity status(transaction latest details) information from RTRA service publisher")
                .post("{{app.context.activity.post}}")
                .produces("application/json")
                .consumes("application/json")
                .type(ActivityStatusRequestDto.class)
                .param().name("x-wu-tenantpid").type(RestParamType.header).required(false).dataType("string").description("Tenant Primary Id.").endParam()
                .param().name("x-wu-tenantsid").type(RestParamType.header).required(false).dataType("string").description("Tenant Secondary Id.").endParam()
                .param().name("x-wu-userid").type(RestParamType.header).dataType("string").description("User Id").required(false).endParam()
                .param().name("x-wu-useremail").type(RestParamType.header).dataType("string").description("User Email").required(false).endParam()
                .param().name("x-wu-username").type(RestParamType.header).dataType("string").description("User Name").required(false).endParam()
                .param().name("x-wu-correlationId").type(RestParamType.header).dataType("string").description("Correlation Id").required(false).endParam()
                .clientRequestValidation(true)
                .to("direct:request-activity");

        from("direct:request-activity")
                .routeId("RT_Activity_01")
                .setExchangePattern(ExchangePattern.InOut)
                .removeHeaders("Camel.*")
                .process(activityRequestProcessor)
                .to("direct:routeActivity");


        from("direct:routeActivity")
                .circuitBreaker()
                .resilience4jConfiguration(resilience4jConfigurationDefinition)
                .to(ExchangePattern.InOnly, "rabbitmq:{{app.rabbitmq.exchange.activity}}?" +
                        "declare=false&autoDelete=false&mandatory=true&guaranteedDeliveries=true" +
                        "&publisherAcknowledgements=true&passive=true&skipQueueDeclare=true" +
                        "&publisherAcknowledgementsTimeout={{app.rabbitmq.activity.publisherAcknowledgementsTimeout}}" +
                        "&addresses={{app.rabbitmq.connection.host.addresses}}" +
                        "&username=" + rabbitMQUserName +
                        "&password=" + rabbitMQPassword +
                        "&vhost={{app.rabbitmq.connection.virtualhost}}&requestTimeout={{app.rabbitmq.activity.requestTimeout}}")
                .end()
                .log(LoggingLevel.INFO,"Activity Status request message sent successfully")
                .process(activityResponseProcessor).id("RT_Activity_Process_02")
                .marshal().json(JsonLibrary.Jackson);


        logger.info("Activity Status router RT_Activity_01 started.");
    }
}

