package com.wu.compliance.iwatch.orchestrator.entity.lookup.processor;

import com.westernunion.entityservice.EntityDetailsRequest;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class EntityLookupRequestProcessor implements Processor {

    @Value("${secret.cmtcmpl.iwatchx.rtra.entitylookup.username}")
    public String clientId;

    @Value("${secret.cmtcmpl.iwatchx.rtra.entitylookup.password}")
    public String clientPassword;

    @Value("${app.entity-lookup.version.number}")
    public String versionNumber;

    @Override
    public void process(Exchange exchange) {
        EntityDetailsRequest entityDetailsRequest = exchange.getIn().getBody(EntityDetailsRequest.class);
        entityDetailsRequest.setClientId(clientId);
        entityDetailsRequest.setClientPwd(clientPassword);
        entityDetailsRequest.setVersionNumber(versionNumber);
        entityDetailsRequest.setReferenceType("MTCN");
        entityDetailsRequest.setReferenceNumber(this.fetch10DigitMtcn(entityDetailsRequest.getReferenceNumber()));
        exchange.getIn().setBody(entityDetailsRequest);
    }

    public String fetch10DigitMtcn(String mtcn) {
        mtcn = ObjectUtils.defaultIfNull(mtcn, "");
        if (mtcn.length() == 16) {
            return StringUtils.right(mtcn, 10);
        }
        return mtcn;
    }
}
