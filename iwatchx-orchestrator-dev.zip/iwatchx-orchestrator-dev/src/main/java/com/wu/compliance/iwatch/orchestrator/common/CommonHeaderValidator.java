package com.wu.compliance.iwatch.orchestrator.common;

import com.networknt.schema.JsonSchema;
import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import com.wu.compliance.iwatch.microcommonapi.dto.CommonHeaderDto;
import com.wu.compliance.iwatch.microcommonapi.dto.CommonHeaderDtoBuilder;
import com.wu.compliance.iwatch.microcommonapi.json.JacksonObjectWriter;
import com.wu.compliance.iwatch.microcommonapi.jsonschema.validation.JsonSchemaValidator;
import com.wu.compliance.iwatch.microcommonapi.jsonschema.validation.ValidationResult;
import io.vavr.control.Try;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class CommonHeaderValidator {

    Logger logger = LogManager.getLogger(this.getClass());

    private final JsonSchemaValidator jsonSchemaValidator;
    private final JacksonObjectWriter jacksonObjectWriter;

    public CommonHeaderValidator(JsonSchemaValidator jsonSchemaValidator, JacksonObjectWriter jacksonObjectWriter) {
        this.jsonSchemaValidator = jsonSchemaValidator;
        this.jacksonObjectWriter = jacksonObjectWriter;
    }

    public ValidationResult validate(Exchange exchange, JsonSchema jsonSchema) {
        CommonHeaderDto commonHeader = new CommonHeaderDtoBuilder()
                .tenantpid((String) exchange.getIn().getHeader(HeaderKey.TENANT_PID.getValue()))
                .tenantsid((String) exchange.getIn().getHeader(HeaderKey.TENANT_SID.getValue()))
                .genre((String) exchange.getIn().getHeader(HeaderKey.GENRE.getValue()))
                .bizgrp((String) exchange.getIn().getHeader(HeaderKey.BUSINESS_GROUP.getValue()))
                .invgrp((String) exchange.getIn().getHeader(HeaderKey.INVESTIGATIVE_GROUP.getValue()))
                .userid((String) exchange.getIn().getHeader(HeaderKey.USER_ID.getValue()))
                .username((String) exchange.getIn().getHeader(HeaderKey.USER_NAME.getValue()))
                .useremail((String) exchange.getIn().getHeader(HeaderKey.USER_EMAIL.getValue()))
                .correlationId((String) exchange.getIn().getHeader(HeaderKey.CORRELATION_ID.getValue()))
                .createCommonHeaderDto();


        String payload = Try.of(() -> jacksonObjectWriter.writeValueAsString(commonHeader))
                .onFailure(ex -> logger.error("Error while converting request header to string",
                        ExceptionUtils.getStackTrace(ex)))
                .getOrElse("");

        ValidationResult validationResult = jsonSchemaValidator.validate(jsonSchema, payload);

        return validationResult;
    }
}
