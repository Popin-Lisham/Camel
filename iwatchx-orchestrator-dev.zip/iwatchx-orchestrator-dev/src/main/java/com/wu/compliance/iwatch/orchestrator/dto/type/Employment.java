package com.wu.compliance.iwatch.orchestrator.dto.type;

public class Employment {
	private String industry;
	
	private String status;

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
