package com.wu.compliance.iwatch.orchestrator.dto.type;


public class HitSide {
 
    private String value;
    private Integer index;

    public Integer getIndex() {
        return index;
    }
    public void setIndex(Integer index) {
        this.index = index;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
}
