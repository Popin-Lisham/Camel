package com.wu.compliance.iwatch.orchestrator.accountmanagement.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class CustomerOnboardingCaseResolutionResponseProcessor implements Processor {

  Logger logger = LogManager.getLogger(this.getClass());

  @Override
  public void process(Exchange exchange) throws Exception{
      Object customerOnboardingCaseResolutionResponse = exchange.getIn().getBody(Object.class);
      exchange.getIn().setBody(customerOnboardingCaseResolutionResponse);
  }
}
