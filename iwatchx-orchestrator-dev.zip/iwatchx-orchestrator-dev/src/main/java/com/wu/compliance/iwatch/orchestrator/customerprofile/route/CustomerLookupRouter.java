package com.wu.compliance.iwatch.orchestrator.customerprofile.route;

import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.customerprofile.processor.CustomerProfileLookupExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.customerprofile.processor.CustomerProfileLookupRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.customerprofile.processor.CustomerProfileLookupResponseProcessor;
import com.wu.compliance.iwatch.orchestrator.dto.request.LookupCustomerProfileRequestDto;
import org.apache.camel.ExchangePattern;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestParamType;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.concurrent.TimeoutException;


@Component()
public class CustomerLookupRouter extends RouteBuilder {
    Logger logger = LogManager.getLogger(this.getClass());

    private final CustomerProfileLookupExceptionProcessor cpiLookupExceptionProcessor;

    private final CustomerProfileLookupRequestProcessor customerProfileLookupRequestProcessor;

    private final CustomerProfileLookupResponseProcessor customerProfileLookupResponseProcessor;
    private final SanitizationProcessor sanitizationProcessor;
    private final XssDataExceptionProcessor xssDataExceptionProcessor;

    public CustomerLookupRouter(CustomerProfileLookupExceptionProcessor cpiLookupExceptionProcessor,
                                CustomerProfileLookupRequestProcessor customerProfileLookupRequestProcessor,
                                CustomerProfileLookupResponseProcessor customerProfileLookupResponseProcessor,
                                SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor) {
        Objects.requireNonNull(customerProfileLookupRequestProcessor, "cpiLookupRequestProcessor is null");
        Objects.requireNonNull(cpiLookupExceptionProcessor, "cpiLookupExceptionProcessor is null");
        Objects.requireNonNull(customerProfileLookupResponseProcessor, "cpiLookupResponseProcessor is null");
        Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
        Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");

        this.cpiLookupExceptionProcessor = cpiLookupExceptionProcessor;
        this.customerProfileLookupRequestProcessor = customerProfileLookupRequestProcessor;
        this.customerProfileLookupResponseProcessor = customerProfileLookupResponseProcessor;
        this.sanitizationProcessor = sanitizationProcessor;
        this.xssDataExceptionProcessor = xssDataExceptionProcessor;
    }


    @Override
    public void configure() throws Exception {
        interceptSendToEndpoint("direct:route-cpi-customer-profile-lookup-input")
                .process(sanitizationProcessor);

        onException(Exception.class)
                .handled(true)
                .process(cpiLookupExceptionProcessor);

        onException(HttpHostConnectException.class, TimeoutException.class)
                .handled(true)
                .maximumRedeliveries("{{app.context.retry.count}}").redeliveryDelay("{{app.context.retry.delay}}")
                .retryAttemptedLogLevel(LoggingLevel.WARN)
                .process(cpiLookupExceptionProcessor);

        onException(XssDataException.class)
                .handled(true)
                .process(xssDataExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        rest().tag("CPI Post Customer Profile")
                .description("CPI Customer Profile lookup from Pharos")
                .post("{{app.context.cpi.customer.lookup.post}}")
                .produces("application/json")
                .consumes("application/json")
                .type(LookupCustomerProfileRequestDto.class)
                .param().name("x-wu-externalRefId").type(RestParamType.header).dataType("string").description("External Ref Id.").required(true).endParam()
                .param().name("Authorization").type(RestParamType.header).dataType("string").description("AuthToken").required(true).endParam()
                .param().name("x-api-key").type(RestParamType.header).dataType("string").description("API Key").required(true).endParam()
                .clientRequestValidation(true)
                .to("direct:route-cpi-customer-profile-lookup-input");

        from("direct:route-cpi-customer-profile-lookup-input")
                .routeId("Customer_Profile_Lookup_v2_ID1")
                .setExchangePattern(ExchangePattern.InOut)
                .unmarshal().json(JsonLibrary.Jackson, LookupCustomerProfileRequestDto.class)
                .log("Request header info is   ${headers}")
                .log(LoggingLevel.INFO, "${body}")
                .to("direct:route-cpi-customer-profile-lookup");

        from("direct:route-cpi-customer-profile-lookup")
                .streamCaching()
                .process(customerProfileLookupRequestProcessor)
                .marshal().json(JsonLibrary.Jackson)
                .log(LoggingLevel.INFO, "Request is routed to RAC for customer profile lookup search request.")
                .to("{{app.cpi.customer.interface.lookup.service.url}}")
                .to("direct:route-cpi-customer-profile-lookup-response");

        from("direct:route-cpi-customer-profile-lookup-response")
                .id("Customer_Profile_Lookup_V2_ID2")
                .process(customerProfileLookupResponseProcessor).end();

        logger.info("RAC Customer Profile lookup search router started.");
    }
}
