package com.wu.compliance.iwatch.orchestrator.dto.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.wu.compliance.iwatch.orchestrator.dto.type.Customer;
import com.wu.compliance.iwatch.orchestrator.dto.type.HitsInfo;

public class CaseRequestDto {

    private ActivityTypeDto activityType;

    private SubjectDto subject;

    private String activityRefNo;

    private String actTimestamp;

    private String transactionSide;

    private String attemptId;

    private String tranSurKey;

    private String hitSide;

    private Integer riskLevel;
    private List<String> triggeringPurpose;
    private String triggeringEvent;

    private List<String> qualifiers;
    
    @JsonInclude(Include.NON_NULL)
    private Customer customerID;
    
    @JsonInclude(Include.NON_NULL)
    private HitsInfo hitsInfo;

    private List<Link> links;

    public SubjectDto getSubject() {
        return subject;
    }

    public void setSubject(SubjectDto subject) {
        this.subject = subject;
    }

    public String getActivityRefNo() {
        return activityRefNo;
    }

    public void setActivityRefNo(String activityRefNo) {
        this.activityRefNo = activityRefNo;
    }

    public String getActTimestamp() {
        return actTimestamp;
    }

    public void setActTimestamp(String actTimestamp) {
        this.actTimestamp = actTimestamp;
    }

    public String getTransactionSide() {
        return transactionSide;
    }

    public void setTransactionSide(String transactionSide) {
        this.transactionSide = transactionSide;
    }

    public String getAttemptId() {
        return attemptId;
    }

    public void setAttemptId(String attemptId) {
        this.attemptId = attemptId;
    }

    public String getTranSurKey() {
        return tranSurKey;
    }

    public void setTranSurKey(String tranSurKey) {
        this.tranSurKey = tranSurKey;
    }

    public ActivityTypeDto getActivityType() {
        return activityType;
    }

    public void setActivityType(ActivityTypeDto activityType) {
        this.activityType = activityType;
    }

    public String getHitSide() {
        return hitSide;
    }

    public void setHitSide(String hitSide) {
        this.hitSide = hitSide;
    }

    public Integer getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(Integer riskLevel) {
        this.riskLevel = riskLevel;
    }

    public List<String> getQualifiers() {
        return qualifiers;
    }

    public void setQualifiers(List<String> qualifiers) {
        this.qualifiers = qualifiers;
    }

	public Customer getCustomerID() {
		return customerID;
	}

	public void setCustomerID(Customer customerID) {
		this.customerID = customerID;
	}

	public HitsInfo getHitsInfo() {
		return hitsInfo;
	}

	public void setHitsInfo(HitsInfo hitsInfo) {
		this.hitsInfo = hitsInfo;
	}
    public List<String> getTriggeringPurpose() {
        return triggeringPurpose;
    }

    public void setTriggeringPurpose(List<String> triggeringPurpose) {
        this.triggeringPurpose = triggeringPurpose;
    }

    public String getTriggeringEvent() {
        return triggeringEvent;
    }

    public void setTriggeringEvent(String triggeringEvent) {
        this.triggeringEvent = triggeringEvent;
    }

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }
}
