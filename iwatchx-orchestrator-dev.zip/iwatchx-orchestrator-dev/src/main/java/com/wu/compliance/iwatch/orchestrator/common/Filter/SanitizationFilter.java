package com.wu.compliance.iwatch.orchestrator.common.Filter;

import com.google.gson.GsonBuilder;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import org.apache.catalina.connector.RequestFacade;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import javax.servlet.*;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.util.List;

import static com.wu.compliance.iwatch.microcommonapi.web.UnsanitizedInputResponseBuilder.buildUnsanitizedInputResponse;

@Component
public class SanitizationFilter implements Filter {

    private List<String> xssBlackList;
    Logger logger = LogManager.getLogger(this.getClass());

    public SanitizationFilter(@Value("#{'${app.security.xss.blacklist}'.split(',')}") List<String> xssBlackList) {
        this.xssBlackList = xssBlackList;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        String requestUri = URLDecoder.decode(((RequestFacade) request).getRequestURI(), Charset.defaultCharset());

        for (String xss : xssBlackList) {
            if (requestUri != null && requestUri.contains(xss)) {
                logger.error("Request URI contains unsanitized data");
                DefaultResponse errorResponse = buildUnsanitizedInputResponse("Request was rejected because the URI contains untrusted data",
                                                    "WUIWXXXXX4007", null);
                HttpServletResponse httpServletResponse = (HttpServletResponse) response;
                httpServletResponse.setStatus(HttpStatus.BAD_REQUEST.value());
                PrintWriter out = response.getWriter();
                httpServletResponse.setContentType("application/json");
                out.print(new GsonBuilder().serializeNulls().create().toJson(errorResponse));
                out.flush();
                return;
            }
        }

        chain.doFilter(request, response);

    }
}
