package com.wu.compliance.iwatch.orchestrator.dto.request;

import org.springframework.validation.annotation.Validated;

/**
 * This model represents Entity Id Extension.
 */

public class EntityIdExtensionDto {
	private String entityId;
	private String isTrueMatch;
	public String getEntityId() {
		return entityId;
	}
	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}
	public String getIsTrueMatch() {
		return isTrueMatch;
	}
	public void setIsTrueMatch(String isTrueMatch) {
		this.isTrueMatch = isTrueMatch;
	}
	
}
