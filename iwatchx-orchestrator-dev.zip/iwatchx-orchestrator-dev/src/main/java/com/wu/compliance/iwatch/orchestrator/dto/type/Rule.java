package com.wu.compliance.iwatch.orchestrator.dto.type;

import java.util.List;

public class Rule {
	private List<Doc> docs;
	private List<Attr> attr;
	
	public List<Doc> getDocs() {
		return docs;
	}
	public void setDocs(List<Doc> docs) {
		this.docs = docs;
	}
	public List<Attr> getAttr() {
		return attr;
	}
	public void setAttr(List<Attr> attr) {
		this.attr = attr;
	}
	
}
