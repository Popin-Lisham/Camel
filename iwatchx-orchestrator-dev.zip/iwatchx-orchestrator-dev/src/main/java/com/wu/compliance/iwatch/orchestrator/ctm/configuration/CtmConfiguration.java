package com.wu.compliance.iwatch.orchestrator.ctm.configuration;

import com.example.xmlns._1482216288989.GSIServicesV10;
import org.apache.camel.component.cxf.CxfEndpoint;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CtmConfiguration {
    @Bean(name = "ctmTibcoGSIServiceCxfEndpoint")
    @ConfigurationProperties(prefix = "cxf-ctm-gsi")
    public CxfEndpoint ctmGSICxfEndpoint() {
        CxfEndpoint cxfEndpoint = new CxfEndpoint();
        cxfEndpoint.setServiceClass(GSIServicesV10.class);
        return cxfEndpoint;
    }
}
