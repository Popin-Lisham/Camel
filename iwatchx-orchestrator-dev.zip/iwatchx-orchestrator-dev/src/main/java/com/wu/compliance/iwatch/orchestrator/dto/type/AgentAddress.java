package com.wu.compliance.iwatch.orchestrator.dto.type;

public class AgentAddress {
	private Location country;
	private Location state;

	public Location getCountry() {
		return country;
	}

	public void setCountry(Location country) {
		this.country = country;
	}

	public Location getState() {
		return state;
	}

	public void setState(Location state) {
		this.state = state;
	}
}
