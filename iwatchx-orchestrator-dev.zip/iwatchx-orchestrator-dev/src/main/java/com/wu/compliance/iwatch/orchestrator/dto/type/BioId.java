package com.wu.compliance.iwatch.orchestrator.dto.type;

public class BioId {
	private String issuingState;
	private String number;
	private String expiryDate;
	private BioIdType type;
	private String issuer;
	private String issuingCountry;
	private String issueDate;
	private boolean primary;

	public void setIssuingState(String issuingState){
		this.issuingState = issuingState;
	}

	public String getIssuingState(){
		return issuingState;
	}

	public void setNumber(String number){
		this.number = number;
	}

	public String getNumber(){
		return number;
	}

	public void setExpiryDate(String expiryDate){
		this.expiryDate = expiryDate;
	}

	public String getExpiryDate(){
		return expiryDate;
	}

	public void setType(BioIdType type){
		this.type = type;
	}

	public BioIdType getType(){
		return type;
	}

	public void setIssuer(String issuer){
		this.issuer = issuer;
	}

	public String getIssuer(){
		return issuer;
	}

	public void setIssuingCountry(String issuingCountry){
		this.issuingCountry = issuingCountry;
	}

	public String getIssuingCountry(){
		return issuingCountry;
	}

	public void setIssueDate(String issueDate){
		this.issueDate = issueDate;
	}

	public String getIssueDate(){
		return issueDate;
	}

	public boolean isPrimary() {
		return primary;
	}

	public void setPrimary(boolean primary) {
		this.primary = primary;
	}
}
