package com.wu.compliance.iwatch.orchestrator.dto.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;



/**
 * This is the request model for Update Verification Flags service.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdateVerificationFlagsRequestDto {
	
	private HeaderDto header;

	private String customerUmn;

	private String galacticId;
	
	private String verificationType;

	private String channel;

	
	private List<ComplianceFlagDto> flagStatusList;

	
	private List<IdDto> idvvStatusList;

	@Override
	public String toString() {
		return "UpdateVerificationFlagsRequestDto{" +
				"header=" + header +
				", customerUmn='" + customerUmn + '\'' +
				", galacticId='" + galacticId + '\'' +
				", verificationType='" + verificationType + '\'' +
				", channel='" + channel + '\'' +
				", flagStatusList=" + flagStatusList +
				", idvvStatusList=" + idvvStatusList +
				", kycDetailList=" + kycDetailList +
				", journeyFacts=" + journeyFacts +
				'}';
	}

	private List<KycDetail> kycDetailList;

	public List<KycDetail> getKycDetailList() {
		return kycDetailList;
	}

	public void setKycDetailList(List<KycDetail> kycDetailList) {
		this.kycDetailList = kycDetailList;
	}

	private KeyValueMapDto journeyFacts;

	public KeyValueMapDto getJourneyFacts() {return journeyFacts;}

	public void setJourneyFacts(KeyValueMapDto journeyFacts) {this.journeyFacts = journeyFacts;}

	public HeaderDto getHeader() {
		return header;
	}


	public void setHeader(HeaderDto header) {
		this.header = header;
	}


	public String getCustomerUmn() {
		return customerUmn;
	}


	public void setCustomerUmn(String customerUmn) {
		this.customerUmn = customerUmn;
	}


	public String getGalacticId() {
		return galacticId;
	}


	public void setGalacticId(String galacticId) {
		this.galacticId = galacticId;
	}


	public String getVerificationType() {
		return verificationType;
	}


	public void setVerificationType(String verificationType) {
		this.verificationType = verificationType;
	}


	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}


	public List<ComplianceFlagDto> getFlagStatusList() {
		return flagStatusList;
	}


	public void setFlagStatusList(List<ComplianceFlagDto> flagStatusList) {
		this.flagStatusList = flagStatusList;
	}


	public List<IdDto> getIdvvStatusList() {
		return idvvStatusList;
	}


	public void setIdvvStatusList(List<IdDto> idvvStatusList) {
		this.idvvStatusList = idvvStatusList;
	}
	
	

}
