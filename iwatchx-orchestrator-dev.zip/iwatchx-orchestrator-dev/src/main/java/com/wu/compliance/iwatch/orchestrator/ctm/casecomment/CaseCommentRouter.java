package com.wu.compliance.iwatch.orchestrator.ctm.casecomment;

import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.ctm.casecomment.processor.CaseCommentExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.ctm.casecomment.processor.CaseCommentRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.ctm.casecomment.processor.CaseCommentResponseProcessor;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import wu.ei.cis.csc.core.gsi.xsd.gsi.addcommentsrequest_2016_12.AddCommentsRequest20161212;

import java.util.Objects;
import java.util.concurrent.TimeoutException;

@Component
public class CaseCommentRouter extends RouteBuilder {

    Logger logger = LogManager.getLogger(this.getClass());
    private final CaseCommentRequestProcessor caseCommentRequestProcessor;

    private final CaseCommentResponseProcessor caseCommentResponseProcessor;

    private final CaseCommentExceptionProcessor caseCommentExceptionProcessor;

    private final SanitizationProcessor sanitizationProcessor;

    private final XssDataExceptionProcessor xssDataExceptionProcessor;

    public CaseCommentRouter(CaseCommentRequestProcessor caseCommentRequestProcessor, CaseCommentResponseProcessor caseCommentResponseProcessor, CaseCommentExceptionProcessor caseCommentExceptionProcessor,
                             SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor) {
        Objects.requireNonNull(caseCommentRequestProcessor, "caseCommentRequestProcessor is null");
        Objects.requireNonNull(caseCommentResponseProcessor, "caseCommentResponseProcessor is null");
        Objects.requireNonNull(caseCommentExceptionProcessor, "caseCommentExceptionProcessor is null");
        Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
        Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");
        this.caseCommentRequestProcessor = caseCommentRequestProcessor;
        this.caseCommentResponseProcessor = caseCommentResponseProcessor;
        this.caseCommentExceptionProcessor = caseCommentExceptionProcessor;
        this.sanitizationProcessor = sanitizationProcessor;
        this.xssDataExceptionProcessor = xssDataExceptionProcessor;
    }

    @Override
    public void configure() {

        interceptSendToEndpoint("direct:process-case-comment-input")
                .process(sanitizationProcessor);

        onException(Exception.class)
                .handled(true)
                .process(caseCommentExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(HttpHostConnectException.class, TimeoutException.class)
                .handled(true)
                .maximumRedeliveries("{{app.context.retry.count}}").redeliveryDelay("{{app.context.retry.delay}}")
                .retryAttemptedLogLevel(LoggingLevel.WARN)
                .process(caseCommentExceptionProcessor);

        onException(XssDataException.class)
                .handled(true)
                .process(xssDataExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        rest()
                .tag("Send Case Comment")
                .description("Send Case Comment to CTM")
                .post("{{app.context.case.comment.post}}")
                .consumes("application/text")
                .type(String.class)
                .to("direct:process-case-comment-input");

        from("direct:process-case-comment-input")
                .routeId("CTM_CaseComment_01")
                .streamCaching()
                .unmarshal().json(JsonLibrary.Jackson, AddCommentsRequest20161212.class)
                .process(caseCommentRequestProcessor)
                .setHeader(CxfConstants.OPERATION_NAME, constant("AddComments_v1_0_0"))
                .to("direct:call-ctm-addComment");

        from("direct:call-ctm-addComment")
                .to("cxf:bean:ctmTibcoGSIServiceCxfEndpoint")
                .process(caseCommentResponseProcessor)
                .marshal().json(JsonLibrary.Jackson);


        logger.info("Case Comment router started.");

    }
}
