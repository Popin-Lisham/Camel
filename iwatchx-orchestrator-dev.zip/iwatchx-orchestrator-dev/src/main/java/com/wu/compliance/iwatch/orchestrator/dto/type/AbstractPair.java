package com.wu.compliance.iwatch.orchestrator.dto.type;

public class AbstractPair {
    private String type;
    private String value;

    public void setType(String type){
        this.type = type;
    }

    public String getType(){
        return type;
    }

    public void setValue(String value){
        this.value = value;
    }

    public String getValue(){
        return value;
    }
}
