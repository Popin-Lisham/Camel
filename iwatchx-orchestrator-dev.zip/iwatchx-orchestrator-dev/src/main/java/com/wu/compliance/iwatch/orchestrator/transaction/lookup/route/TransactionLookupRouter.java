package com.wu.compliance.iwatch.orchestrator.transaction.lookup.route;

import com.westernunion.transactionlookupservice.TransactionLookupWSFaultException;
import com.westernunion.transactionlookupservice.TransactionLookupWSRequest;
import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.transaction.lookup.exception.TransactionDetailsNotFoundException;
import com.wu.compliance.iwatch.orchestrator.transaction.lookup.processor.*;
import org.apache.camel.ExchangePattern;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

import javax.xml.bind.UnmarshalException;
import java.util.Objects;

@Component
public class TransactionLookupRouter extends RouteBuilder {

    private final TransactionLookupRequestProcessor transactionLookupRequestProcessor;

    private final TransactionLookupResponseProcessor transactionLookupResponseProcessor;

    private final TransactionLookupExceptionProcessor transactionLookupExceptionProcessor;

    private final TransactionLookupWSFaultExceptionProcessor transactionLookupWSFaultExceptionProcessor;

    private final TransactionDetailsNotFoundExceptionProcessor transactionDetailsNotFoundExceptionProcessor;

    private final TransactionResponseUnmarshalExceptionProcessor transactionResponseUnmarshalExceptionProcessor;

    private final SanitizationProcessor sanitizationProcessor;

    private final XssDataExceptionProcessor xssDataExceptionProcessor;

    public TransactionLookupRouter(TransactionLookupRequestProcessor transactionLookupRequestProcessor, TransactionLookupResponseProcessor transactionLookupResponseProcessor, TransactionLookupExceptionProcessor transactionLookupExceptionProcessor,
                                   TransactionLookupWSFaultExceptionProcessor transactionLookupWSFaultExceptionProcessor, TransactionDetailsNotFoundExceptionProcessor transactionDetailsNotFoundExceptionProcessor,
                                   SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor,
                                   TransactionResponseUnmarshalExceptionProcessor transactionResponseUnmarshalExceptionProcessor) {
        Objects.requireNonNull(transactionLookupRequestProcessor, "transactionLookupRequestProcessor is null");
        Objects.requireNonNull(transactionLookupResponseProcessor, "transactionLookupResponseProcessor is null");
        Objects.requireNonNull(transactionLookupExceptionProcessor, "transactionLookupExceptionProcessor is null");
        Objects.requireNonNull(transactionLookupWSFaultExceptionProcessor, "transactionLookupWSFaultExceptionProcessor is null");
        Objects.requireNonNull(transactionDetailsNotFoundExceptionProcessor, "transactionDetailsNotFoundExceptionProcessor is null");
        Objects.requireNonNull(transactionResponseUnmarshalExceptionProcessor, "transactionUnmarshalExceptionProcessor is null");
        Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
        Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");

        this.transactionLookupRequestProcessor = transactionLookupRequestProcessor;
        this.transactionLookupResponseProcessor = transactionLookupResponseProcessor;
        this.transactionLookupExceptionProcessor = transactionLookupExceptionProcessor;
        this.transactionLookupWSFaultExceptionProcessor = transactionLookupWSFaultExceptionProcessor;
        this.transactionDetailsNotFoundExceptionProcessor = transactionDetailsNotFoundExceptionProcessor;
        this.transactionResponseUnmarshalExceptionProcessor = transactionResponseUnmarshalExceptionProcessor;
        this.sanitizationProcessor = sanitizationProcessor;
        this.xssDataExceptionProcessor = xssDataExceptionProcessor;
    }

    @Override
    public void configure() {

        interceptSendToEndpoint("direct:process-transaction-lookup-input")
                .process(sanitizationProcessor);

        onException(UnmarshalException.class)
                .handled(true)
                .process(transactionResponseUnmarshalExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(TransactionLookupWSFaultException.class)
                .handled(true)
                .process(transactionLookupWSFaultExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(TransactionDetailsNotFoundException.class)
                .handled(true)
                .process(transactionDetailsNotFoundExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(Exception.class)
                .handled(true)
                .process(transactionLookupExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(XssDataException.class)
                .handled(true)
                .process(xssDataExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        rest()
                .tag("Fetch Transaction")
                .description("Fetch transaction information from RTRA lookup service")
                .post("{{app.context.transaction.post}}")
                .consumes("application/text")
                .type(String.class)
                .to("direct:process-transaction-lookup-input");

        from("direct:process-transaction-lookup-input")
                .routeId("RT_transaction_01")
                .streamCaching()
                .unmarshal().json(JsonLibrary.Jackson, TransactionLookupWSRequest.class)
                .process(transactionLookupRequestProcessor)
                .to("direct:call-transaction-lookup");

        from("direct:call-transaction-lookup")
                .log(LoggingLevel.INFO, "Fetching transaction lookup details for activity reference number : ${body.txnMtcn}")
                .to(ExchangePattern.InOut, "cxf:bean:rtraTransactionLookupCxfEndpoint")
                .process(transactionLookupResponseProcessor)
                .marshal().json(JsonLibrary.Jackson);
    }

}