package com.wu.compliance.iwatch.orchestrator.activity.processor;

import com.wu.compliance.iwatch.microcommonapi.jsonschema.validation.ValidationResult;
import com.wu.compliance.iwatch.orchestrator.common.ActivityStatusHeaderSchema;
import com.wu.compliance.iwatch.orchestrator.common.CommonHeaderValidator;
import com.wu.compliance.iwatch.orchestrator.common.CommonValidationException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

@Component
public class ActivityStatusHeaderValidationProcessor implements Processor {

    private final ActivityStatusHeaderSchema activityStatusHeaderSchema;
    private final CommonHeaderValidator commonHeaderValidator;

    public ActivityStatusHeaderValidationProcessor(CommonHeaderValidator commonHeaderValidator, ActivityStatusHeaderSchema activityStatusHeaderSchema) {
        this.commonHeaderValidator = commonHeaderValidator;
        this.activityStatusHeaderSchema = activityStatusHeaderSchema;
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        ValidationResult validationResult = commonHeaderValidator.validate(exchange, activityStatusHeaderSchema.getJsonSchema());
        if (validationResult.isNotValid()) {
            throw new CommonValidationException(validationResult.getErrorDetails(), "The request provided is missing the required header(s).");
        }
    }
}
