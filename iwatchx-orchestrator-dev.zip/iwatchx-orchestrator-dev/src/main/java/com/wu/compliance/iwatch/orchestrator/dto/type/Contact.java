package com.wu.compliance.iwatch.orchestrator.dto.type;

import java.util.List;

public class Contact{
	private List<Phone> phones;
	private String email;

	public void setPhones(List<Phone> phones){
		this.phones = phones;
	}

	public List<Phone> getPhones(){
		return phones;
	}

	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return email;
	}
}