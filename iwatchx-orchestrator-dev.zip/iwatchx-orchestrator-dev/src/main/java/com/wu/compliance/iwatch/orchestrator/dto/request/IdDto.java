package com.wu.compliance.iwatch.orchestrator.dto.request;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;



/**
 * Id
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IdDto {

	private String number;

	private String seqNumber;

	private String type;

	private String issuingAgency;

	private String issuingCountry;

	private String issuingAuthority;

	
	private LocalDate issueDate;

	
	private LocalDate expirationDate;

	private String doesIdHaveExpDate;

	private String doesIdHaveIssueDate;

	
	private IdVerificationDto idVerification;

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getIssuingAgency() {
		return issuingAgency;
	}

	public void setIssuingAgency(String issuingAgency) {
		this.issuingAgency = issuingAgency;
	}

	public String getIssuingCountry() {
		return issuingCountry;
	}

	public void setIssuingCountry(String issuingCountry) {
		this.issuingCountry = issuingCountry;
	}

	public String getIssuingAuthority() {
		return issuingAuthority;
	}

	public void setIssuingAuthority(String issuingAuthority) {
		this.issuingAuthority = issuingAuthority;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(LocalDate expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getDoesIdHaveExpDate() {
		return doesIdHaveExpDate;
	}

	public void setDoesIdHaveExpDate(String doesIdHaveExpDate) {
		this.doesIdHaveExpDate = doesIdHaveExpDate;
	}

	public String getDoesIdHaveIssueDate() {
		return doesIdHaveIssueDate;
	}

	public void setDoesIdHaveIssueDate(String doesIdHaveIssueDate) {
		this.doesIdHaveIssueDate = doesIdHaveIssueDate;
	}

	public IdVerificationDto getIdVerification() {
		return idVerification;
	}

	public void setIdVerification(IdVerificationDto idVerification) {
		this.idVerification = idVerification;
	}
	

}
