package com.wu.compliance.iwatch.orchestrator.common;

import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.wu.compliance.iwatch.orchestrator.dto.response.ResponseBuilder.buildBadRequestResponse;

@Component
public class InvalidHeaderProcessor implements Processor {

    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange) throws Exception {
        CommonValidationException exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, CommonValidationException.class);
        String message = exception.getMessage() + exception.getErrorDetails();
        logger.error(message, exception);
        DefaultResponse errorResponse = buildBadRequestResponse(StringUtils.defaultIfBlank((String) exchange.getIn().getHeader(HeaderKey.CORRELATION_ID.getValue()), UUID.randomUUID().toString()), exception.getErrorDetails());
        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.BAD_REQUEST.value());
        exchange.getIn().setBody(errorResponse);
    }
}
