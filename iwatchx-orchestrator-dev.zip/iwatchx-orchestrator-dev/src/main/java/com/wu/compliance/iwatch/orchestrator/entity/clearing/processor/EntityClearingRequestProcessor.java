package com.wu.compliance.iwatch.orchestrator.entity.clearing.processor;

import com.westernunion.entityservice.EntityClearingRequest;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class EntityClearingRequestProcessor implements Processor {

    @Value("${secret.cmtcmpl.iwatchx.rtra.entitylookup.username}")
    public String clientId;

    @Value("${secret.cmtcmpl.iwatchx.rtra.entitylookup.password}")
    public String clientPassword;

    @Value("${app.entity-lookup.version.number}")
    public String versionNumber;

    @Override
    public void process(Exchange exchange) {
        EntityClearingRequest entityClearingRequest = exchange.getIn().getBody(EntityClearingRequest.class);
        entityClearingRequest.setClientId(clientId);
        entityClearingRequest.setClientPwd(clientPassword);
        entityClearingRequest.setVersionNumber(versionNumber);
        entityClearingRequest.setReferenceType("MTCN");
        entityClearingRequest.setReferenceNumber(this.fetch10DigitMtcn(entityClearingRequest.getReferenceNumber()));
        exchange.getIn().setBody(entityClearingRequest);
    }

    public String fetch10DigitMtcn(String mtcn) {
       mtcn = ObjectUtils.defaultIfNull(mtcn,"");
        if (mtcn.length() == 16) {
            return StringUtils.right(mtcn, 10);
        }
        return mtcn;
    }
}
