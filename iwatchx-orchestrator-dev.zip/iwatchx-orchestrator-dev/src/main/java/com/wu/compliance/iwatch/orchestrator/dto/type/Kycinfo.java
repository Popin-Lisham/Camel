package com.wu.compliance.iwatch.orchestrator.dto.type;

import java.util.List;

public class Kycinfo {

	private String pep;
	
	private List<String> fundsSrc;
	
	private List<String> purpose;
	
	private List<TaxCountry> taxCountries;

	public String getPep() {
		return pep;
	}

	public void setPep(String pep) {
		this.pep = pep;
	}

	public List<String> getFundsSrc() {
		return fundsSrc;
	}

	public void setFundsSrc(List<String> fundsSrc) {
		this.fundsSrc = fundsSrc;
	}

	public List<TaxCountry> getTaxCountries() {
		return taxCountries;
	}

	public void setTaxCountries(List<TaxCountry> taxCountries) {
		this.taxCountries = taxCountries;
	}

	public List<String> getPurpose() {
		return purpose;
	}

	public void setPurpose(List<String> purpose) {
		this.purpose = purpose;
	}
	
	
	
}
