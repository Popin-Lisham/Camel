package com.wu.compliance.iwatch.orchestrator.dto.request;

import java.util.HashMap;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Key value pairs
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class KeyValueMapDto extends HashMap<String, String> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
