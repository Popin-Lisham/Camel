package com.wu.compliance.iwatch.orchestrator.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerProfileDto {

	private String wuCardNumber;
	private String country;
	private String isGlobal;
	private CmpDto cmp;
	
    public String getWuCardNumber() {
		return wuCardNumber;
	}

	public void setWuCardNumber(String wuCardNumber) {
		this.wuCardNumber = wuCardNumber;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getIsGlobal() {
		return isGlobal;
	}

	public void setIsGlobal(String isGlobal) {
		this.isGlobal = isGlobal;
	}

	public CmpDto getCmp() {
		return cmp;
	}

	public void setCmp(CmpDto cmp) {
		this.cmp = cmp;
	}

@Override
  public String toString() {
    return "CustomerProfileDto [wuCardNumber=" + wuCardNumber + ", country=" + country + ", isGlobal=" + isGlobal + ", cmp=" + cmp + "]";
  }
}
