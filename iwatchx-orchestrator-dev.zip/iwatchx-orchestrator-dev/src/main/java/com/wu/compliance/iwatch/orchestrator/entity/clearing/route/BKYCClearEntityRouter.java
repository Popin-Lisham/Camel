package com.wu.compliance.iwatch.orchestrator.entity.clearing.route;

import java.util.Objects;
import java.util.concurrent.TimeoutException;

import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import org.apache.camel.ExchangePattern;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.Resilience4jConfigurationDefinition;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestParamType;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wu.compliance.iwatch.orchestrator.dto.request.EntityClearingRequestDto;
import com.wu.compliance.iwatch.orchestrator.entity.clearing.processor.BKYCEntityClearingExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.entity.clearing.processor.BKYCEntityClearingRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.entity.clearing.processor.BKYCEntityClearingResponseProcessor;

@Component
public class BKYCClearEntityRouter extends RouteBuilder {
	Logger logger = LogManager.getLogger(this.getClass());

	private final BKYCEntityClearingRequestProcessor entityClearingRequestProcessor;

    private final BKYCEntityClearingResponseProcessor entityClearingResponseProcessor;

    private final BKYCEntityClearingExceptionProcessor entityClearingExceptionProcessor;
    
    private final Resilience4jConfigurationDefinition resilience4jConfigurationDefinition;

	private final SanitizationProcessor sanitizationProcessor;

	private final XssDataExceptionProcessor xssDataExceptionProcessor;

    public BKYCClearEntityRouter(BKYCEntityClearingRequestProcessor entityClearingRequestProcessor,
								 BKYCEntityClearingResponseProcessor entityClearingResponseProcessor,
								 BKYCEntityClearingExceptionProcessor entityClearingExceptionProcessor,
								 Resilience4jConfigurationDefinition resilience4jConfigurationDefinition,
								 SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor) {
        Objects.requireNonNull(entityClearingRequestProcessor, "entityClearingRequestProcessor is null");
        Objects.requireNonNull(entityClearingResponseProcessor, "entityClearingResponseProcessor is null");
        Objects.requireNonNull(entityClearingExceptionProcessor, "entityClearingExceptionProcessor is null");
        Objects.requireNonNull(resilience4jConfigurationDefinition, "entityClearingExceptionProcessor is null");
		Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
		Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");
        this.entityClearingRequestProcessor = entityClearingRequestProcessor;
        this.entityClearingResponseProcessor = entityClearingResponseProcessor;
        this.entityClearingExceptionProcessor = entityClearingExceptionProcessor;
        this.resilience4jConfigurationDefinition = resilience4jConfigurationDefinition;
		this.sanitizationProcessor = sanitizationProcessor;
		this.xssDataExceptionProcessor = xssDataExceptionProcessor;
    }

    @Override
    public void configure() {

		interceptSendToEndpoint("direct:route-cj-clear-entity-input")
			.process(sanitizationProcessor);

        onException(Exception.class)
        	.handled(true)
        	.process(entityClearingExceptionProcessor);

        onException(HttpHostConnectException.class, TimeoutException.class)
        	.handled(true)
        	.maximumRedeliveries("{{app.context.retry.count}}").redeliveryDelay("{{app.context.retry.delay}}")
        	.retryAttemptedLogLevel(LoggingLevel.WARN)
        	.process(entityClearingExceptionProcessor);

		onException(XssDataException.class)
				.handled(true)
				.process(xssDataExceptionProcessor)
				.marshal().json(JsonLibrary.Jackson);
        
        rest().tag("Post Clear Entity")
        	.description("Entity clearence from Pharos")
        	.post("{{app.context.rac.clear.entity.post}}")
            .produces("application/json")
            .consumes("application/json")
        	.type(EntityClearingRequestDto.class)
        	.param().name("x-wu-externalRefId").type(RestParamType.header).dataType("string").description("External Ref Id.").required(true).endParam()
        	.param().name("Authorization").type(RestParamType.header).dataType("string").description("AuthToken").required(true).endParam()
        	.param().name("x-api-key").type(RestParamType.header).dataType("string").description("API Key").required(true).endParam()
        	.clientRequestValidation(true)
        	.to("direct:route-cj-clear-entity-input");	
        
        from("direct:route-cj-clear-entity-input")
        	.routeId("CJ_Clear_Entity_01")
        	.setExchangePattern(ExchangePattern.InOut)
        	.unmarshal().json(JsonLibrary.Jackson, EntityClearingRequestDto.class)
        	.log("Request header info is   ${headers}")
        	.log(LoggingLevel.INFO, "${body}")
        	.to("direct:route-cj-clear-entity"); 

        from("direct:route-cj-clear-entity")
        	.streamCaching()
        	.process(entityClearingRequestProcessor)
        	.marshal().json(JsonLibrary.Jackson)
         	.log(LoggingLevel.INFO, "Request is routed to RAC for entity clearing.")
         	.to("{{app.cpi.interface.clear.entity.service.url}}")
         	.to("direct:route-cj-clear-entity-response");
         
        from("direct:route-cj-clear-entity-response")	
        	.id("CJ_Clear_Entity_02")
        	.process(entityClearingResponseProcessor).end();


        logger.info("Clear Entity router started.");
    }
}
