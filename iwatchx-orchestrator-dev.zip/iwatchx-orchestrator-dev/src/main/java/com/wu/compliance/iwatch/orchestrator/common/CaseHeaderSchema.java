package com.wu.compliance.iwatch.orchestrator.common;

import com.wu.compliance.iwatch.microcommonapi.jsonschema.validation.AbstractHeaderSchema;
import org.springframework.stereotype.Component;

@Component
public class CaseHeaderSchema extends AbstractHeaderSchema {
    public CaseHeaderSchema() {
        super("case-header-schema.json");
    }
}
