package com.wu.compliance.iwatch.orchestrator.transaction.lookup.processor;

import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.orchestrator.dto.response.ResponseBuilder;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class TransactionLookupExceptionProcessor implements Processor {
    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange) {
        Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
        logger.error("An error occurred while processing transaction lookup request.", exception);

        DefaultResponse errorResponse = ResponseBuilder.buildExteranlFailureResponse((String) exchange.getIn().getHeader(HeaderKey.CORRELATION_ID.getValue()), "An error occurred while processing transaction lookup request.");

        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.INTERNAL_SERVER_ERROR.value());
        exchange.getIn().setBody(errorResponse);
    }
}
