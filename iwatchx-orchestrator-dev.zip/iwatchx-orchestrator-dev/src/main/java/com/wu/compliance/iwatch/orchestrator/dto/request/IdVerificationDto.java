package com.wu.compliance.iwatch.orchestrator.dto.request;

import java.time.LocalDate;
import java.time.OffsetDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;




/**
 * Defines Id verification details
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class IdVerificationDto {

	private String verificationStatus;

	
	private OffsetDateTime statusDate;

	private String docRefNumber;

	private String source;

	private String mtcn;

	
	private OffsetDateTime txnDate;

	private String ocrFirstName;

	private String ocrLastName;

	private String ocrMiddleName;

	private String ocrName;

	
	private LocalDate ocrDateOfBirth;

	private String ocrNumber;

	private String ocrType;

	private String ocrIssuingAgency;

	private String ocrIssuingCountry;

	
	private LocalDate ocrIssueDate;

	
	private LocalDate ocrExpirationDate;

	private String ocrFirstNameMatch;

	private String ocrLastNameMatch;

	private String ocrMiddleNameMatch;

	private String ocrNameMatch;

	private String ocrDateOfBirthMatch;

	private String ocrNumberMatch;

	private String ocrTypeMatch;

	private String ocrIssuingAgencyMatch;

	private String ocrIssuingCountryMatch;

	private String ocrIssueDateMatch;

	private String ocrExpirationDateMatch;

	
	private VerificationVendorDto vendor1;

	
	private VerificationVendorDto vendor2;


	public String getVerificationStatus() {
		return verificationStatus;
	}


	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}


	public OffsetDateTime getStatusDate() {
		return statusDate;
	}


	public void setStatusDate(OffsetDateTime statusDate) {
		this.statusDate = statusDate;
	}


	public String getDocRefNumber() {
		return docRefNumber;
	}


	public void setDocRefNumber(String docRefNumber) {
		this.docRefNumber = docRefNumber;
	}


	public String getSource() {
		return source;
	}


	public void setSource(String source) {
		this.source = source;
	}


	public String getMtcn() {
		return mtcn;
	}


	public void setMtcn(String mtcn) {
		this.mtcn = mtcn;
	}


	public OffsetDateTime getTxnDate() {
		return txnDate;
	}


	public void setTxnDate(OffsetDateTime txnDate) {
		this.txnDate = txnDate;
	}


	public String getOcrFirstName() {
		return ocrFirstName;
	}


	public void setOcrFirstName(String ocrFirstName) {
		this.ocrFirstName = ocrFirstName;
	}


	public String getOcrLastName() {
		return ocrLastName;
	}


	public void setOcrLastName(String ocrLastName) {
		this.ocrLastName = ocrLastName;
	}


	public String getOcrMiddleName() {
		return ocrMiddleName;
	}


	public void setOcrMiddleName(String ocrMiddleName) {
		this.ocrMiddleName = ocrMiddleName;
	}


	public String getOcrName() {
		return ocrName;
	}


	public void setOcrName(String ocrName) {
		this.ocrName = ocrName;
	}


	public LocalDate getOcrDateOfBirth() {
		return ocrDateOfBirth;
	}


	public void setOcrDateOfBirth(LocalDate ocrDateOfBirth) {
		this.ocrDateOfBirth = ocrDateOfBirth;
	}


	public String getOcrNumber() {
		return ocrNumber;
	}


	public void setOcrNumber(String ocrNumber) {
		this.ocrNumber = ocrNumber;
	}


	public String getOcrType() {
		return ocrType;
	}


	public void setOcrType(String ocrType) {
		this.ocrType = ocrType;
	}


	public String getOcrIssuingAgency() {
		return ocrIssuingAgency;
	}


	public void setOcrIssuingAgency(String ocrIssuingAgency) {
		this.ocrIssuingAgency = ocrIssuingAgency;
	}


	public String getOcrIssuingCountry() {
		return ocrIssuingCountry;
	}


	public void setOcrIssuingCountry(String ocrIssuingCountry) {
		this.ocrIssuingCountry = ocrIssuingCountry;
	}


	public LocalDate getOcrIssueDate() {
		return ocrIssueDate;
	}


	public void setOcrIssueDate(LocalDate ocrIssueDate) {
		this.ocrIssueDate = ocrIssueDate;
	}


	public LocalDate getOcrExpirationDate() {
		return ocrExpirationDate;
	}


	public void setOcrExpirationDate(LocalDate ocrExpirationDate) {
		this.ocrExpirationDate = ocrExpirationDate;
	}


	public String getOcrFirstNameMatch() {
		return ocrFirstNameMatch;
	}


	public void setOcrFirstNameMatch(String ocrFirstNameMatch) {
		this.ocrFirstNameMatch = ocrFirstNameMatch;
	}


	public String getOcrLastNameMatch() {
		return ocrLastNameMatch;
	}


	public void setOcrLastNameMatch(String ocrLastNameMatch) {
		this.ocrLastNameMatch = ocrLastNameMatch;
	}


	public String getOcrMiddleNameMatch() {
		return ocrMiddleNameMatch;
	}


	public void setOcrMiddleNameMatch(String ocrMiddleNameMatch) {
		this.ocrMiddleNameMatch = ocrMiddleNameMatch;
	}


	public String getOcrNameMatch() {
		return ocrNameMatch;
	}


	public void setOcrNameMatch(String ocrNameMatch) {
		this.ocrNameMatch = ocrNameMatch;
	}


	public String getOcrDateOfBirthMatch() {
		return ocrDateOfBirthMatch;
	}


	public void setOcrDateOfBirthMatch(String ocrDateOfBirthMatch) {
		this.ocrDateOfBirthMatch = ocrDateOfBirthMatch;
	}


	public String getOcrNumberMatch() {
		return ocrNumberMatch;
	}


	public void setOcrNumberMatch(String ocrNumberMatch) {
		this.ocrNumberMatch = ocrNumberMatch;
	}


	public String getOcrTypeMatch() {
		return ocrTypeMatch;
	}


	public void setOcrTypeMatch(String ocrTypeMatch) {
		this.ocrTypeMatch = ocrTypeMatch;
	}


	public String getOcrIssuingAgencyMatch() {
		return ocrIssuingAgencyMatch;
	}


	public void setOcrIssuingAgencyMatch(String ocrIssuingAgencyMatch) {
		this.ocrIssuingAgencyMatch = ocrIssuingAgencyMatch;
	}


	public String getOcrIssuingCountryMatch() {
		return ocrIssuingCountryMatch;
	}


	public void setOcrIssuingCountryMatch(String ocrIssuingCountryMatch) {
		this.ocrIssuingCountryMatch = ocrIssuingCountryMatch;
	}


	public String getOcrIssueDateMatch() {
		return ocrIssueDateMatch;
	}


	public void setOcrIssueDateMatch(String ocrIssueDateMatch) {
		this.ocrIssueDateMatch = ocrIssueDateMatch;
	}


	public String getOcrExpirationDateMatch() {
		return ocrExpirationDateMatch;
	}


	public void setOcrExpirationDateMatch(String ocrExpirationDateMatch) {
		this.ocrExpirationDateMatch = ocrExpirationDateMatch;
	}


	public VerificationVendorDto getVendor1() {
		return vendor1;
	}


	public void setVendor1(VerificationVendorDto vendor1) {
		this.vendor1 = vendor1;
	}


	public VerificationVendorDto getVendor2() {
		return vendor2;
	}


	public void setVendor2(VerificationVendorDto vendor2) {
		this.vendor2 = vendor2;
	}
	

}
