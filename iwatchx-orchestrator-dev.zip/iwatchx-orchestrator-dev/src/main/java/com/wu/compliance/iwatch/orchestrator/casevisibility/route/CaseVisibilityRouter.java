package com.wu.compliance.iwatch.orchestrator.casevisibility.route;

import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.casevisibility.processor.CaseVisibilityExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.casevisibility.processor.CaseVisibilityRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.common.CommonHeaderValidationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.CommonValidationException;
import com.wu.compliance.iwatch.orchestrator.common.InvalidHeaderProcessor;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.dto.request.ComplianceCaseActivityDto;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestParamType;
import org.apache.http.conn.HttpHostConnectException;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.concurrent.TimeoutException;

@Component
public class CaseVisibilityRouter extends RouteBuilder {

    private final CaseVisibilityRequestProcessor caseVisibilityRequestProcessor;

    private final CaseVisibilityExceptionProcessor caseVisibilityExceptionProcessor;

    private final InvalidHeaderProcessor invalidHeaderProcessor;

    private final CommonHeaderValidationProcessor commonHeaderValidationProcessor;

    private final SanitizationProcessor sanitizationProcessor;

    private final XssDataExceptionProcessor xssDataExceptionProcessor;

    public CaseVisibilityRouter(CaseVisibilityRequestProcessor caseVisibilityRequestProcessor,
                                CaseVisibilityExceptionProcessor caseVisibilityExceptionProcessor,
                                InvalidHeaderProcessor invalidHeaderProcessor,
                                CommonHeaderValidationProcessor commonHeaderValidationProcessor,
                                SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor) {
        Objects.requireNonNull(caseVisibilityRequestProcessor, "caseVisibilityRequestProcessor is null");
        Objects.requireNonNull(caseVisibilityExceptionProcessor, "caseVisibilityExceptionProcessor is null");
        Objects.requireNonNull(invalidHeaderProcessor, "headerValidationFailedProcessor is null");
        Objects.requireNonNull(commonHeaderValidationProcessor, "headerValidationProvider is null");
        Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
        Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");
        this.caseVisibilityRequestProcessor = caseVisibilityRequestProcessor;
        this.caseVisibilityExceptionProcessor = caseVisibilityExceptionProcessor;
        this.invalidHeaderProcessor = invalidHeaderProcessor;
        this.commonHeaderValidationProcessor = commonHeaderValidationProcessor;
        this.sanitizationProcessor = sanitizationProcessor;
        this.xssDataExceptionProcessor = xssDataExceptionProcessor;
    }

    @Override
    public void configure() {

        interceptSendToEndpoint("direct:visibility-cases")
                .process(sanitizationProcessor)
                .process(commonHeaderValidationProcessor);

        interceptSendToEndpoint("direct:visibility-case-status")
                .process(sanitizationProcessor)
                .process(commonHeaderValidationProcessor);

        onException(CommonValidationException.class)
                .handled(true)
                .process(invalidHeaderProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(Exception.class)
                .handled(true)
                .process(caseVisibilityExceptionProcessor);


        onException(HttpHostConnectException.class, TimeoutException.class)
                .handled(true)
                .maximumRedeliveries("{{app.context.retry.count}}").redeliveryDelay("{{app.context.retry.delay}}")
                .retryAttemptedLogLevel(LoggingLevel.WARN)
                .process(caseVisibilityExceptionProcessor);

        onException(XssDataException.class)
                .handled(true)
                .process(xssDataExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        rest().tag("Fetch case details").description("Fetch cases information")
                .put("{{app.context.visibility.cases.put}}")
                .consumes("application/json")
                .param().name("x-wu-tenantpid").type(RestParamType.header).dataType("string").description("Tenant Primary Id.").required(false).endParam()
                .param().name("x-wu-tenantsid").type(RestParamType.header).dataType("string").description("Tenant Secondary Id.").required(false).endParam()
                .param().name("x-wu-genre").type(RestParamType.header).dataType("string").description("Genre.").required(false).endParam()
                .param().name("x-wu-userid").type(RestParamType.header).dataType("string").description("User Id").required(false).endParam()
                .param().name("x-wu-useremail").type(RestParamType.header).dataType("string").description("User Email").required(false).endParam()
                .param().name("x-wu-username").type(RestParamType.header).dataType("string").description("User Name").required(false).endParam()
                .param().name("x-wu-correlationId").type(RestParamType.header).dataType("string").description("Correlation Id").required(false).endParam()
                .clientRequestValidation(true)
                .type(ComplianceCaseActivityDto.class)
                .to("direct:visibility-cases");

        from("direct:visibility-cases")
                .routeId("RT_Visibility_01")
                .streamCaching()
                .process(caseVisibilityRequestProcessor)
                .to("rest:put:{{app.visibility.case.uri}}?host={{app.visibility.host}}")
                .end()
                .log(LoggingLevel.INFO, "Visibility cases details service request message sent successfully");

        rest().tag("Fetch case status").description("Fetch case status information")
                .get("{{app.context.visibility.case.status.get}}")
                .param().name("x-wu-tenantpid").type(RestParamType.header).dataType("string").description("Tenant Primary Id.").required(false).endParam()
                .param().name("x-wu-tenantsid").type(RestParamType.header).dataType("string").description("Tenant Secondary Id.").required(false).endParam()
                .param().name("x-wu-genre").type(RestParamType.header).dataType("string").description("Genre.").required(false).endParam()
                .param().name("x-wu-userid").type(RestParamType.header).dataType("string").description("User Id").required(false).endParam()
                .param().name("x-wu-useremail").type(RestParamType.header).dataType("string").description("User Email").required(false).endParam()
                .param().name("x-wu-username").type(RestParamType.header).dataType("string").description("User Name").required(false).endParam()
                .param().name("x-wu-correlationId").type(RestParamType.header).dataType("string").description("Correlation Id").required(false).endParam()
                .clientRequestValidation(true)
                .to("direct:visibility-case-status");

        from("direct:visibility-case-status")
                .streamCaching()
                .process(caseVisibilityRequestProcessor)
                .to("rest:get:{{app.visibility.case.status.uri}}?host={{app.visibility.host}}")
                .end()
                .log(LoggingLevel.INFO, "Visibility case status service request message sent successfully");
    }
}
