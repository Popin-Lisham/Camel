package com.wu.compliance.iwatch.orchestrator.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wu.compliance.iwatch.microcommonapi.dto.OffsetDateTimeToString;
import com.wu.compliance.iwatch.microcommonapi.dto.StringToOffsetDateTime;

import java.time.OffsetDateTime;
import java.util.Map;

/**
 * Defines Compliance Flags like ECDD
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ComplianceFlagDto {

	private String wuCardNumber;

	private String country;

	private String isGlobal;

	private String type;

	private String subType;

	@JsonSerialize(converter = OffsetDateTimeToString.class)
   @JsonDeserialize(converter = StringToOffsetDateTime.class)
	private OffsetDateTime expiryDate;

	private String source;

	private String value;

	private String subStatus;

	private Map<String, String> attributes;

	private AuditInfoDto auditInfo;

	public String getWuCardNumber() {
		return wuCardNumber;
	}

	public void setWuCardNumber(String wuCardNumber) {
		this.wuCardNumber = wuCardNumber;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getIsGlobal() {
		return isGlobal;
	}

	public void setIsGlobal(String isGlobal) {
		this.isGlobal = isGlobal;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public OffsetDateTime getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(OffsetDateTime expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public Map<String,String> getAttributes() {
		return attributes;
	}

	public void setAttributes(Map<String,String> attributes) {
		this.attributes = attributes;
	}

	public AuditInfoDto getAuditInfo() {
		return auditInfo;
	}

	public void setAuditInfo(AuditInfoDto auditInfo) {
		this.auditInfo = auditInfo;
	}
	
}
