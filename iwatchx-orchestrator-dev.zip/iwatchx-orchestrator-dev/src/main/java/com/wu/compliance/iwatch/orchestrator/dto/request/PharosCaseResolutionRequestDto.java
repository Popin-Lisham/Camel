package com.wu.compliance.iwatch.orchestrator.dto.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PharosCaseResolutionRequestDto {

	private HeaderDto header;
	private String channel;
	private String source;
	private String galacticId;
	private String verificationType;
	private ComplianceDecisionDto complianceDecision;
	private List<CustomerProfileDto> customerProfile;
	private KeyValueMapDto journeyFacts;

	private List<KycDetail> kycDetailList;

	public List<KycDetail> getKycDetailList() {
		return kycDetailList;
	}

	public void setKycDetailList(List<KycDetail> kycDetailList) {
		this.kycDetailList = kycDetailList;
	}

	public KeyValueMapDto getJourneyFacts() {return journeyFacts;}
	
	public void setJourneyFacts(KeyValueMapDto journeyFacts) {this.journeyFacts = journeyFacts;}


	public HeaderDto getHeader() {
		return header;
	}


	public void setHeader(HeaderDto header) {
		this.header = header;
	}


	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}


	public String getSource() {
		return source;
	}


	public void setSource(String source) {
		this.source = source;
	}


	public String getGalacticId() {
		return galacticId;
	}


	public void setGalacticId(String galacticId) {
		this.galacticId = galacticId;
	}


	public ComplianceDecisionDto getComplianceDecision() {
		return complianceDecision;
	}


	public void setComplianceDecision(ComplianceDecisionDto complianceDecision) {
		this.complianceDecision = complianceDecision;
	}


	public List<CustomerProfileDto> getCustomerProfile() {
		return customerProfile;
	}


	public void setCustomerProfile(List<CustomerProfileDto> customerProfile) {
		this.customerProfile = customerProfile;
	}

	public String getVerificationType() {
		return verificationType;
	}


	public void setVerificationType(String verificationType) {
		this.verificationType = verificationType;
	}


	@Override
	public String toString() {
		return "PharosCaseResolutionRequestDto [header=" + header + ", channel=" + channel + ", source="
				+ source + ", galacticId=" + galacticId + ", verificationType=" + verificationType +
				", complianceDecision=" + complianceDecision + ", customerProfile=" + customerProfile + ",kycDetailList="+ kycDetailList +",]";
	}
}
