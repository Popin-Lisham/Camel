package com.wu.compliance.iwatch.orchestrator.activity.processor;

import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.rabbitmq.RabbitMQConstants;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

@Component
public class ActivityRequestProcessor implements Processor {


       @Override
    public void process(Exchange exchange) throws Exception {
           exchange.getIn().setHeader(RabbitMQConstants.CONTENT_TYPE, MediaType.APPLICATION_JSON);

           exchange.getIn().setHeader("spring_returned_message_correlation",
                   exchange.getIn().getHeader(HeaderKey.CORRELATION_ID.getValue()));
           exchange.getIn().setHeader("rx-wu-tenantpid",
                   exchange.getIn().getHeader(HeaderKey.TENANT_PID.getValue()));
           exchange.getIn().setHeader("rx-wu-tenantsid",
                   exchange.getIn().getHeader(HeaderKey.TENANT_SID.getValue()));
           exchange.getIn().setHeader("rx-wu-userid",
                    exchange.getIn().getHeader(HeaderKey.USER_ID.getValue()));
           exchange.getIn().setHeader("rx-wu-username",
                    exchange.getIn().getHeader(HeaderKey.USER_NAME.getValue()));
           exchange.getIn().setHeader("rx-wu-useremail",
                    exchange.getIn().getHeader(HeaderKey.USER_EMAIL.getValue()));
    }
}
