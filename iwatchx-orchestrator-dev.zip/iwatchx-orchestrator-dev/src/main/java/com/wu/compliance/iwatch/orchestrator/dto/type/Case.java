package com.wu.compliance.iwatch.orchestrator.dto.type;

import java.util.List;

public class Case {
    private Subject subject;
    private HitSide hitSide;
	private List<String> triggeringPurpose;
	private String triggeringEvent;
	public Subject getSubject() {
		return subject;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	public HitSide getHitSide() {
		return hitSide;
	}
	public void setHitSide(HitSide hitSide) {
		this.hitSide = hitSide;
	}
	public List<String> getTriggeringPurpose() {
		return triggeringPurpose;
	}
	public void setTriggeringPurpose(List<String> triggeringPurpose) {
		this.triggeringPurpose = triggeringPurpose;
	}
	public String getTriggeringEvent() {
		return triggeringEvent;
	}
	public void setTriggeringEvent(String triggeringEvent) {
		this.triggeringEvent = triggeringEvent;
	}
}
