package com.wu.compliance.iwatch.orchestrator.dto.response;

/**
 * This is the response model for Entity Clearing service.
 */

public class EntityClearingResponse{

	/**
	 * 
	 */
	private String responseStatus;

	/**
	 * List of Response Messages.
	 */
	public enum ResponseMessageEnum {
		ENTITIES_WHITELISTED_SUCCESSFULLY("ENTITIES_WHITELISTED_SUCCESSFULLY"),

		ENTITY_CLEARING_NOT_SUCCESSFUL_ENTITIES_NOT_PRESENT_IN_SYSTEM(
				"ENTITY_CLEARING_NOT_SUCCESSFUL_ENTITIES_NOT_PRESENT_IN_SYSTEM"),

		WHITELISTED_ENTITIES_HAS_BEEN_REMOVED_SUCCESSFULLY("WHITELISTED_ENTITIES_HAS_BEEN_REMOVED_SUCCESSFULLY"),

		ENTITIES_REVRTED_NOT_SUCCESSFUL_ENTITIES_NOT_PRESENT_IN_SYSTEM(
				"ENTITIES_REVRTED_NOT_SUCCESSFUL_ENTITIES_NOT_PRESENT_IN_SYSTEM");

		private String value;

		ResponseMessageEnum(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return String.valueOf(value);
		}

		public static ResponseMessageEnum fromValue(String text) {
			for (ResponseMessageEnum b : ResponseMessageEnum.values()) {
				if (String.valueOf(b.value).equals(text)) {
					return b;
				}
			}
			return null;
		}
	}

	private ResponseMessageEnum responseMessage;

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public ResponseMessageEnum getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(ResponseMessageEnum responseMessage) {
		this.responseMessage = responseMessage;
	}

}
