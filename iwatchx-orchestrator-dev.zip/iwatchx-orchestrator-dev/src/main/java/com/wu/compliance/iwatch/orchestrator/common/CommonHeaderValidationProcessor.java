package com.wu.compliance.iwatch.orchestrator.common;

import com.wu.compliance.iwatch.microcommonapi.jsonschema.validation.ValidationResult;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class CommonHeaderValidationProcessor implements Processor {

    Logger logger = LogManager.getLogger(this.getClass());

    private final CommonHeaderSchema commonHeaderSchema;
    private final CommonHeaderValidator commonHeaderValidator;

    public CommonHeaderValidationProcessor(CommonHeaderSchema commonHeaderSchema, CommonHeaderValidator commonHeaderValidator) {
        this.commonHeaderSchema = commonHeaderSchema;
        this.commonHeaderValidator = commonHeaderValidator;
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        ValidationResult validationResult = commonHeaderValidator.validate(exchange, commonHeaderSchema.getJsonSchema());
        if (validationResult.isNotValid()) {
            throw new CommonValidationException(validationResult.getErrorDetails(), "The request provided is missing the required header(s).");
        }
    }
}
