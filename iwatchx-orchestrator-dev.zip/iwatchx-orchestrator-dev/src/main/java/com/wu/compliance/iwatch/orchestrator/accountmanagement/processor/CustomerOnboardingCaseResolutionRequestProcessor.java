package com.wu.compliance.iwatch.orchestrator.accountmanagement.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;

@Component
public class CustomerOnboardingCaseResolutionRequestProcessor implements Processor {

  
  @Override
   public void process(Exchange exchange) throws JsonProcessingException {
       exchange.getIn().removeHeader(Exchange.HTTP_URI);
   }

}