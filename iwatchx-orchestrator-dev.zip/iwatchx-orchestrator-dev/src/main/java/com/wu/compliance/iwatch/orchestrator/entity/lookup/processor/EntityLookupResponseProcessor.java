package com.wu.compliance.iwatch.orchestrator.entity.lookup.processor;

import com.westernunion.entityservice.EntityDetailsResponse;
import com.wu.compliance.iwatch.orchestrator.entity.lookup.exception.EntityDataNotFoundException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class EntityLookupResponseProcessor implements Processor {

    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange) throws EntityDataNotFoundException {
        EntityDetailsResponse entityDetailsResponse = exchange.getIn().getBody(EntityDetailsResponse.class);

        if (ObjectUtils.isEmpty(entityDetailsResponse.getEntityHits())) {
            logger.error("No data found from entity lookup service for activity reference number: " +
                    entityDetailsResponse.getHeader().getCorrelationId());

            throw new EntityDataNotFoundException();
        }

        logger.info("Successfully fetched entity details for mtcn : " + entityDetailsResponse.getHeader().getCorrelationId());

        exchange.getIn().setBody(entityDetailsResponse);
    }
}
