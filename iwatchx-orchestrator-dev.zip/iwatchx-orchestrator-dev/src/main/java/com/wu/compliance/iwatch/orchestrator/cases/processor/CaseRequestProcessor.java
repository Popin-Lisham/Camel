package com.wu.compliance.iwatch.orchestrator.cases.processor;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;


@Component
public class CaseRequestProcessor implements Processor {

    @Override
    public void process(Exchange exchange) throws JsonProcessingException {
        exchange.getIn().removeHeader(Exchange.HTTP_URI);
    }
}
