package com.wu.compliance.iwatch.orchestrator.common;

import com.wu.compliance.iwatch.microcommonapi.jsonschema.validation.AbstractHeaderSchema;
import org.springframework.stereotype.Component;

@Component
public class PACaseLookupHeaderSchema extends AbstractHeaderSchema {
    public PACaseLookupHeaderSchema() {
        super("pacaselookup-header-schema.json");
    }
}
