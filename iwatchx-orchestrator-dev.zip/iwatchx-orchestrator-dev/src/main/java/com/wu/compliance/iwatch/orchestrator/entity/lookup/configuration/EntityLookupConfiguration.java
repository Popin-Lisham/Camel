package com.wu.compliance.iwatch.orchestrator.entity.lookup.configuration;

import com.westernunion.entityservice.EntityService;
import org.apache.camel.component.cxf.CxfEndpoint;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EntityLookupConfiguration {

    @Bean(name = "rtraEntityLookupCxfEndpoint")
    @ConfigurationProperties(prefix = "cxf-entity-lookup")
    public CxfEndpoint rtraEntityLookupCxfEndpoint() {
        CxfEndpoint cxfEndpoint = new CxfEndpoint();
        cxfEndpoint.setServiceClass(EntityService.class);
        return cxfEndpoint;
    }

}
