package com.wu.compliance.iwatch.orchestrator.dto.request;


import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * CustomerID
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerIDDto {
	/**
	 * Gets or Sets custIdType
	 */
	public enum CustIdTypeEnum {
		PCP("PCP"),

		GALACTICID("GALACTICID"),

		CUST_HASH("CUST-HASH"),

		PASSPORT("PASSPORT"),

		UMN("UMN");

		private String value;

		CustIdTypeEnum(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return String.valueOf(value);
		}

		public static CustIdTypeEnum fromValue(String text) {
			for (CustIdTypeEnum b : CustIdTypeEnum.values()) {
				if (String.valueOf(b.value).equals(text)) {
					return b;
				}
			}
			return null;
		}
	}

	private CustIdTypeEnum custIdType;
	private String custIdNumber;
	public CustIdTypeEnum getCustIdType() {
		return custIdType;
	}
	public void setCustIdType(CustIdTypeEnum custIdType) {
		this.custIdType = custIdType;
	}
	public String getCustIdNumber() {
		return custIdNumber;
	}
	public void setCustIdNumber(String custIdNumber) {
		this.custIdNumber = custIdNumber;
	}
	
}
