package com.wu.compliance.iwatch.orchestrator.pacaselookup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

@Component
public class PACaseLookupRequestProcessor implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        exchange.getIn().removeHeader(Exchange.HTTP_URI);
    }
}
