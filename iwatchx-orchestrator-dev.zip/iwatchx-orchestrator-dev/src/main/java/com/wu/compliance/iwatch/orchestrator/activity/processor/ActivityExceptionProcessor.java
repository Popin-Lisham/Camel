package com.wu.compliance.iwatch.orchestrator.activity.processor;

import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.wu.compliance.iwatch.orchestrator.dto.response.ResponseBuilder.buildUnknownErrorResponse;

@Component
public class ActivityExceptionProcessor implements Processor {
    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange)  {
        Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
        logger.error(ExceptionUtils.getMessage(exception), exception);
        DefaultResponse errorResponse = buildUnknownErrorResponse(StringUtils.defaultIfBlank((String) exchange.getIn().getHeader(HeaderKey.CORRELATION_ID.getValue()), UUID.randomUUID().toString()), exception.getMessage());
        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.INTERNAL_SERVER_ERROR.value());
        exchange.getIn().setBody(errorResponse);
    }
}