package com.wu.compliance.iwatch.orchestrator.dto.type;

import java.util.List;

public class Party {
	
	private Kycinfo kycinfo;
	private Employment employment;
    private Address address;
    private String gender;
    private String dateOfBirth;
    private List<BioId> bioIds;
    private String type;
    private String countryOfBirth;
    private String cityOfBirth;
    private String subjectId;
    private String nationality;
    private Contact contact;
    private Name name;
    private String category;
    
	public Kycinfo getKycinfo() {
		return kycinfo;
	}
	public void setKycinfo(Kycinfo kycinfo) {
		this.kycinfo = kycinfo;
	}
	public Employment getEmployment() {
		return employment;
	}
	public void setEmployment(Employment employment) {
		this.employment = employment;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public List<BioId> getBioIds() {
		return bioIds;
	}
	public void setBioIds(List<BioId> bioIds) {
		this.bioIds = bioIds;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCountryOfBirth() {
		return countryOfBirth;
	}
	public void setCountryOfBirth(String countryOfBirth) {
		this.countryOfBirth = countryOfBirth;
	}
	public String getCityOfBirth() {
		return cityOfBirth;
	}
	public void setCityOfBirth(String cityOfBirth) {
		this.cityOfBirth = cityOfBirth;
	}
	public String getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public Contact getContact() {
		return contact;
	}
	public void setContact(Contact contact) {
		this.contact = contact;
	}
	public Name getName() {
		return name;
	}
	public void setName(Name name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}

    
}