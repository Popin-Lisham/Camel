package com.wu.compliance.iwatch.orchestrator.dto.request;

import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

/**
 * This model represents Cleared Entity List.
 */
@Validated
public class ClearedEntityDto {

	public enum EntityTypeEnum {
		SENDER("SENDER"), SENDERTP("SENDERTP"), CREDIT("CREDIT"), PAYEE("PAYEE"), COMPANY("COMPANY"), PERSON("PERSON"),
		PEPSENDER("PEPSENDER"), PEPPAYEE("PEPPAYEE");

		private String value;

		EntityTypeEnum(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return String.valueOf(value);
		}

		public static EntityTypeEnum fromValue(String text) {
			for (EntityTypeEnum b : EntityTypeEnum.values()) {
				if (String.valueOf(b.value).equals(text)) {
					return b;
				}
			}
			return null;
		}
	}

	private EntityTypeEnum entityType;

	private String nameTypeCode;

	private String nameIdentifier;

	@Valid
	private List<String> entityIds;

	@Valid
	private List<EntityIdExtensionDto> entityIdExtensions;

	public EntityTypeEnum getEntityType() {
		return entityType;
	}

	public void setEntityType(EntityTypeEnum entityType) {
		this.entityType = entityType;
	}

	public String getNameTypeCode() {
		return nameTypeCode;
	}

	public void setNameTypeCode(String nameTypeCode) {
		this.nameTypeCode = nameTypeCode;
	}

	public String getNameIdentifier() {
		return nameIdentifier;
	}

	public void setNameIdentifier(String nameIdentifier) {
		this.nameIdentifier = nameIdentifier;
	}

	public List<String> getEntityIds() {
		return entityIds;
	}

	public void setEntityIds(List<String> entityIds) {
		this.entityIds = entityIds;
	}

	public List<EntityIdExtensionDto> getEntityIdExtensions() {
		return entityIdExtensions;
	}

	public void setEntityIdExtensions(List<EntityIdExtensionDto> entityIdExtensions) {
		this.entityIdExtensions = entityIdExtensions;
	}
	
}
