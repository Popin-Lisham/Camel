package com.wu.compliance.iwatch.orchestrator.common;

import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import static com.wu.compliance.iwatch.microcommonapi.web.UnsanitizedInputResponseBuilder.buildUnsanitizedInputResponse;

@Component
public class XssDataExceptionProcessor implements Processor {

    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange) throws Exception {
        XssDataException exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, XssDataException.class);
        logger.error(exception.getMessage(), exception);
        DefaultResponse errorResponse = buildUnsanitizedInputResponse(exception.getMessage(), "WUIWXXXXX4007", null);
        exchange.getIn().removeHeaders("*");
        exchange.getIn().setBody(errorResponse);
        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.BAD_REQUEST.value());
        exchange.getIn().setHeader("Content-Security-Policy","default-src 'self';base-uri 'self';block-all-mixed-content;font-src 'self' https: data:;frame-ancestors 'self';img-src 'self' data:;object-src 'none';script-src 'self';script-src-attr 'none';style-src 'self' https: 'unsafe-inline';upgrade-insecure-requests");
        exchange.getIn().setHeader("X-Content-Type-Options","nosniff");
        exchange.getIn().setHeader("Strict-Transport-Security","max-age=15552000; includeSubDomains");
        exchange.getIn().setHeader("X-XSS-Protection","1; mode=block");
    }
}
