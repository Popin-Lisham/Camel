package com.wu.compliance.iwatch.orchestrator.dto.type;

public class Amount{
	private String currency;
	private String value;

	public void setCurrency(String currency){
		this.currency = currency;
	}

	public String getCurrency(){
		return currency;
	}

	public void setValue(String value){
		this.value = value;
	}

	public String getValue(){
		return value;
	}
}
