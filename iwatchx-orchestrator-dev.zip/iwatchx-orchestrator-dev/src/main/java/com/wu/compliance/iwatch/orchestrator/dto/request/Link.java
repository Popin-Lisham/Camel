package com.wu.compliance.iwatch.orchestrator.dto.request;

import java.util.List;

public class Link {
    private String attr;

    private String desc;

    private String hitSide;

    private String type;

    private List<String> triggeringPurpose;

    private String triggeringEvent;

    private List<String> qualifiers;

    public String getAttr() {
        return attr;
    }

    public void setAttr(String attr) {
        this.attr = attr;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getHitSide() {
        return hitSide;
    }

    public void setHitSide(String hitSide) {
        this.hitSide = hitSide;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getTriggeringPurpose() {
        return triggeringPurpose;
    }

    public void setTriggeringPurpose(List<String> triggeringPurpose) {
        this.triggeringPurpose = triggeringPurpose;
    }

    public String getTriggeringEvent() {
        return triggeringEvent;
    }

    public void setTriggeringEvent(String triggeringEvent) {
        this.triggeringEvent = triggeringEvent;
    }

    public List<String> getQualifiers() {
        return qualifiers;
    }

    public void setQualifiers(List<String> qualifiers) {
        this.qualifiers = qualifiers;
    }
}
