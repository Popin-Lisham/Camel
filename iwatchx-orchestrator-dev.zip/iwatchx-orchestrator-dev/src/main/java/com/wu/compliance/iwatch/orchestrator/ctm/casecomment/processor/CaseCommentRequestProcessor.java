package com.wu.compliance.iwatch.orchestrator.ctm.casecomment.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import wu.ei.cis.csc.core.gsi.xsd.gsi.addcommentsrequest_2016_12.AddCommentsRequest20161212;

@Component
public class CaseCommentRequestProcessor  implements Processor {
    Logger logger = LogManager.getLogger(this.getClass());
    @Override
    public void process(Exchange exchange) {
       AddCommentsRequest20161212 addCommentsRequest = exchange.getIn().getBody(AddCommentsRequest20161212.class);
       exchange.getIn().setBody(addCommentsRequest);
       logger.debug("Case Comment request received");
    }
}
