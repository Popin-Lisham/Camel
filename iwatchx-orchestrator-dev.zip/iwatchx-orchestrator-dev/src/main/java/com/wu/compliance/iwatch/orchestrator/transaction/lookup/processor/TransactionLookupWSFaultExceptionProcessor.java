package com.wu.compliance.iwatch.orchestrator.transaction.lookup.processor;

import com.westernunion.transactionlookupservice.TransactionLookupWSFaultException;
import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.microcommonapi.json.JacksonObjectWriter;
import com.wu.compliance.iwatch.orchestrator.dto.response.ResponseBuilder;
import io.vavr.control.Try;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class TransactionLookupWSFaultExceptionProcessor implements Processor {
    private final JacksonObjectWriter jacksonObjectWriter;
    Logger logger = LogManager.getLogger(this.getClass());

    public TransactionLookupWSFaultExceptionProcessor(JacksonObjectWriter jacksonObjectWriter) {
        this.jacksonObjectWriter = jacksonObjectWriter;
    }

    @Override
    public void process(Exchange exchange) {
        logger.error("Fault received from transaction lookup Service");
        Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);

        TransactionLookupWSFaultException transactionLookupWSFaultException = ((TransactionLookupWSFaultException) exception);
        String transactionLookupWSFaultInfo = Try.of(() -> jacksonObjectWriter.writeValueAsString(transactionLookupWSFaultException.getFaultInfo()))
                .onFailure(ex -> logger.error("Error while converting transactionLookupWSFaultInfo to string",
                        ExceptionUtils.getStackTrace(ex)))
                .getOrElse("");

        logger.error("Fault details : " + transactionLookupWSFaultInfo);

        DefaultResponse errorResponse = ResponseBuilder.buildExteranlFailureResponse((String) exchange.getIn().getHeader(HeaderKey.CORRELATION_ID.getValue()), "Fault received from transaction lookup Service : "
                + transactionLookupWSFaultException.getFaultInfo().getErrorCode() +" : "
                + transactionLookupWSFaultException.getFaultInfo().getErrorMessage());

        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.SERVICE_UNAVAILABLE.value());
        exchange.getIn().setBody(errorResponse);
    }
}
