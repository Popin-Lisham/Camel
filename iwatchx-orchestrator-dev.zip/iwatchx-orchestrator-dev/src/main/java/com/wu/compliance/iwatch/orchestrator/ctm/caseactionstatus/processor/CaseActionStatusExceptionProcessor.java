package com.wu.compliance.iwatch.orchestrator.ctm.caseactionstatus.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.http.base.HttpOperationFailedException;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.wu.compliance.iwatch.orchestrator.dto.response.ResponseBuilder.buildUnknownErrorResponse;

@Component
public class CaseActionStatusExceptionProcessor implements Processor {
    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange) throws Exception {
        String errorMsg;
        Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
        if (ExceptionUtils.getRootCause(exception).getClass() == HttpOperationFailedException.class) {
            HttpOperationFailedException httpException = (HttpOperationFailedException) ExceptionUtils.getRootCause(exception);
            if (httpException.getStatusCode() == HttpStatus.NOT_FOUND.value()) {
                errorMsg="Incorrect CTM Action Interface endpoint: \n";
                exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.INTERNAL_SERVER_ERROR.value());
                DefaultResponse errorResponse = buildUnknownErrorResponse(StringUtils.defaultIfBlank((String) exchange.getIn().getHeader(HeaderKey.CORRELATION_ID.getValue()), UUID.randomUUID().toString()), httpException.getMessage());
                ObjectMapper objectMapper = new ObjectMapper();
                exchange.getIn().setBody(objectMapper.writeValueAsString(errorResponse));
            } else {
                errorMsg="Error response from CTM Action Interface Service : \n";
                exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, httpException.getStatusCode());
                exchange.getIn().setBody(httpException.getResponseBody());
            }
            logger.error(errorMsg + httpException.getResponseBody(), httpException);

        } else {
            logger.error(ExceptionUtils.getStackTrace(exception));
            ObjectMapper objectMapper = new ObjectMapper();
            DefaultResponse errorResponse = buildUnknownErrorResponse(StringUtils.defaultIfBlank((String) exchange.getIn().getHeader(HeaderKey.CORRELATION_ID.getValue()), UUID.randomUUID().toString()), exception.getMessage());
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.INTERNAL_SERVER_ERROR.value());
            exchange.getIn().setBody(objectMapper.writeValueAsString(errorResponse));
        }
    }
}
