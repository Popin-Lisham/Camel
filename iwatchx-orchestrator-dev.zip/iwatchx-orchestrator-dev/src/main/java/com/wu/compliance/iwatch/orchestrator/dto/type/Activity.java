package com.wu.compliance.iwatch.orchestrator.dto.type;

import java.time.OffsetDateTime;
import java.util.List;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wu.compliance.iwatch.microcommonapi.dto.OffsetDateTimeToString;
import com.wu.compliance.iwatch.microcommonapi.dto.StringToOffsetDateTime;

public class Activity {
	private List<Party> parties;
	private List<Attribute> attributes;

	@JsonSerialize(converter = OffsetDateTimeToString.class)
	@JsonDeserialize(converter = StringToOffsetDateTime.class)
	private OffsetDateTime actTimestamp;

	private String refId;
	private Type type;
	private Info info;

	public void setParties(List<Party> parties) {
		this.parties = parties;
	}
	public List<Party> getParties() {
		return parties;
	}
	public void setAttributes(List<Attribute> attributes) {
		this.attributes = attributes;
	}
	public List<Attribute> getAttributes() {
		return attributes;
	}
	public void setActTimestamp(OffsetDateTime actTimestamp) {
		this.actTimestamp = actTimestamp;
	}
	public OffsetDateTime getActTimestamp() {
		return actTimestamp;
	}
	public void setRefId(String refId) {
		this.refId = refId;
	}
	public String getRefId() {
		return refId;
	}
	public void setType(Type type) {
		this.type = type;
	}
	public Type getType() {
		return type;
	}
	public void setInfo(Info info) {
		this.info = info;
	}
	public Info getInfo() {
		return info;
	}
}