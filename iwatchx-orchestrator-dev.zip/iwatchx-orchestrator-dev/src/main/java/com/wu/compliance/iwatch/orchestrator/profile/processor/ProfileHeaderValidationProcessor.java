package com.wu.compliance.iwatch.orchestrator.profile.processor;

import com.wu.compliance.iwatch.microcommonapi.jsonschema.validation.ValidationResult;
import com.wu.compliance.iwatch.orchestrator.common.CommonHeaderValidator;
import com.wu.compliance.iwatch.orchestrator.common.CommonValidationException;
import com.wu.compliance.iwatch.orchestrator.common.ProfileHeaderSchema;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class ProfileHeaderValidationProcessor implements Processor {

    Logger logger = LogManager.getLogger(this.getClass());

    private final ProfileHeaderSchema profileHeaderSchema;
    private final CommonHeaderValidator commonHeaderValidator;

    public ProfileHeaderValidationProcessor(ProfileHeaderSchema profileHeaderSchema, CommonHeaderValidator commonHeaderValidator) {
        this.profileHeaderSchema = profileHeaderSchema;
        this.commonHeaderValidator = commonHeaderValidator;
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        logger.info("Profile attachment request received");
        ValidationResult validationResult = commonHeaderValidator.validate(exchange, profileHeaderSchema.getJsonSchema());
        if (!validationResult.isValid()) {
            throw new CommonValidationException(validationResult.getErrorDetails(), "The request provided is missing the required header(s).");
        }
        logger.info("Header validation passed");
    }
}
