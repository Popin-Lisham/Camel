package com.wu.compliance.iwatch.orchestrator.dto.request;


public class ComplianceCaseActivityDto {

    private String activityRefId;

    private String activityType;

    public String getActivityRefId() {
        return activityRefId;
    }

    public void setActivityRefId(String activityRefId) {
        this.activityRefId = activityRefId;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }
}
