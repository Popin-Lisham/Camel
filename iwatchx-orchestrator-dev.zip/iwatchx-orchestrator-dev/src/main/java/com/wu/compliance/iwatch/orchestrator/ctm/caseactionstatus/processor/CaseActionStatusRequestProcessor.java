package com.wu.compliance.iwatch.orchestrator.ctm.caseactionstatus.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class CaseActionStatusRequestProcessor implements Processor {
    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange) {
        exchange.getIn().removeHeader(Exchange.HTTP_URI);

        logger.info("Case action status request received");
    }
}
