package com.wu.compliance.iwatch.orchestrator.dto.request;

public class AbstractAttachmentQuality {
    private String status;
    private String refId;
    private ReasonDto reason;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public ReasonDto getReason() {
        return reason;
    }

    public void setReason(ReasonDto reason) {
        this.reason = reason;
    }
}
