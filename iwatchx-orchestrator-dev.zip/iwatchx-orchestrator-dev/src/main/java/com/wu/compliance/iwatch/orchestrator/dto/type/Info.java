package com.wu.compliance.iwatch.orchestrator.dto.type;

public class Info{
	private Amount amount;
	private AgentAddress destination;
	private AgentAddress source;

	public void setAmount(Amount amount){
		this.amount = amount;
	}

	public Amount getAmount(){
		return amount;
	}

	public void setDestination(AgentAddress destination){
		this.destination = destination;
	}

	public AgentAddress getDestination(){
		return destination;
	}

	public void setSource(AgentAddress source){
		this.source = source;
	}

	public AgentAddress getSource(){
		return source;
	}
}
