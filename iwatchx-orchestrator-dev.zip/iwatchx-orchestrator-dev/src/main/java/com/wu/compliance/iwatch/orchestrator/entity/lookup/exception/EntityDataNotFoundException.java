package com.wu.compliance.iwatch.orchestrator.entity.lookup.exception;

public class EntityDataNotFoundException extends Exception {
}
