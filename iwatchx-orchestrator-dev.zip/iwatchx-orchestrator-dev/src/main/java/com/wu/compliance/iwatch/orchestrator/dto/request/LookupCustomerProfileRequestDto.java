package com.wu.compliance.iwatch.orchestrator.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class LookupCustomerProfileRequestDto extends LookupCustomerRequestDto{

    private String dateOfBirth;
    private Name name;

    private String galacticId;

    private String lookupType;

    private String customerUmn;

    private String channel;

    private String idNumber;

    private Character idType;

    private String bankProfileId;

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public void setGalacticId(String galacticId) {
        this.galacticId = galacticId;
    }

    public void setLookupType(String lookupType) {
        this.lookupType = lookupType;
    }

    public void setCustomerUmn(String customerUmn) {
        this.customerUmn = customerUmn;
    }

    @Override
    public void setChannel(String channel) {
        this.channel = channel;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public void setIdType(Character idType) {
        this.idType = idType;
    }

    public void setBankProfileId(String bankProfileId) {
        this.bankProfileId = bankProfileId;
    }



    public LookupCustomerProfileRequestDto() {
    }


    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public String getGalacticId() {
        return galacticId;
    }

    public String getLookupType() {
        return lookupType;
    }

    public String getCustomerUmn() {
        return customerUmn;
    }

    @Override
    public String getChannel() {
        return channel;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public Character getIdType() {
        return idType;
    }

    public Name getName() {
       return name;
    }

    public String getBankProfileId(){
        return bankProfileId;
    }

}
