package com.wu.compliance.iwatch.orchestrator.dto.type;

import java.util.List;

public class HitsInfo{
	private List<Entity> entities;
	private List<Rule> rules;
	
	public List<Entity> getEntities() {
		return entities;
	}
	public void setEntities(List<Entity> entities) {
		this.entities = entities;
	}
	public List<Rule> getRules() {
		return rules;
	}
	public void setRules(List<Rule> rules) {
		this.rules = rules;
	}
	
}