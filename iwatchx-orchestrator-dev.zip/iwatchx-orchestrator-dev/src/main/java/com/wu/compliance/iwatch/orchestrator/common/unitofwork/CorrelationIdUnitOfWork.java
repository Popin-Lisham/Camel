package com.wu.compliance.iwatch.orchestrator.common.unitofwork;

import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import org.apache.camel.AsyncCallback;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.impl.engine.DefaultUnitOfWork;
import org.slf4j.MDC;

public class CorrelationIdUnitOfWork extends DefaultUnitOfWork {

    public CorrelationIdUnitOfWork(Exchange exchange) {
        super(exchange);
    }

    @Override
    public AsyncCallback beforeProcess(Processor processor, Exchange exchange, AsyncCallback callback) {
        MDC.put(HeaderKey.HEADER_CORRELATION_ID.getValue(), (String)exchange.getIn().getHeader(HeaderKey.CORRELATION_ID.getValue()));
        return callback;
    }

    @Override
    public boolean isBeforeAfterProcess() {
        return true;
    }
}