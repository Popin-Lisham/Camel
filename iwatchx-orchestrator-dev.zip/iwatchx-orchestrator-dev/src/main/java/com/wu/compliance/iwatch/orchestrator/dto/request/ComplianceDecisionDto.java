package com.wu.compliance.iwatch.orchestrator.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ComplianceDecisionDto {

	private DispositionDto disposition;
	private String action;
	private String reason;
	
    public DispositionDto getDisposition() {
		return disposition;
	}

	public void setDisposition(DispositionDto disposition) {
		this.disposition = disposition;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

@Override
  public String toString() {
    return "ComplianceDecisionDto [disposition=" + disposition + ", action=" + action + ", reason=" + reason + "]";
  }
}
