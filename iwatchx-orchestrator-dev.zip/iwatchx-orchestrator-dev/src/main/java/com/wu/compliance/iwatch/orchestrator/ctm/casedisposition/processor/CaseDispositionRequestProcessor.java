package com.wu.compliance.iwatch.orchestrator.ctm.casedisposition.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import wu.ei.cis.csc.core.gsi.xsd.gsi.gsitxndecisionrequest_2016_12.GSITxnDecisionRequest20161212;

@Component
public class CaseDispositionRequestProcessor implements Processor {
    Logger logger = LogManager.getLogger(this.getClass());
    @Override
    public void process(Exchange exchange) throws Exception {
        GSITxnDecisionRequest20161212 gsiTxnDecisionRequest = exchange.getIn().getBody(GSITxnDecisionRequest20161212.class);
        exchange.getIn().setBody(gsiTxnDecisionRequest);
        logger.info("Case Disposition request received");
    }
}
