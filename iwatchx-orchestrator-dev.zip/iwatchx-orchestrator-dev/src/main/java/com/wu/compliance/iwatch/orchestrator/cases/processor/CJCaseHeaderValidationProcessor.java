package com.wu.compliance.iwatch.orchestrator.cases.processor;

import com.wu.compliance.iwatch.microcommonapi.jsonschema.validation.ValidationResult;
import com.wu.compliance.iwatch.orchestrator.common.CaseHeaderSchema;
import com.wu.compliance.iwatch.orchestrator.common.CommonHeaderValidator;
import com.wu.compliance.iwatch.orchestrator.common.CommonValidationException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class CJCaseHeaderValidationProcessor implements Processor {

	 private final CaseHeaderSchema caseHeaderSchema;
	 private final CommonHeaderValidator commonHeaderValidator;

    public CJCaseHeaderValidationProcessor(CaseHeaderSchema caseHeaderSchema, CommonHeaderValidator commonHeaderValidator) {
        this.caseHeaderSchema = caseHeaderSchema;
        this.commonHeaderValidator = commonHeaderValidator;
    }

    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange) throws Exception {
        ValidationResult validationResult = commonHeaderValidator.validate(exchange, caseHeaderSchema.getJsonSchema());
        if (validationResult.isNotValid()) {
            throw new CommonValidationException(validationResult.getErrorDetails(), "The request provided is missing the required header(s).");
        }
    }
}
