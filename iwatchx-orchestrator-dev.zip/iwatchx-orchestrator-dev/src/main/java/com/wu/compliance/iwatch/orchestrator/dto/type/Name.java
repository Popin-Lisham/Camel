package com.wu.compliance.iwatch.orchestrator.dto.type;

import java.util.List;

public class Name{
	private String middle;
	private String last;
	private String first;
	private String fullName;
	private List<String> aliases;

	public void setMiddle(String middle){
		this.middle = middle;
	}

	public String getMiddle(){
		return middle;
	}

	public void setLast(String last){
		this.last = last;
	}

	public String getLast(){
		return last;
	}

	public void setFirst(String first){
		this.first = first;
	}

	public String getFirst(){
		return first;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public List<String> getAliases() {
		return aliases;
	}

	public void setAliases(List<String> aliases) {
		this.aliases = aliases;
	}
}
