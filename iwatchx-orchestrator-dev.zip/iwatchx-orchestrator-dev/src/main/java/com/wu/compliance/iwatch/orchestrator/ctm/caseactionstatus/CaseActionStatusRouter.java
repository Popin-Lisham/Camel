package com.wu.compliance.iwatch.orchestrator.ctm.caseactionstatus;

import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.common.CommonHeaderValidationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.CommonValidationException;
import com.wu.compliance.iwatch.orchestrator.common.InvalidHeaderProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.ctm.caseactionstatus.processor.CaseActionStatusExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.ctm.caseactionstatus.processor.CaseActionStatusRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.dto.request.CaseDispositionStatusDto;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestParamType;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.concurrent.TimeoutException;

@Component
public class CaseActionStatusRouter extends RouteBuilder {
    Logger logger = LogManager.getLogger(this.getClass());

    private final CaseActionStatusRequestProcessor caseActionStatusRequestProcessor;
    private final CaseActionStatusExceptionProcessor caseActionStatusExceptionProcessor;
    private final CommonHeaderValidationProcessor commonHeaderValidationProcessor;
    private final InvalidHeaderProcessor invalidHeaderProcessor;
    private final SanitizationProcessor sanitizationProcessor;
    private final XssDataExceptionProcessor xssDataExceptionProcessor;

    public CaseActionStatusRouter(CaseActionStatusRequestProcessor caseActionStatusRequestProcessor,
                                  CaseActionStatusExceptionProcessor caseActionStatusExceptionProcessor,
                                  CommonHeaderValidationProcessor commonHeaderValidationProcessor,
                                  InvalidHeaderProcessor invalidHeaderProcessor,
                                  SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor) {
        Objects.requireNonNull(caseActionStatusRequestProcessor, "caseActionStatusRequestProcessor is null");
        Objects.requireNonNull(caseActionStatusExceptionProcessor, "caseActionStatusExceptionProcessor is null");
        Objects.requireNonNull(commonHeaderValidationProcessor, "headerValidationProcessor is null");
        Objects.requireNonNull(invalidHeaderProcessor, "headerValidationFailedProcessor is null");
        Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
        Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");

        this.caseActionStatusRequestProcessor = caseActionStatusRequestProcessor;
        this.caseActionStatusExceptionProcessor = caseActionStatusExceptionProcessor;
        this.commonHeaderValidationProcessor = commonHeaderValidationProcessor;
        this.invalidHeaderProcessor = invalidHeaderProcessor;
        this.sanitizationProcessor = sanitizationProcessor;
        this.xssDataExceptionProcessor = xssDataExceptionProcessor;
    }

    @Override
    public void configure() {

        interceptSendToEndpoint("direct:route-ctm-action-status")
                .process(sanitizationProcessor)
                .process(commonHeaderValidationProcessor);

        onException(CommonValidationException.class)
                .handled(true)
                .process(invalidHeaderProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(Exception.class)
                .handled(true)
                .process(caseActionStatusExceptionProcessor);

        onException(HttpHostConnectException.class, TimeoutException.class)
                .handled(true)
                .maximumRedeliveries("{{app.context.retry.count}}").redeliveryDelay("{{app.context.retry.delay}}")
                .retryAttemptedLogLevel(LoggingLevel.WARN)
                .process(caseActionStatusExceptionProcessor);

        onException(XssDataException.class)
                .handled(true)
                .process(xssDataExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        rest().tag("Post Case Action Status")
                .description("Case action status result from iWatch")
                .consumes("application/json")
                .post("{{app.context.case.status.post}}")
                .type(CaseDispositionStatusDto.class)
                .param().name("x-wu-tenantpid").type(RestParamType.header).dataType("string").description("Tenant Primary Id.").required(false).endParam()
                .param().name("x-wu-tenantsid").type(RestParamType.header).dataType("string").description("Tenant Secondary Id.").required(false).endParam()
                .param().name("x-wu-genre").type(RestParamType.header).dataType("string").description("Genre.").required(false).endParam()
                .param().name("x-wu-userid").type(RestParamType.header).dataType("string").description("User Id").required(false).endParam()
                .param().name("x-wu-useremail").type(RestParamType.header).dataType("string").description("User Email").required(false).endParam()
                .param().name("x-wu-username").type(RestParamType.header).dataType("string").description("User Name").required(false).endParam()
                .param().name("x-wu-correlationId").type(RestParamType.header).dataType("string").description("Correlation Id").required(false).endParam()
                .clientRequestValidation(true)
                .to("direct:route-ctm-action-status");

        from("direct:route-ctm-action-status")
                .routeId("CTM_Action_Status_01")
                .streamCaching()
                .process(caseActionStatusRequestProcessor)
                .log(LoggingLevel.INFO, "Request is routed to CTM Action Interface for case action status request.")
                .to("{{app.ctm.interface.service.url}}")
                .end()
                .log(LoggingLevel.INFO, "Case action status request sent successfully")
                .log(LoggingLevel.DEBUG, "Response from CTM Action Interface ${body}");

        logger.info("Case action status router started.");
    }
}
