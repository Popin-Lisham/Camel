package com.wu.compliance.iwatch.orchestrator.common.unitofwork;

import org.apache.camel.Exchange;
import org.apache.camel.spi.UnitOfWork;
import org.apache.camel.spi.UnitOfWorkFactory;

public class CorrelationIdUnitOfWorkFactory implements UnitOfWorkFactory {

    @Override
    public UnitOfWork createUnitOfWork(Exchange exchange) {
        return new CorrelationIdUnitOfWork(exchange);
    }
}

