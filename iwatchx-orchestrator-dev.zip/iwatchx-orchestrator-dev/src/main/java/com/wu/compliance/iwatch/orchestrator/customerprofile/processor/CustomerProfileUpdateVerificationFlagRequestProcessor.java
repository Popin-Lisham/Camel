package com.wu.compliance.iwatch.orchestrator.customerprofile.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
@Component
public class CustomerProfileUpdateVerificationFlagRequestProcessor implements Processor {
    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange) {
        exchange.getIn().removeHeader(Exchange.HTTP_URI);
        logger.info("Customer Profile verificationFlag request received");
    }
}
