package com.wu.compliance.iwatch.orchestrator.transaction.lookup.processor;

import com.westernunion.transactionlookupservice.TransactionLookupWSResponse;
import com.wu.compliance.iwatch.orchestrator.transaction.lookup.exception.TransactionDetailsNotFoundException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class TransactionLookupResponseProcessor implements Processor {

    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange) throws TransactionDetailsNotFoundException {
        TransactionLookupWSResponse transactionLookupWSResponse = exchange.getIn().getBody(TransactionLookupWSResponse.class);

        if (ObjectUtils.isEmpty(transactionLookupWSResponse.getTransactionDetails())) {
            logger.error("No data found from transaction lookup service for activity reference number: " +
                    transactionLookupWSResponse.getHeader().getCorrelationId());

            throw new TransactionDetailsNotFoundException();
        }

        logger.info("Successfully fetched transaction details for mtcn : " + transactionLookupWSResponse.getHeader().getCorrelationId());

        exchange.getIn().setBody(transactionLookupWSResponse);
    }
}
