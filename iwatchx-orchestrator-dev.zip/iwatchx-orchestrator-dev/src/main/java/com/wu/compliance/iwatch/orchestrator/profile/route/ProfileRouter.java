package com.wu.compliance.iwatch.orchestrator.profile.route;

import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.common.CommonValidationException;
import com.wu.compliance.iwatch.orchestrator.common.InvalidHeaderProcessor;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.dto.request.ProfileAttachmentDto;
import com.wu.compliance.iwatch.orchestrator.profile.processor.ProfileExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.profile.processor.ProfileHeaderValidationProcessor;
import com.wu.compliance.iwatch.orchestrator.profile.processor.ProfileRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.profile.processor.ProfileResponseProcessor;
import org.apache.camel.ExchangePattern;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.Resilience4jConfigurationDefinition;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestParamType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
public class ProfileRouter extends RouteBuilder {
    Logger logger = LogManager.getLogger(this.getClass());

    private final ProfileRequestProcessor profileRequestProcessor;

    private final ProfileResponseProcessor profileResponseProcessor;

    private final ProfileExceptionProcessor profileExceptionProcessor;

    private final Resilience4jConfigurationDefinition resilience4jConfigurationDefinition;

    private final ProfileHeaderValidationProcessor profileHeaderValidationProcessor;

    private final InvalidHeaderProcessor invalidHeaderProcessor;

    @Value("${secret.cmtcmpl.iwatchx.queue.cjrabbitmq.username}")
    private String rabbitMQUserName;

    @Value("${secret.cmtcmpl.iwatchx.queue.cjrabbitmq.password}")
    private String rabbitMQPassword;


    private final SanitizationProcessor sanitizationProcessor;

    private final XssDataExceptionProcessor xssDataExceptionProcessor;

    public ProfileRouter(ProfileRequestProcessor profileRequestProcessor, ProfileResponseProcessor profileResponseProcessor,
                         ProfileExceptionProcessor profileExceptionProcessor,
                         Resilience4jConfigurationDefinition resilience4jConfigurationDefinition,
                         ProfileHeaderValidationProcessor profileHeaderValidationProcessor, InvalidHeaderProcessor invalidHeaderProcessor,
                         SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor) {

        Objects.requireNonNull(profileRequestProcessor, "profileRequestProcessor is null");
        Objects.requireNonNull(profileResponseProcessor, "profileResponseProcessor is null");
        Objects.requireNonNull(profileExceptionProcessor, "profileExceptionProcessor is null");
        Objects.requireNonNull(resilience4jConfigurationDefinition, "resilience4jConfigurationDefinition is null");
        Objects.requireNonNull(invalidHeaderProcessor, "headerValidationFailedProcessor is null");
        Objects.requireNonNull(profileHeaderValidationProcessor, "profileHeaderValidationProcessor is null");
        Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
        Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");

        this.profileRequestProcessor = profileRequestProcessor;
        this.profileResponseProcessor = profileResponseProcessor;
        this.profileExceptionProcessor = profileExceptionProcessor;
        this.resilience4jConfigurationDefinition = resilience4jConfigurationDefinition;
        this.profileHeaderValidationProcessor = profileHeaderValidationProcessor;
        this.invalidHeaderProcessor = invalidHeaderProcessor;
        this.sanitizationProcessor = sanitizationProcessor;
        this.xssDataExceptionProcessor = xssDataExceptionProcessor;
    }

    @Override
    public void configure() {

        interceptSendToEndpoint("direct:request-profile")
                .process(sanitizationProcessor)
                .process(profileHeaderValidationProcessor);

        onException(CommonValidationException.class)
                .handled(true)
                .process(invalidHeaderProcessor).id("RT_Profile_Process_05")
                .marshal().json(JsonLibrary.Jackson);

        onException(Exception.class)
                .handled(true)
                .process(profileExceptionProcessor).id("RT_Profile_Process_04")
                .marshal().json(JsonLibrary.Jackson);

        onException(XssDataException.class)
                .handled(true)
                .process(xssDataExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        rest().tag("Post Profile").description("Post profile attachment information from iWatch queue listener")
                .post("{{app.context.profile.post}}")
                .produces("application/json")
                .consumes("application/json")
                .type(ProfileAttachmentDto.class)
                .param().name("x-wu-tenantpid").type(RestParamType.header).dataType("string").description("Tenant Primary Id.").required(false).endParam()
                .param().name("x-wu-tenantsid").type(RestParamType.header).dataType("string").description("Tenant Secondary Id.").required(false).endParam()
                .param().name("x-wu-userid").type(RestParamType.header).dataType("string").description("User Id").required(false).endParam()
                .param().name("x-wu-useremail").type(RestParamType.header).dataType("string").description("User Email").required(false).endParam()
                .param().name("x-wu-username").type(RestParamType.header).dataType("string").description("User Name").required(false).endParam()
                .param().name("x-wu-correlationId").type(RestParamType.header).dataType("string").description("Correlation Id").required(false).endParam()
                .clientRequestValidation(true)
                .to("direct:request-profile");

        from("direct:request-profile")
                .routeId("RT_Profile_01")
                .setExchangePattern(ExchangePattern.InOut)
                .removeHeaders("Camel.*")
                .process(profileRequestProcessor)
                .to("direct:routeProfile");

        from("direct:routeProfile")
                .circuitBreaker()
                .resilience4jConfiguration(resilience4jConfigurationDefinition)
                .log(LoggingLevel.INFO, "Sending Profile attachment request to {{app.rabbitmq.exchange.profile}}")
                .to(ExchangePattern.InOnly, "rabbitmq:{{app.rabbitmq.exchange.profile}}?" +
                        "declare=false&autoDelete=false&mandatory=true&guaranteedDeliveries=true" +
                        "&publisherAcknowledgements=true&passive=true&skipQueueDeclare=true" +
                        "&publisherAcknowledgementsTimeout={{app.rabbitmq.profile.publisherAcknowledgementsTimeout}}" +
                        "&addresses={{app.rabbitmq.connection.host.addresses}}" +
                        "&username=" + rabbitMQUserName +
                        "&password=" + rabbitMQPassword +
                        "&vhost={{app.rabbitmq.connection.virtualhost}}&requestTimeout={{app.rabbitmq.profile.requestTimeout}}")
                .end()
                .log(LoggingLevel.INFO, "Profile attachment request message sent successfully")
                .process(profileResponseProcessor).id("RT_Profile_Process_02")
                .marshal().json(JsonLibrary.Jackson);

        logger.info("Profile router RT_Profile_01 started.");
    }
}