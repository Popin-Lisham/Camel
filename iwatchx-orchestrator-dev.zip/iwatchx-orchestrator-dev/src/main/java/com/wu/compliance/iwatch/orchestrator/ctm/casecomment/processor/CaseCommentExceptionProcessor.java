package com.wu.compliance.iwatch.orchestrator.ctm.casecomment.processor;

import com.example.xmlns._1482216288989.FaultErrorMessageV100;
import com.wu.compliance.iwatch.orchestrator.common.ConnectionErrorHeader;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import wu.ei.cis.csc.core.gsi.xsd.wu.faulterrormessage_2016_12.FaultErrorMessage20161212;

@Component
public class CaseCommentExceptionProcessor  implements Processor {

    Logger logger = LogManager.getLogger(this.getClass());
    private final ConnectionErrorHeader connectionErrorHeader;

    public CaseCommentExceptionProcessor(ConnectionErrorHeader connectionErrorHeader) {
        this.connectionErrorHeader = connectionErrorHeader;
    }


    @Override
    public void process(Exchange exchange) {
        Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.INTERNAL_SERVER_ERROR.value());
        if(ExceptionUtils.hasCause(exception, FaultErrorMessageV100.class)){
            FaultErrorMessageV100 ctmServiceFaultException = ((FaultErrorMessageV100) exception);
            logger.error("Error response from ctm GSI Service : \n"+ ctmServiceFaultException.getFaultInfo().getErrorText(),exception);
            exchange.getIn().setBody(ctmServiceFaultException.getFaultInfo());
        }
        else {
            logger.error(ExceptionUtils.getStackTrace(exception),exception);
            connectionErrorHeader.setConnectionErrorHeader(exchange,exception);
            exchange.getIn().setBody(createCustomErrorMessage());
        }
    }
    public FaultErrorMessage20161212 createCustomErrorMessage(){
        FaultErrorMessage20161212 addCommentServiceFault = new FaultErrorMessage20161212();
        addCommentServiceFault.setErrorText("An error occurred while trying to access Tibco CSL CTM Service.");
        return addCommentServiceFault;
    }
}
