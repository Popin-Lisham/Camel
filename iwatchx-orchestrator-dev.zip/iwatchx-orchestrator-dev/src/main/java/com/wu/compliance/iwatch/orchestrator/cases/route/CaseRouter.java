package com.wu.compliance.iwatch.orchestrator.cases.route;

import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.cases.processor.CaseExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.cases.processor.CaseHeaderValidationProcessor;
import com.wu.compliance.iwatch.orchestrator.cases.processor.CaseRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.cases.processor.CaseTypeErrorProcessor;
import com.wu.compliance.iwatch.orchestrator.common.CommonValidationException;
import com.wu.compliance.iwatch.orchestrator.common.InvalidHeaderProcessor;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.dto.request.CaseRequestDto;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.Resilience4jConfigurationDefinition;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
public class CaseRouter extends RouteBuilder {

    private final CaseRequestProcessor caseRequestProcessor;

    private final CaseExceptionProcessor caseExceptionProcessor;

    private final CaseTypeErrorProcessor caseTypeErrorProcessor;

    private final Resilience4jConfigurationDefinition resilience4jConfigurationDefinition;

    private final CaseHeaderValidationProcessor caseHeaderValidationProcessor;

    private final InvalidHeaderProcessor invalidHeaderProcessor;

    private final SanitizationProcessor sanitizationProcessor;

    private final XssDataExceptionProcessor xssDataExceptionProcessor;

    public CaseRouter(CaseRequestProcessor caseRequestProcessor, CaseExceptionProcessor caseExceptionProcessor,
                      CaseTypeErrorProcessor caseTypeErrorProcessor,
                      Resilience4jConfigurationDefinition resilience4jConfigurationDefinition,
                      CaseHeaderValidationProcessor caseHeaderValidationProcessor, InvalidHeaderProcessor invalidHeaderProcessor,
                      SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor) {
        Objects.requireNonNull(caseRequestProcessor, "caseRequestProcessor is null");
        Objects.requireNonNull(caseExceptionProcessor, "caseExceptionProcessor is null");
        Objects.requireNonNull(caseTypeErrorProcessor, "caseTypeErrorProcessor is null");
        Objects.requireNonNull(resilience4jConfigurationDefinition, "resilience4jConfigurationDefinition is null");
        Objects.requireNonNull(caseHeaderValidationProcessor, "caseHeaderValidationProcessor is null");
        Objects.requireNonNull(invalidHeaderProcessor, "headerValidationFailedProcessor is null");
        Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
        Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");

        this.caseRequestProcessor = caseRequestProcessor;
        this.caseExceptionProcessor = caseExceptionProcessor;
        this.caseTypeErrorProcessor = caseTypeErrorProcessor;
        this.resilience4jConfigurationDefinition = resilience4jConfigurationDefinition;
        this.caseHeaderValidationProcessor = caseHeaderValidationProcessor;
        this.invalidHeaderProcessor = invalidHeaderProcessor;
        this.sanitizationProcessor = sanitizationProcessor;
        this.xssDataExceptionProcessor = xssDataExceptionProcessor;
    }

    @Override
    public void configure() {

        interceptSendToEndpoint("direct:process-input")
                .process(sanitizationProcessor)
                .process(caseHeaderValidationProcessor);

        onException(Exception.class)
                .handled(true)
                .process(caseExceptionProcessor);

        onException(CommonValidationException.class)
                .handled(true)
                .process(invalidHeaderProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(XssDataException.class)
                .handled(true)
                .process(xssDataExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        rest().tag("Post Cases").description("Post case creation information from iWatch queue listener")
                .post("{{app.context.cases.post}}")
                .produces("application/json")
                .consumes("application/json")
                .type(CaseRequestDto.class)
                .param().name("x-wu-tenantpid").type(RestParamType.header).dataType("string").description("Tenant Primary Id.").required(false).endParam()
                .param().name("x-wu-tenantsid").type(RestParamType.header).dataType("string").description("Tenant Secondary Id.").required(false).endParam()
                .param().name("x-wu-bizgrp").type(RestParamType.header).dataType("string").description("Classification BusinessGroup.").required(false).endParam()
                .param().name("x-wu-invgrp").type(RestParamType.header).dataType("string").description("Classification InvestigationGroup").required(false).endParam()
                .param().name("x-wu-userid").type(RestParamType.header).dataType("string").description("User Id").required(false).endParam()
                .param().name("x-wu-useremail").type(RestParamType.header).dataType("string").description("User Email").required(false).endParam()
                .param().name("x-wu-username").type(RestParamType.header).dataType("string").description("User Name").required(false).endParam()
                .param().name("x-wu-correlationId").type(RestParamType.header).dataType("string").description("Correlation Id").required(false).endParam()
                .clientRequestValidation(true)
                .to("direct:process-input");

        from("direct:process-input")
                .routeId("RT_Case_01")
                .unmarshal().json(JsonLibrary.Jackson, CaseRequestDto.class)
                .log(LoggingLevel.INFO, "Case creation message received: activityRefNo = ${body.activityRefNo}, attemptId = ${body.attemptId}, tranSurKey = ${body.tranSurKey}")
                .to("direct:select-route");

        from("direct:select-route")
                .log(LoggingLevel.DEBUG, "Business group type is ${header.x-wu-bizgrp}")
                .choice()
                .when().simple("${header.x-wu-bizgrp} == 'GSI'")
                .to("direct:gsi-interim")
                .when().simple("${header.x-wu-bizgrp} == 'KYC'")
                .to("direct:kyc-interim")
                .otherwise()
                .to("direct:default")
                .end();

        from("direct:gsi-interim")
                .streamCaching()
                .log(LoggingLevel.DEBUG, "Request is routed to interim service for case creation")
                .process(caseRequestProcessor)
                .marshal().json(JsonLibrary.Jackson)
                .circuitBreaker()
                .resilience4jConfiguration(resilience4jConfigurationDefinition)
                .to("{{app.cj.interim.url}}")
                .end()
                .log(LoggingLevel.INFO, "Interim service request message sent successfully");

        from("direct:kyc-interim")
				.streamCaching()
				.log(LoggingLevel.INFO, "Request is routed to interim service for case creation")
				.process(caseRequestProcessor)
				.marshal().json(JsonLibrary.Jackson)
				.circuitBreaker()
				.resilience4jConfiguration(resilience4jConfigurationDefinition)
				.to("{{app.cj.interim.kyc.url}}")
				.end()
				.log(LoggingLevel.INFO, "Interim service request message sent successfully");
        
        from("direct:default")
                .log(LoggingLevel.ERROR, "Case creation request is not able to route as case type is ${header.x-wu-bizgrp}")
                .transform().constant("Not able to route as classification business group is unknown")
                .process(caseTypeErrorProcessor)
                .marshal().json(JsonLibrary.Jackson);
    }
}
