package com.wu.compliance.iwatch.orchestrator.transaction.lookup.exception;

public class TransactionDetailsNotFoundException extends Exception {
}
