package com.wu.compliance.iwatch.orchestrator.dto.type;

public class HitDetail {
	private double score;
	private String subjectAttribute;
	private String entityAttribute;
	private String algo;
	
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public String getSubjectAttribute() {
		return subjectAttribute;
	}
	public void setSubjectAttribute(String subjectAttribute) {
		this.subjectAttribute = subjectAttribute;
	}
	public String getEntityAttribute() {
		return entityAttribute;
	}
	public void setEntityAttribute(String entityAttribute) {
		this.entityAttribute = entityAttribute;
	}
	public String getAlgo() {
		return algo;
	}
	public void setAlgo(String algo) {
		this.algo = algo;
	}
	
}
