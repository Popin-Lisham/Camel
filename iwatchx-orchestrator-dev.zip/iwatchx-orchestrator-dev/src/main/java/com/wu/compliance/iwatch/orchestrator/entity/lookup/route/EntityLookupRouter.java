package com.wu.compliance.iwatch.orchestrator.entity.lookup.route;

import com.westernunion.entityservice.EntityDetailsRequest;
import com.westernunion.entityservice.EntityServiceFaultException;
import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.entity.lookup.exception.EntityDataNotFoundException;
import com.wu.compliance.iwatch.orchestrator.entity.lookup.processor.*;
import org.apache.camel.ExchangePattern;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

import javax.xml.bind.UnmarshalException;
import java.util.Objects;

@Component
public class EntityLookupRouter extends RouteBuilder {

    private final EntityLookupRequestProcessor entityLookupRequestProcessor;

    private final EntityLookupResponseProcessor entityLookupResponseProcessor;

    private final EntityLookupExceptionProcessor entityLookupExceptionProcessor;

    private final EntityServiceFaultExceptionProcessor entityServiceFaultExceptionProcessor;

    private final EntityDataNotFoundExceptionProcessor entityDataNotFoundExceptionProcessor;

    private final EntityResponseUnmarshalExceptionProcessor entityResponseUnmarshalExceptionProcessor;

    private final SanitizationProcessor sanitizationProcessor;

    private final XssDataExceptionProcessor xssDataExceptionProcessor;

    public EntityLookupRouter(EntityLookupRequestProcessor entityLookupRequestProcessor, EntityLookupResponseProcessor entityLookupResponseProcessor, EntityLookupExceptionProcessor entityLookupExceptionProcessor,
                              EntityServiceFaultExceptionProcessor entityServiceFaultExceptionProcessor, EntityDataNotFoundExceptionProcessor entityDataNotFoundExceptionProcessor,
                              EntityResponseUnmarshalExceptionProcessor entityResponseUnmarshalExceptionProcessor,
                              SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor) {
        Objects.requireNonNull(entityLookupRequestProcessor, "entityLookupRequestProcessor is null");
        Objects.requireNonNull(entityLookupResponseProcessor, "entityLookupResponseProcessor is null");
        Objects.requireNonNull(entityLookupExceptionProcessor, "entityLookupExceptionProcessor is null");
        Objects.requireNonNull(entityServiceFaultExceptionProcessor, "entityServiceFaultExceptionProcessor is null");
        Objects.requireNonNull(entityDataNotFoundExceptionProcessor, "entityDataNotFoundExceptionProcessor is null");
        Objects.requireNonNull(entityResponseUnmarshalExceptionProcessor, "entityUnmarshalExceptionProcessor is null");
        Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
        Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");

        this.entityLookupRequestProcessor = entityLookupRequestProcessor;
        this.entityLookupResponseProcessor = entityLookupResponseProcessor;
        this.entityLookupExceptionProcessor = entityLookupExceptionProcessor;
        this.entityServiceFaultExceptionProcessor = entityServiceFaultExceptionProcessor;
        this.entityDataNotFoundExceptionProcessor = entityDataNotFoundExceptionProcessor;
        this.entityResponseUnmarshalExceptionProcessor = entityResponseUnmarshalExceptionProcessor;
        this.sanitizationProcessor = sanitizationProcessor;
        this.xssDataExceptionProcessor = xssDataExceptionProcessor;
    }

    @Override
    public void configure() {

        interceptSendToEndpoint("direct:process-entity-lookup-input")
                .process(sanitizationProcessor);

        onException(UnmarshalException.class)
                .handled(true)
                .process(entityResponseUnmarshalExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(EntityServiceFaultException.class)
                .handled(true)
                .process(entityServiceFaultExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(EntityDataNotFoundException.class)
                .handled(true)
                .process(entityDataNotFoundExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(Exception.class)
                .handled(true)
                .process(entityLookupExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(XssDataException.class)
                .handled(true)
                .process(xssDataExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        rest()
                .tag("Fetch Entity")
                .description("Fetch entity information from RTRA lookup service")
                .post("{{app.context.entity.post}}")
                .consumes("application/text")
                .type(String.class)
                .to("direct:process-entity-lookup-input");

        from("direct:process-entity-lookup-input")
                .routeId("RT_entity_01")
                .streamCaching()
                .unmarshal().json(JsonLibrary.Jackson, EntityDetailsRequest.class)
                .process(entityLookupRequestProcessor)
                .to("direct:call-entity-lookup");

        from("direct:call-entity-lookup")
                .log(LoggingLevel.INFO,"Fetching entity lookup details for activity reference number : ${body.referenceNumber}")
                .to(ExchangePattern.InOut, "cxf:bean:rtraEntityLookupCxfEndpoint")
                .process(entityLookupResponseProcessor)
                .marshal().json(JsonLibrary.Jackson);
    }

}