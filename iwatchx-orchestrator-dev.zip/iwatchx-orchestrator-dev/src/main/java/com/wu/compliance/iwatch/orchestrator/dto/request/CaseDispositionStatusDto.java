package com.wu.compliance.iwatch.orchestrator.dto.request;

public class CaseDispositionStatusDto {
    private String queueName;
    private String refId;
    private String decision;
    private ResponseDto response;
    private String reInstatedRefId;
    private String caseId;

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getQueueName() {
        return queueName;
    }

    public void setQueueName(String queueName) {
        this.queueName = queueName;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public ResponseDto getResponse() {
        return response;
    }

    public void setResponse(ResponseDto response) {
        this.response = response;
    }

    public String getReInstatedRefId() {
        return reInstatedRefId;
    }

    public void setReInstatedRefId(String reInstatedRefId) {
        this.reInstatedRefId = reInstatedRefId;
    }
}
