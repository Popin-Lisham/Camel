package com.wu.compliance.iwatch.orchestrator.dto.request;

import org.springframework.validation.annotation.Validated;

/**
 * Header
 */

public class HeaderDto {
	private String appName;
	private String appVersion;
	private String tenantId;

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppVersion() {
		return appVersion;
	}

	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

  @Override
  public String toString() {
    return "HeaderDto [appName=" + appName + ", appVersion=" + appVersion + ", tenantId=" + tenantId + "]";
  }

}
