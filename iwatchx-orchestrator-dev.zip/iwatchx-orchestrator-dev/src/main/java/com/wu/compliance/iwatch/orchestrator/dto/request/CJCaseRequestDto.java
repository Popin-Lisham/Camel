package com.wu.compliance.iwatch.orchestrator.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.wu.compliance.iwatch.orchestrator.dto.type.Activity;
import com.wu.compliance.iwatch.orchestrator.dto.type.Case;
import com.wu.compliance.iwatch.orchestrator.dto.type.HitsInfo;

public class CJCaseRequestDto {
	@JsonProperty("case")
	private Case acase;
	private Activity activity;
	private HitsInfo hitsInfo;
	public Case getAcase() {
		return acase;
	}
	public void setAcase(Case acase) {
		this.acase = acase;
	}
	public Activity getActivity() {
		return activity;
	}
	public void setActivity(Activity activity) {
		this.activity = activity;
	}
	public HitsInfo getHitsInfo() {
		return hitsInfo;
	}
	public void setHitsInfo(HitsInfo hitsInfo) {
		this.hitsInfo = hitsInfo;
	}
	
}
