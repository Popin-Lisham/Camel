package com.wu.compliance.iwatch.orchestrator.transaction.lookup.processor;

import com.westernunion.transactionlookupservice.TransactionLookupWSRequest;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class TransactionLookupRequestProcessor implements Processor {

    @Value("${secret.cmtcmpl.iwatchx.rtra.txnlookup.username}")
    public String partnerId;

    @Value("${secret.cmtcmpl.iwatchx.rtra.txnlookup.password}")
    public String partnerPassword;

    @Value("${app.transaction-lookup.version.number}")
    public String versionNumber;

    @Override
    public void process(Exchange exchange) {
        TransactionLookupWSRequest transactionLookupWSRequest = exchange.getIn().getBody(TransactionLookupWSRequest.class);
        transactionLookupWSRequest.setPartnerId(partnerId);
        transactionLookupWSRequest.setPartnerPwd(partnerPassword);
        transactionLookupWSRequest.setVersionNumber(versionNumber);
        exchange.getIn().setBody(transactionLookupWSRequest);
    }
}
