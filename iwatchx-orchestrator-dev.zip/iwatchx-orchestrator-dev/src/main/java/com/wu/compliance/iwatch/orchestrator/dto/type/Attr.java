package com.wu.compliance.iwatch.orchestrator.dto.type;

import com.fasterxml.jackson.annotation.JsonInclude;

public class Attr {
	private String name;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String category;
	private String value;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
}
