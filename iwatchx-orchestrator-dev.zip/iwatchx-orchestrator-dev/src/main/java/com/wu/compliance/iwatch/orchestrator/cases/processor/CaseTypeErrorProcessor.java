package com.wu.compliance.iwatch.orchestrator.cases.processor;

import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.wu.compliance.iwatch.orchestrator.dto.response.ResponseBuilder.buildUnknownErrorResponse;

@Component
public class CaseTypeErrorProcessor implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        DefaultResponse errorResponse = buildUnknownErrorResponse(StringUtils.defaultIfBlank((String) exchange.getIn().getHeader(HeaderKey.CORRELATION_ID.getValue()), UUID.randomUUID().toString()), exchange.getIn().getBody(String.class));
        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.BAD_REQUEST.value());
        exchange.getIn().setBody(errorResponse);
    }
}
