package com.wu.compliance.iwatch.orchestrator.common;

import com.wu.compliance.iwatch.microcommonapi.jsonschema.validation.AbstractHeaderSchema;
import org.springframework.stereotype.Component;

@Component
public class ActivityStatusHeaderSchema extends AbstractHeaderSchema {
    public ActivityStatusHeaderSchema() {
        super("activity-header-schema.json");
    }
}
