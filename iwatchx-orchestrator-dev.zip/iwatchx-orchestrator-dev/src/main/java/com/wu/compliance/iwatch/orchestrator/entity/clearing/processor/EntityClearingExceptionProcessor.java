package com.wu.compliance.iwatch.orchestrator.entity.clearing.processor;

import com.westernunion.entityservice.EntityServiceFault;
import com.westernunion.entityservice.EntityServiceFaultException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class EntityClearingExceptionProcessor implements Processor {
    Logger logger = LogManager.getLogger(this.getClass());

    @Override
    public void process(Exchange exchange) {
        Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.INTERNAL_SERVER_ERROR.value());
        if (ExceptionUtils.hasCause(exception, EntityServiceFaultException.class)) {
            EntityServiceFaultException entityServiceFaultException = ((EntityServiceFaultException) exception);
            logger.error("Error response from entity clearing Service : \n" + entityServiceFaultException.getFaultInfo().getErrorDescription(), exception);
            exchange.getIn().setBody(entityServiceFaultException.getFaultInfo());
        } else {
            logger.error(ExceptionUtils.getStackTrace(exception));
            exchange.getIn().setBody(createCustomErrorMessage());
        }
    }

    public EntityServiceFault createCustomErrorMessage() {
        EntityServiceFault entityServiceFault = new EntityServiceFault();
        entityServiceFault.setErrorMessage("An error occurred while trying to access entity clearing service.");
        return entityServiceFault;
    }
}
