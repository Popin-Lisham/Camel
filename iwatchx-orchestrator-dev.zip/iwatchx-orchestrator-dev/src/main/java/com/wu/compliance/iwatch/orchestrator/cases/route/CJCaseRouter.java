package com.wu.compliance.iwatch.orchestrator.cases.route;

import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.cases.processor.CJCaseExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.cases.processor.CJCaseHeaderValidationProcessor;
import com.wu.compliance.iwatch.orchestrator.cases.processor.CJCaseRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.cases.processor.CJCaseTypeErrorProcessor;
import com.wu.compliance.iwatch.orchestrator.common.CommonValidationException;
import com.wu.compliance.iwatch.orchestrator.common.InvalidHeaderProcessor;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.dto.request.CJCaseRequestDto;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.Resilience4jConfigurationDefinition;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.stereotype.Component;
import java.util.Objects;

@Component
public class CJCaseRouter extends RouteBuilder {

    private final CJCaseRequestProcessor caseRequestProcessor;

    private final CJCaseExceptionProcessor caseExceptionProcessor;

    private final CJCaseTypeErrorProcessor caseTypeErrorProcessor;

    private final Resilience4jConfigurationDefinition resilience4jConfigurationDefinition;

    private final CJCaseHeaderValidationProcessor caseHeaderValidationProcessor;

    private final InvalidHeaderProcessor invalidHeaderProcessor;

    private final SanitizationProcessor sanitizationProcessor;

    private final XssDataExceptionProcessor xssDataExceptionProcessor;

    public CJCaseRouter(CJCaseRequestProcessor caseRequestProcessor, CJCaseExceptionProcessor caseExceptionProcessor,
                      CJCaseTypeErrorProcessor caseTypeErrorProcessor,
                      Resilience4jConfigurationDefinition resilience4jConfigurationDefinition,
                      CJCaseHeaderValidationProcessor caseHeaderValidationProcessor, InvalidHeaderProcessor invalidHeaderProcessor,
                      SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor) {
        Objects.requireNonNull(caseRequestProcessor, "caseRequestProcessor is null");
        Objects.requireNonNull(caseExceptionProcessor, "caseExceptionProcessor is null");
        Objects.requireNonNull(caseTypeErrorProcessor, "caseTypeErrorProcessor is null");
        Objects.requireNonNull(resilience4jConfigurationDefinition, "resilience4jConfigurationDefinition is null");
        Objects.requireNonNull(caseHeaderValidationProcessor, "caseHeaderValidationProcessor is null");
        Objects.requireNonNull(invalidHeaderProcessor, "headerValidationFailedProcessor is null");
        Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
        Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");

        this.caseRequestProcessor = caseRequestProcessor;
        this.caseExceptionProcessor = caseExceptionProcessor;
        this.caseTypeErrorProcessor = caseTypeErrorProcessor;
        this.resilience4jConfigurationDefinition = resilience4jConfigurationDefinition;
        this.caseHeaderValidationProcessor = caseHeaderValidationProcessor;
        this.invalidHeaderProcessor = invalidHeaderProcessor;
        this.sanitizationProcessor = sanitizationProcessor;
        this.xssDataExceptionProcessor = xssDataExceptionProcessor;
    }

    @Override
    public void configure() {

        interceptSendToEndpoint("direct:process-input-cj")
                .process(sanitizationProcessor)
                .process(caseHeaderValidationProcessor);

        onException(Exception.class)
                .handled(true)
                .process(caseExceptionProcessor);

        onException(CommonValidationException.class)
                .handled(true)
                .process(invalidHeaderProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(XssDataException.class)
                .handled(true)
                .process(xssDataExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        rest().tag("Post CJ Cases").description("Post case creation information from Mulesoft")
                .post("{{app.context.cj.cases.post}}")
                .produces("application/json")
                .consumes("application/json")
                .type(CJCaseRequestDto.class)
                .param().name("x-wu-tenantpid").type(RestParamType.header).dataType("string").description("Tenant Primary Id.").required(false).endParam()
                .param().name("x-wu-tenantsid").type(RestParamType.header).dataType("string").description("Tenant Secondary Id.").required(false).endParam()
                .param().name("x-wu-bizgrp").type(RestParamType.header).dataType("string").description("Classification BusinessGroup.").required(false).endParam()
                .param().name("x-wu-invgrp").type(RestParamType.header).dataType("string").description("Classification InvestigationGroup").required(false).endParam()
                .param().name("x-wu-userid").type(RestParamType.header).dataType("string").description("User Id").required(false).endParam()
                .param().name("x-wu-useremail").type(RestParamType.header).dataType("string").description("User Email").required(false).endParam()
                .param().name("x-wu-username").type(RestParamType.header).dataType("string").description("User Name").required(false).endParam()
                .param().name("x-wu-correlationId").type(RestParamType.header).dataType("string").description("Correlation Id").required(false).endParam()
                .clientRequestValidation(true)
                .to("direct:process-input-cj");

        from("direct:process-input-cj")
                .routeId("RT_CJCase_01")
                .unmarshal().json(JsonLibrary.Jackson, CJCaseRequestDto.class)
                .log(LoggingLevel.INFO, "Case creation message received")
                .to("direct:select-route-cj");

        from("direct:select-route-cj")
                .log(LoggingLevel.INFO, "Business group type is ${header.x-wu-bizgrp}")
                .choice()
                .when().simple("${header.x-wu-bizgrp} in {{valid.cj.bizgrps}}")
                .to("direct:casecreate-cj")
                .otherwise()
                .to("direct:default-cj")
                .end();

        from("direct:casecreate-cj")
                .streamCaching()
                .log(LoggingLevel.INFO, "Request is routed to Case Create service for case creation")
                .process(caseRequestProcessor)
                .marshal().json(JsonLibrary.Jackson)
                .circuitBreaker()
                .resilience4jConfiguration(resilience4jConfigurationDefinition)
                .to("{{app.cj.case.creator.url}}")
                .end()
                .log(LoggingLevel.INFO, "Case Create service request message sent successfully");


        from("direct:default-cj")
                .log(LoggingLevel.ERROR, "Case creation request is not able to route as case type is ${header.x-wu-bizgrp}")
                .transform().constant("Not able to route as classification business group is unknown")
                .process(caseTypeErrorProcessor)
                .marshal().json(JsonLibrary.Jackson);
    }
}
