package com.wu.compliance.iwatch.orchestrator.customerprofile.route;

import java.util.Objects;
import java.util.concurrent.TimeoutException;

import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import org.apache.camel.ExchangePattern;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestParamType;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wu.compliance.iwatch.orchestrator.customerprofile.processor.CustomerProfileUpdateVerificationFlagExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.customerprofile.processor.CustomerProfileUpdateVerificationFlagRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.customerprofile.processor.CustomerProfileUpdateVerificationFlagResponseProcessor;
import com.wu.compliance.iwatch.orchestrator.dto.request.LookupCustomerRequestDto;
import com.wu.compliance.iwatch.orchestrator.dto.request.UpdateVerificationFlagsRequestDto;
@Component
public class CustomerProfileUpdateVerificationFlagRouter extends RouteBuilder {
	Logger logger = LogManager.getLogger(this.getClass());

	private final CustomerProfileUpdateVerificationFlagExceptionProcessor customerProfileUpdateVerificationFlagExceptionProcessor;
	private final CustomerProfileUpdateVerificationFlagRequestProcessor customerProfileUpdateVerificationFlagRequestProcessor ;
	private final CustomerProfileUpdateVerificationFlagResponseProcessor customerProfileUpdateVerificationFlagResponseProcessor;
	private final SanitizationProcessor sanitizationProcessor;
	private final XssDataExceptionProcessor xssDataExceptionProcessor;

	public CustomerProfileUpdateVerificationFlagRouter(
			CustomerProfileUpdateVerificationFlagExceptionProcessor customerProfileUpdateVerificationFlagExceptionProcessor,
			CustomerProfileUpdateVerificationFlagRequestProcessor customerProfileUpdateVerificationFlagRequestProcessor,
			CustomerProfileUpdateVerificationFlagResponseProcessor customerProfileUpdateVerificationFlagResponseProcessor,
			SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor) {
		Objects.requireNonNull(customerProfileUpdateVerificationFlagRequestProcessor, "customerProfileUpdateVerificationFlagRequestProcessor is null");
		Objects.requireNonNull(customerProfileUpdateVerificationFlagExceptionProcessor, "customerProfileUpdateVerificationFlagExceptionProcessor is null");
		Objects.requireNonNull(customerProfileUpdateVerificationFlagResponseProcessor, "customerProfileUpdateVerificationFlagResponseProcessor is null");
		Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
		Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");

		this.customerProfileUpdateVerificationFlagRequestProcessor = customerProfileUpdateVerificationFlagRequestProcessor;
		this.customerProfileUpdateVerificationFlagExceptionProcessor = customerProfileUpdateVerificationFlagExceptionProcessor;
		this.customerProfileUpdateVerificationFlagResponseProcessor = customerProfileUpdateVerificationFlagResponseProcessor;
		this.sanitizationProcessor = sanitizationProcessor;
		this.xssDataExceptionProcessor = xssDataExceptionProcessor;
	}

	@Override
    public void configure() {

		interceptSendToEndpoint("direct:route-cpi-profile-update-verification-input")
				.process(sanitizationProcessor);

        onException(Exception.class)
                .handled(true)
                .process(customerProfileUpdateVerificationFlagExceptionProcessor);

        onException(HttpHostConnectException.class, TimeoutException.class)
                .handled(true)
                .maximumRedeliveries("{{app.context.retry.count}}").redeliveryDelay("{{app.context.retry.delay}}")
                .retryAttemptedLogLevel(LoggingLevel.WARN)
                .process(customerProfileUpdateVerificationFlagExceptionProcessor);

		onException(XssDataException.class)
				.handled(true)
				.process(xssDataExceptionProcessor)
				.marshal().json(JsonLibrary.Jackson);

        rest().tag("Post Customer Profile Verification")
                .description("Customer Profile verificationflag from Pharos")
                .post("{{app.context.cpi.verificationflag.post}}")
                .produces("application/json")
                .consumes("application/json")
                .type(UpdateVerificationFlagsRequestDto.class)
                .param().name("x-wu-externalRefId").type(RestParamType.header).dataType("string").description("External Ref Id.").required(true).endParam()
                .param().name("Authorization").type(RestParamType.header).dataType("string").description("AuthToken").required(true).endParam()
            	.param().name("x-api-key").type(RestParamType.header).dataType("string").description("API Key").required(true).endParam()
                .clientRequestValidation(true)
                .to("direct:route-cpi-profile-update-verification-input");
        
        from("direct:route-cpi-profile-update-verification-input")
    			.routeId("CPI_Profile_Verificationflag_01")
    			.setExchangePattern(ExchangePattern.InOut)
    			.unmarshal().json(JsonLibrary.Jackson, UpdateVerificationFlagsRequestDto.class)
    			.log("Request header info is   ${headers}")
    			.log(LoggingLevel.INFO, "${body}")
    			.to("direct:route-cpi-profile-update-verification"); 

	    from("direct:route-cpi-profile-update-verification")
		    	.streamCaching()
		    	.process(customerProfileUpdateVerificationFlagRequestProcessor)
		    	.marshal().json(JsonLibrary.Jackson)
		     	.log(LoggingLevel.INFO, "Request is routed to RAC for customer profile verificationflag request.")
		     	.to("{{app.cpi.interface.update.flag.service.url}}")
		     	.to("direct:route-cpi-profile-lookup-response");
	    
	    from("direct:route-cpi-profile-update-verification-response")
	    		.id("CPI_Profile_Verificationflag_02")
	    		.process(customerProfileUpdateVerificationFlagResponseProcessor).end();

        logger.info("RAC Customer Profile verificationflag router started.");
    }
}
