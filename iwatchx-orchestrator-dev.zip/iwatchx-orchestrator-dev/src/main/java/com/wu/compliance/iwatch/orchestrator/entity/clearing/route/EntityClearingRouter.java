package com.wu.compliance.iwatch.orchestrator.entity.clearing.route;

import com.westernunion.entityservice.EntityClearingRequest;
import com.wu.compliance.iwatch.microcommonapi.web.exception.XssDataException;
import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.common.XssDataExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.entity.clearing.processor.EntityClearingExceptionProcessor;
import com.wu.compliance.iwatch.orchestrator.entity.clearing.processor.EntityClearingRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.entity.clearing.processor.EntityClearingResponseProcessor;
import org.apache.camel.ExchangePattern;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.http.conn.HttpHostConnectException;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.concurrent.TimeoutException;

@Component
public class EntityClearingRouter extends RouteBuilder {

    private final EntityClearingRequestProcessor entityClearingRequestProcessor;

    private final EntityClearingResponseProcessor entityClearingResponseProcessor;

    private final EntityClearingExceptionProcessor entityClearingExceptionProcessor;

    private final SanitizationProcessor sanitizationProcessor;

    private final XssDataExceptionProcessor xssDataExceptionProcessor;

    public EntityClearingRouter(EntityClearingRequestProcessor entityClearingRequestProcessor,
                                EntityClearingResponseProcessor entityClearingResponseProcessor,
                                EntityClearingExceptionProcessor entityClearingExceptionProcessor,
                                SanitizationProcessor sanitizationProcessor, XssDataExceptionProcessor xssDataExceptionProcessor) {
        Objects.requireNonNull(entityClearingRequestProcessor, "entityClearingRequestProcessor is null");
        Objects.requireNonNull(entityClearingResponseProcessor, "entityClearingResponseProcessor is null");
        Objects.requireNonNull(entityClearingExceptionProcessor, "entityClearingExceptionProcessor is null");
        Objects.requireNonNull(sanitizationProcessor, "sanitizationProcessor is null");
        Objects.requireNonNull(xssDataExceptionProcessor, "xssDataExceptionProcessor is null");
        this.entityClearingRequestProcessor = entityClearingRequestProcessor;
        this.entityClearingResponseProcessor = entityClearingResponseProcessor;
        this.entityClearingExceptionProcessor = entityClearingExceptionProcessor;
        this.sanitizationProcessor = sanitizationProcessor;
        this.xssDataExceptionProcessor = xssDataExceptionProcessor;
    }

    @Override
    public void configure() {

        interceptSendToEndpoint("direct:process-entity-clearing-input")
                .process(sanitizationProcessor);

        onException(Exception.class)
                .handled(true)
                .process(entityClearingExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        onException(HttpHostConnectException.class, TimeoutException.class)
                .handled(true)
                .maximumRedeliveries("{{app.context.retry.count}}").redeliveryDelay("{{app.context.retry.delay}}")
                .retryAttemptedLogLevel(LoggingLevel.WARN)
                .process(entityClearingExceptionProcessor);

        onException(XssDataException.class)
                .handled(true)
                .process(xssDataExceptionProcessor)
                .marshal().json(JsonLibrary.Jackson);

        rest()
                .tag("Clear Entities")
                .description("Clear entity information from RTRA Hit DB")
                .post("{{app.context.entity.clearing.post}}")
                .consumes("application/text")
                .type(String.class)
                .to("direct:process-entity-clearing-input");

        from("direct:process-entity-clearing-input")
                .routeId("RT_entityclearing_01")
                .streamCaching()
                .unmarshal().json(JsonLibrary.Jackson, EntityClearingRequest.class)
                .process(entityClearingRequestProcessor)
                .setHeader(CxfConstants.OPERATION_NAME, constant("entityClearing"))
                .to("direct:call-entity-clearing");

        from("direct:call-entity-clearing")
                .log(LoggingLevel.INFO,"Clearing entities for reference number : ${body.referenceNumber}")
                .to(ExchangePattern.InOut, "cxf:bean:rtraEntityLookupCxfEndpoint")
                .process(entityClearingResponseProcessor)
                .marshal().json(JsonLibrary.Jackson);
    }

}