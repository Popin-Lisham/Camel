package com.wu.compliance.iwatch.orchestrator.cases.route;

import com.wu.compliance.iwatch.orchestrator.cases.processor.CaseRequestProcessor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

@SpringBootTest
class CaseRouterTest extends CamelTestSupport {
    @Autowired
    SpringCamelContext defaultContext;

    @Autowired
    ProducerTemplate template;

    @Autowired
    private CaseRequestProcessor caseRequestProcessor;

    @BeforeEach
    public void setUp() throws Exception {

        AdviceWithRouteBuilder mockAdvice = new AdviceWithRouteBuilder() {
            @Override
            public void configure() {
                replaceFromWith("direct:allCases");
                interceptSendToEndpoint("direct:allCases")
                        .process(caseRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .to("mock:caseResult");
                replaceFromWith("direct:kycCases");
                interceptSendToEndpoint("direct:kycCases")
                        .process(caseRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .to("mock:caseResultKyc");
                replaceFromWith("direct:casesWithTriggeringPurpose");
                interceptSendToEndpoint("direct:casesWithTriggeringPurpose")
                        .process(caseRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .to("mock:caseResultWithTriggeringPurpose");
            }
        };
        AdviceWith.adviceWith(defaultContext.getRouteDefinition("RT_Case_01"), defaultContext, mockAdvice);
    }

    @Test
    @DisplayName("given case payload when case routing should execute case router without any exception")
    void testCasesRouter_WhenReceiveMessage_ExecuteSuccessful() throws Exception {
        final File fileRequest = ResourceUtils.getFile("classpath:cases/validRequest.json");
        final File fileExpected = ResourceUtils.getFile("classpath:cases/validResponse.json");
        String caseJson = Files.readString(fileRequest.toPath());
        String resultCaseJson = Files.readString(fileExpected.toPath());

        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:caseResult", MockEndpoint.class);
        resultEndpoint.expectedBodiesReceived(resultCaseJson);
        resultEndpoint.expectedMessageCount(1);
        Map<String, Object> headers = new HashMap<>();
        headers.put("x-wu-tenantpid", "WU");
        headers.put("x-wu-tenantsid", "CMT");
        headers.put("x-wu-bizgrp", "GSI");
        headers.put("x-wu-invgrp", "INTR");
        template.sendBodyAndHeaders("direct:allCases", caseJson, headers);
        resultEndpoint.assertIsSatisfied();
    }

    @Test
    @DisplayName("given case payload when case routing should execute KYC case router without any exception")
    void testCasesRouterKyc_WhenReceiveMessage_ExecuteSuccessful() throws Exception {
        final File fileRequest = ResourceUtils.getFile("classpath:cases/validRequest.json");
        final File fileExpected = ResourceUtils.getFile("classpath:cases/validResponse.json");
        String caseJson = Files.readString(fileRequest.toPath());
        String resultCaseJson = Files.readString(fileExpected.toPath());

        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:caseResultKyc", MockEndpoint.class);
        resultEndpoint.expectedBodiesReceived(resultCaseJson);
        resultEndpoint.expectedMessageCount(1);
        Map<String, Object> headers = new HashMap<>();
        headers.put("x-wu-tenantpid", "WU");
        headers.put("x-wu-tenantsid", "CMT");
        headers.put("x-wu-bizgrp", "KYC");
        headers.put("x-wu-invgrp", "CDR");
        template.sendBodyAndHeaders("direct:kycCases", caseJson, headers);
        resultEndpoint.assertIsSatisfied();
    }

    @Test
    @DisplayName("given case payload with triggering values when case routing should execute case router without any exception")
    void testCasesRouterWithTriggering_WhenReceiveMessage_ExecuteSuccessful() throws Exception {
        final File fileRequest = ResourceUtils.getFile("classpath:cases/validRequestWithTriggering.json");
        final File fileExpected = ResourceUtils.getFile("classpath:cases/validResponseWithTriggering.json");
        String caseJson = Files.readString(fileRequest.toPath());
        String resultCaseJson = Files.readString(fileExpected.toPath());

        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:caseResultWithTriggeringPurpose", MockEndpoint.class);
        resultEndpoint.expectedBodiesReceived(resultCaseJson);
        resultEndpoint.expectedMessageCount(1);
        Map<String, Object> headers = new HashMap<>();
        headers.put("x-wu-tenantpid", "WU");
        headers.put("x-wu-tenantsid", "CMT");
        headers.put("x-wu-bizgrp", "GSI");
        headers.put("x-wu-invgrp", "Interdiction");
        template.sendBodyAndHeaders("direct:casesWithTriggeringPurpose", caseJson, headers);
        resultEndpoint.assertIsSatisfied();
    }
}
