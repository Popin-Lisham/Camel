package com.wu.compliance.iwatch.orchestrator.pacaselookup.route;

import com.wu.compliance.iwatch.microcommonapi.json.JacksonObjectWriter;
import com.wu.compliance.iwatch.microtestapi.provider.FileSource;
import com.wu.compliance.iwatch.orchestrator.pacaselookup.processor.PACaseLookupHeaderValidationProcessor;
import com.wu.compliance.iwatch.orchestrator.pacaselookup.processor.PACaseLookupRequestProcessor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.Map;

@SpringBootTest
class PACaseLookupRouterTest extends CamelTestSupport {
    @Autowired
    SpringCamelContext defaultContext;

    @Autowired
    ProducerTemplate template;

    @Autowired
    PACaseLookupRequestProcessor paCaseLookupRequestProcessor;

    @Autowired
    PACaseLookupHeaderValidationProcessor paCaseLookupHeaderValidationProcessor;

    JacksonObjectWriter jacksonObjectWriter;

    @BeforeEach
    public void setUp() throws Exception {
        AdviceWithRouteBuilder mockAdvice = new AdviceWithRouteBuilder() {
            @Override
            public void configure() {

                interceptSendToEndpoint("direct:pacaselookupRequest01")
                        .process(paCaseLookupRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .to("mock:externalServiceResult01");

                interceptSendToEndpoint("direct:pacaselookupRequest02")
                        .process(paCaseLookupRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .to("mock:externalServiceResult02");

            }
        };
        AdviceWith.adviceWith(defaultContext.getRouteDefinition("RT_PACaseLookup_01"), defaultContext, mockAdvice);
        jacksonObjectWriter = new JacksonObjectWriter();
    }

    @ParameterizedTest(name = "<...valid...json...>")
    @DisplayName("given valid CRN based profile attachment when pacaselookup routing should execute pacaselookup router without any exception")
    @FileSource(resources = "/pacaselookup/validRequest.json")
    void testPACaseLookupRouter_WhenReceiveMessage_ExecuteSuccessful(String validRequest) throws Exception {
        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:externalServiceResult01", MockEndpoint.class);
        resultEndpoint.expectedBodiesReceived(validRequest);
        resultEndpoint.expectedMessageCount(1);

        Map<String, Object> headers = new HashMap<>();
        headers.put("x-wu-tenantpid", "WU");
        headers.put("x-wu-tenantsid", "CMT");
        template.sendBodyAndHeaders("direct:pacaselookupRequest01", validRequest, headers);
        resultEndpoint.assertIsSatisfied();
    }

    @ParameterizedTest(name = "<...valid...json...>")
    @DisplayName("given valid CRN based profile attachment missing headers when pacaselookup routing should execute pacaselookup router throw bad exception")
    @FileSource(resources = "/pacaselookup/validRequest.json")
    public void testPACaseLookupRouter_WhenReceiveMessage_ThrowBadRequest(String validRequest) throws Exception {
        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:externalServiceResult02", MockEndpoint.class);
        resultEndpoint.expectedHeaderReceived("x-wu-tenantpid", "WU");
        resultEndpoint.expectedHeaderReceived("x-wu-tenantsid", "CMT");

        template.sendBodyAndHeaders("direct:pacaselookupRequest02", validRequest, null);
        resultEndpoint.assertIsNotSatisfied();
    }
}