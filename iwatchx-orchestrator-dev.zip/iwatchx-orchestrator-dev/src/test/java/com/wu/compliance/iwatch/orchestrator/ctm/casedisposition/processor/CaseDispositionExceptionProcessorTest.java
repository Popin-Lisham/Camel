package com.wu.compliance.iwatch.orchestrator.ctm.casedisposition.processor;

import com.example.xmlns._1482216288989.FaultErrorMessageV100;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.compliance.iwatch.orchestrator.common.ConnectionErrorHeader;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import wu.ei.cis.csc.core.gsi.xsd.wu.faulterrormessage_2016_12.FaultErrorMessage20161212;

import static org.junit.jupiter.api.Assertions.assertEquals;


class CaseDispositionExceptionProcessorTest extends CamelTestSupport {

    @Produce("direct:startExceptions")
    protected ProducerTemplate template;

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                FaultErrorMessage20161212 faultInfo = new FaultErrorMessage20161212();
                faultInfo.setErrorText("Error in Case Disposition decision request");

                onException(Exception.class)
                        .handled(true)
                        .process(new CaseDispositionExceptionProcessor(new ConnectionErrorHeader()));

                from("direct:caseDispositionRuntimeExceptionTest")
                        .to("mock:caseDispositionRuntimeExceptionResult")
                        .throwException(new RuntimeException("Runtime Exception"));

                from("direct:caseDispositionFaultExceptionTest")
                        .to("mock:caseDispositionFaultExceptionTestResult")
                        .throwException(new FaultErrorMessageV100("", faultInfo));

            }
        };
    }

    @Test
    @DisplayName("When exception occurs case disposition routing should give proper error result")
    public void testTriggerProcessor_RuntimeException_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:caseDispositionRuntimeExceptionResult");
        Exchange exchange = getMandatoryEndpoint("direct:caseDispositionRuntimeExceptionTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("exception test");
        ObjectMapper objectMapper = new ObjectMapper();
        FaultErrorMessage20161212 faultInfo = new FaultErrorMessage20161212();
        faultInfo.setErrorText("An error occurred while trying to access Tibco CSL CTM Service.");
        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("exception test");

        Exchange result = template.send("direct:caseDispositionRuntimeExceptionTest", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertEquals(objectMapper.writeValueAsString(result.getIn().getBody()), objectMapper.writeValueAsString(faultInfo));

    }

    @Test
    @DisplayName("When http exception occurs case disposition routing should give proper error result")
    public void testTriggerProcessor_HttpException_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:caseDispositionFaultExceptionTestResult");
        Exchange exchange = getMandatoryEndpoint("direct:caseDispositionFaultExceptionTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("Fault exception test");
        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("Fault exception test");

        ObjectMapper objectMapper = new ObjectMapper();
        FaultErrorMessage20161212 faultInfo = new FaultErrorMessage20161212();
        faultInfo.setErrorText("Error in Case Disposition decision request");

        Exchange result = template.send("direct:caseDispositionFaultExceptionTest", exchange);
        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertEquals(objectMapper.writeValueAsString(result.getIn().getBody()), objectMapper.writeValueAsString(faultInfo));

    }

}