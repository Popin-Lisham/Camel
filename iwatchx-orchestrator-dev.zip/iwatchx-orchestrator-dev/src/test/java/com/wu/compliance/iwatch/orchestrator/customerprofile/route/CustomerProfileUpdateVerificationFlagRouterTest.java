package com.wu.compliance.iwatch.orchestrator.customerprofile.route;

import com.wu.compliance.iwatch.orchestrator.customerprofile.processor.CustomerProfileUpdateVerificationFlagRequestProcessor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

;
@SpringBootTest
public class CustomerProfileUpdateVerificationFlagRouterTest extends CamelTestSupport {
	@Autowired
    SpringCamelContext defaultContext;

    @Autowired
    ProducerTemplate template;

    @Autowired
    CustomerProfileUpdateVerificationFlagRequestProcessor customerProfileUpdateVerificationFlagRequestProcessor;

    @BeforeEach
    public void setUp() throws Exception {

        AdviceWithRouteBuilder mockAdvice = new AdviceWithRouteBuilder() {
            @Override
            public void configure() {
                replaceFromWith("direct:cpiVerification");
                interceptSendToEndpoint("direct:cpiVerification")
                        .process(customerProfileUpdateVerificationFlagRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .to("mock:verificationResponse");
            }
        };
        AdviceWith.adviceWith(defaultContext.getRouteDefinition("CPI_Profile_Verificationflag_01"), defaultContext, mockAdvice);
    }

    @Test
    @Disabled
    @DisplayName("given customer verification payload when cpi verification routing should execute verification router without any exception")
    void testCustomerProfileUpdateVerificationFlagRouter_WhenReceiveMessage_ExecuteSuccessful() throws Exception {
        final File fileRequest = ResourceUtils.getFile("classpath:cpiinterface/custverificationrequest.json");
        final File fileExpected = ResourceUtils.getFile("classpath:cpiinterface/custverificationresponse.json");
        String caseJson = Files.readString(fileRequest.toPath());
        String resultCaseJson = Files.readString(fileExpected.toPath());

        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:verificationResponse", MockEndpoint.class);
        resultEndpoint.expectedBodiesReceived(resultCaseJson);
        resultEndpoint.expectedMessageCount(1);
        Map<String, Object> headers = new HashMap<>();
        headers.put("x-wu-tenantpid", "WU");
        headers.put("x-wu-tenantsid", "CMT");
        headers.put("x-wu-bizgrp", "BKYC");
        headers.put("x-wu-invgrp", "ONB");
        template.sendBodyAndHeaders("direct:cpiVerification", caseJson, headers);
        resultEndpoint.assertIsSatisfied();
    }
}
