package com.wu.compliance.iwatch.orchestrator.transaction.lookup.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.westernunion.transactionlookupservice.TransactionLookupWSFault;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.orchestrator.transaction.lookup.exception.TransactionDetailsNotFoundException;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TransactionDetailsNotFoundExceptionProcessorTest extends CamelTestSupport {
    @Produce("direct:startExceptions")
    protected ProducerTemplate template;

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                onException(TransactionDetailsNotFoundException.class)
                        .handled(true)
                        .process(new TransactionDetailsNotFoundExceptionProcessor());

                from("direct:txnLookupDataNotFoundExceptionTest")
                        .to("mock:txnLookupDataNotFoundExceptionResult")
                        .throwException(new TransactionDetailsNotFoundException());
            }
        };
    }

    @Test
    @DisplayName("When exception occurs transaction lookup routing should give proper error result")
    public void testTriggerProcessor_TxnLookupDataNotFound_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:txnLookupDataNotFoundExceptionResult");
        Exchange exchange = getMandatoryEndpoint("direct:txnLookupDataNotFoundExceptionTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("exception test");

        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("exception test");

        Exchange result = template.send("direct:txnLookupDataNotFoundExceptionTest", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.NOT_FOUND.value());
        assertEquals(((DefaultResponse)result.getIn().getBody()).getDescription(), "No data found from transaction lookup service");

    }
}
