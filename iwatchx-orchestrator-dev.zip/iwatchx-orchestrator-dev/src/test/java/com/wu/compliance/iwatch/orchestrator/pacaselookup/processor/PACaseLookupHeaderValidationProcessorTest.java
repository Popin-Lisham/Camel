package com.wu.compliance.iwatch.orchestrator.pacaselookup.processor;

import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.microcommonapi.dto.ErrorDetail;
import com.wu.compliance.iwatch.microcommonapi.json.JacksonObjectReader;
import com.wu.compliance.iwatch.microcommonapi.json.JacksonObjectWriter;
import com.wu.compliance.iwatch.microcommonapi.json.JsonMapper;
import com.wu.compliance.iwatch.microcommonapi.jsonschema.validation.JsonSchemaValidator;
import com.wu.compliance.iwatch.orchestrator.common.CommonHeaderValidator;
import com.wu.compliance.iwatch.orchestrator.common.CommonValidationException;
import com.wu.compliance.iwatch.orchestrator.common.InvalidHeaderProcessor;
import com.wu.compliance.iwatch.orchestrator.common.PACaseLookupHeaderSchema;
import com.wu.compliance.iwatch.orchestrator.dto.response.ResponseBuilder;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PACaseLookupHeaderValidationProcessorTest extends CamelTestSupport {

    JacksonObjectReader jacksonObjectReader = new JacksonObjectReader();
    JacksonObjectWriter jacksonObjectWriter = new JacksonObjectWriter();

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {

                onException(Exception.class)
                        .handled(true)
                        .process(new PACaseLookupExceptionProcessor());

                onException(CommonValidationException.class)
                        .handled(true)
                        .process(new InvalidHeaderProcessor());

                interceptSendToEndpoint("mock:headerMissingResult")
                        .process(paCaseLookupHeaderValidationProcessorInstance());

                from("direct:validateHeaderTest")
                        .to("mock:headerMissingResult");

            }
        };
    }

    private PACaseLookupHeaderValidationProcessor paCaseLookupHeaderValidationProcessorInstance() {
        CommonHeaderValidator commonHeaderValidator = new CommonHeaderValidator(new JsonSchemaValidator(new JsonMapper()), jacksonObjectWriter);
        return new PACaseLookupHeaderValidationProcessor(
                new PACaseLookupHeaderSchema(), commonHeaderValidator);
    }

    @Test
    @DisplayName("When header is missing will throw common validation exception and return bad error response")
    public void testHeaderValidation__shouldThrow_CommonValidationException() throws Exception {
        String uuid = UUID.randomUUID().toString();
        DefaultResponse expectedErrorResponse = ResponseBuilder.buildBadRequestResponse(uuid, List.of(
                new ErrorDetail("$.tenantpid", "$.tenantpid: null found, string expected"),
                new ErrorDetail("$.tenantsid", "$.tenantsid: null found, string expected")));

        Exchange exchange = getMandatoryEndpoint("direct:validateHeaderTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("validating common header");
        exchange.getIn().setHeader("x-wu-correlationId", uuid);
        exchange.getIn().setHeader("x-wu-userid", "1234");
        exchange.getIn().setHeader("x-wu-username", "test");
        exchange.getIn().setHeader("x-wu-useremail", "test@test.com");
        exchange.getIn().setHeader("CamelHttpResponseCode", 400);

        Exchange actualResult = template.send("direct:validateHeaderTest", exchange);

        assertEquals(HttpStatus.BAD_REQUEST.value(), actualResult.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE));
        assertEquals(jacksonObjectWriter.writeValueAsString(expectedErrorResponse), jacksonObjectWriter.writeValueAsString(actualResult.getIn().getBody()));
    }
}