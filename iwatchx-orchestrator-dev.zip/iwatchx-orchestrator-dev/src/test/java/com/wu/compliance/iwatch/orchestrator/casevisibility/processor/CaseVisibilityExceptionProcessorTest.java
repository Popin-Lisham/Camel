package com.wu.compliance.iwatch.orchestrator.casevisibility.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.microcommonapi.dto.ErrorDetail;
import com.wu.compliance.iwatch.orchestrator.common.CommonValidationException;
import com.wu.compliance.iwatch.orchestrator.common.InvalidHeaderProcessor;
import com.wu.compliance.iwatch.orchestrator.dto.response.ResponseBuilder;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.http.base.HttpOperationFailedException;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CaseVisibilityExceptionProcessorTest extends CamelTestSupport {
    @Produce("direct:startExceptions")
    protected ProducerTemplate template;

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                onException(Exception.class)
                        .handled(true)
                        .process(new CaseVisibilityExceptionProcessor());

                onException(CommonValidationException.class)
                        .handled(true)
                        .process(new InvalidHeaderProcessor());

                interceptSendToEndpoint("mock:badRequestCSVResult")
                        .throwException(new CommonValidationException(List.of(new ErrorDetail("tenantpid", "must not be blank")), ""));

                from("direct:cvsRuntimeExceptionTest")
                        .to("mock:cvsRuntimeExceptionResult")
                        .throwException(new RuntimeException("Runtime Exception"));

                from("direct:cvsHttpOperationFailedException_400_Test")
                        .to("mock:cvsHttpExceptionResult_400")
                        .throwException(new HttpOperationFailedException("",400,"","",null,"http exception test 400"));

                from("direct:cvsHttpOperationFailedException_404_Test")
                        .to("mock:cvsHttpExceptionResult_404")
                        .throwException(new HttpOperationFailedException("",404,"","",null,"http exception test 404"));

                from("direct:badRequestCSVResult")
                        .to("mock:badRequestCSVResult");

            }
        };
    }

    @Test
    @DisplayName("When exception occurs csv routing should give proper error result")
    public void testTriggerProcessor_RuntimeException_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:cvsRuntimeExceptionResult");
        Exchange exchange = getMandatoryEndpoint("direct:cvsRuntimeExceptionTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("exception test");
        exchange.getIn().setHeader("x-wu-correlationId", UUID.randomUUID().toString());
        ObjectMapper objectMapper = new ObjectMapper();
        DefaultResponse errorResponse = ResponseBuilder.buildUnknownErrorResponse(exchange.getIn().getHeader("x-wu-correlationId").toString(), "Runtime Exception");
        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("exception test");

        Exchange result = template.send("direct:cvsRuntimeExceptionTest", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertEquals(result.getIn().getBody(), objectMapper.writeValueAsString(errorResponse));

    }

    @Test
    @DisplayName("When http exception occurs csv routing should give proper error result")
    public void testTriggerProcessor_HttpException_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:cvsHttpExceptionResult_400");
        Exchange exchange = getMandatoryEndpoint("direct:cvsHttpOperationFailedException_400_Test").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("http exception test");
        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("http exception test");
        Exchange result = template.send("direct:cvsHttpOperationFailedException_400_Test", exchange);
        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.BAD_REQUEST.value());
        assertEquals(result.getIn().getBody(), "http exception test 400");

    }

    @Test
    @DisplayName("When http exception 404 occurs csv routing should give proper error result")
    public void testTriggerProcessor_HttpException_404_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:cvsHttpExceptionResult_404");
        Exchange exchange = getMandatoryEndpoint("direct:cvsHttpOperationFailedException_404_Test").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("http exception test");
        exchange.getIn().setHeader("x-wu-correlationId", UUID.randomUUID().toString());
        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("http exception test");

        DefaultResponse errorResponse = ResponseBuilder.buildUnknownErrorResponse(exchange.getIn().getHeader("x-wu-correlationId").toString(), "HTTP operation failed invoking  with statusCode: 404, redirectLocation: ");
        ObjectMapper objectMapper = new ObjectMapper();

        Exchange result = template.send("direct:cvsHttpOperationFailedException_404_Test", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertEquals(result.getIn().getBody(), objectMapper.writeValueAsString(errorResponse));

    }

    @Test
    @DisplayName("When predicate exception occurs csv routing should give proper error result")
    public void testTriggerProcessor_predicateException_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:badRequestCSVResult");

        ObjectMapper objectMapper = new ObjectMapper();

        Exchange exchange = getMandatoryEndpoint("direct:badRequestCSVResult").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("predicate exception test");
        exchange.getIn().setHeader("x-wu-correlationId", UUID.randomUUID().toString());
        exchange.getIn().setHeader("CamelHttpResponseCode", 400);

        DefaultResponse errorResponse = ResponseBuilder.buildBadRequestResponse((String) exchange.getIn().getHeader("x-wu-correlationId"), List.of(new ErrorDetail("tenantpid","must not be blank")));

        Exchange result = template.send("direct:badRequestCSVResult", exchange);

        resultEndpoint.assertIsSatisfied();

        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.BAD_REQUEST.value());
        assertEquals(objectMapper.writeValueAsString(result.getIn().getBody()), objectMapper.writeValueAsString(errorResponse));
    }

}