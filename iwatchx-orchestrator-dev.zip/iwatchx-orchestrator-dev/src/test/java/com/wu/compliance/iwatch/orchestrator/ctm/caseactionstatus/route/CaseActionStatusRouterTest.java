package com.wu.compliance.iwatch.orchestrator.ctm.caseactionstatus.route;

import com.wu.compliance.iwatch.orchestrator.ctm.caseactionstatus.CaseActionStatusRouter;
import com.wu.compliance.iwatch.orchestrator.ctm.caseactionstatus.processor.CaseActionStatusRequestProcessor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.spring.SpringCamelContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

@SpringBootTest
class CaseActionStatusRouterTest {
    @Autowired
    CaseActionStatusRouter caseActionStatusRouter;

    @Autowired
    SpringCamelContext defaultContext;

    @Autowired
    ProducerTemplate template;

    @Autowired
    private CaseActionStatusRequestProcessor caseActionStatusRequestProcessor;

    private String actionStatusJson;

    @BeforeEach
    public void setUp() throws Exception {
        final File file = ResourceUtils.getFile("classpath:ctm/caseactionstatus/validRequest.json");
        actionStatusJson = Files.readString(file.toPath());
        AdviceWithRouteBuilder mockAdvice = new AdviceWithRouteBuilder() {
            @Override
            public void configure() {
                replaceFromWith("direct:casestatus");
                interceptSendToEndpoint("direct:casestatus")
                        .process(caseActionStatusRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .to("mock:casestatusResult");
            }
        };
        AdviceWith.adviceWith(defaultContext.getRouteDefinition("CTM_Action_Status_01"), defaultContext, mockAdvice);
    }

    @Test
    @DisplayName("given case action status payload when action status routing should action status  profile router without any exception")
    void testActionStatus_WhenReceiveMessage_ExecuteSuccessful() throws Exception {
        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:casestatusResult", MockEndpoint.class);
        resultEndpoint.expectedBodiesReceived(actionStatusJson);
        resultEndpoint.expectedMessageCount(1);
        Map<String, Object> headers = new HashMap<>();
        headers.put("x-wu-tenantpid", "WU");
        headers.put("x-wu-tenantsid", "CMT");
        template.sendBodyAndHeaders("direct:casestatus", actionStatusJson, headers);
        resultEndpoint.assertIsSatisfied();
    }
}