package com.wu.compliance.iwatch.orchestrator.transaction.lookup.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.westernunion.compliancevalidationservice.Header;
import com.westernunion.transactionlookupservice.TransactionDetails;
import com.westernunion.transactionlookupservice.TransactionLookupWSResponse;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.orchestrator.transaction.lookup.exception.TransactionDetailsNotFoundException;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TransactionLookupResponseProcessorTest extends CamelTestSupport {
    @Produce("direct:startExceptions")
    protected ProducerTemplate template;

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                onException(TransactionDetailsNotFoundException.class)
                        .handled(true)
                        .process(new TransactionDetailsNotFoundExceptionProcessor());

                from("direct:txnLookupWSResponseTest")
                        .to("mock:txnLookupWSResponseResult")
                        .process(new TransactionLookupResponseProcessor());
            }
        };
    }

    @Test
    @DisplayName("When valid transaction lookup response received then routing should give proper success result")
    public void testTriggerProcessor_TxnResponseProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:txnLookupWSResponseResult");
        Exchange exchange = getMandatoryEndpoint("direct:txnLookupWSResponseTest").createExchange(ExchangePattern.InOut);

        ObjectMapper objectMapper = new ObjectMapper();

        Header header = new Header();
        header.setCorrelationId("MOCK_CORRELATION_ID");

        TransactionDetails transactionDetails = new TransactionDetails();
        transactionDetails.setMtcn("MOCK_MTCN");

        TransactionLookupWSResponse transactionLookupWSResponse = new TransactionLookupWSResponse();
        transactionLookupWSResponse.setResponseMessage("SUCCESS");
        transactionLookupWSResponse.setHeader(header);
        transactionLookupWSResponse.setTransactionDetails(transactionDetails);
        exchange.getIn().setBody(transactionLookupWSResponse);

        resultEndpoint.expectedMessageCount(1);

        Exchange result = template.send("direct:txnLookupWSResponseTest", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(objectMapper.writeValueAsString(result.getIn().getBody()), objectMapper.writeValueAsString(transactionLookupWSResponse));
    }

    @Test
    @DisplayName("When valid transaction lookup empty response received then routing should throw NoDataFound exception")
    public void testTriggerProcessor_TxnResponseProcessor_ThrowNoDataFoundException() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:txnLookupWSResponseResult");
        Exchange exchange = getMandatoryEndpoint("direct:txnLookupWSResponseTest").createExchange(ExchangePattern.InOut);

        Header header = new Header();
        header.setCorrelationId("MOCK_CORRELATION_ID");

        TransactionLookupWSResponse transactionLookupWSResponse = new TransactionLookupWSResponse();
        transactionLookupWSResponse.setResponseMessage("SUCCESS");
        transactionLookupWSResponse.setHeader(header);
        exchange.getIn().setBody(transactionLookupWSResponse);

        resultEndpoint.expectedMessageCount(1);

        Exchange result = template.send("direct:txnLookupWSResponseTest", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.NOT_FOUND.value());
        assertEquals(((DefaultResponse) result.getIn().getBody()).getDescription(), "No data found from transaction lookup service");
    }
}
