package com.wu.compliance.iwatch.orchestrator.transaction.lookup.route;

import com.westernunion.transactionlookupservice.TransactionLookupWSRequest;
import com.wu.compliance.iwatch.orchestrator.transaction.lookup.processor.TransactionLookupRequestProcessor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.nio.file.Files;


@SpringBootTest
class TransactionLookupRouterTest extends CamelTestSupport {

    @Autowired
    SpringCamelContext defaultContext;

    @Autowired
    ProducerTemplate template;

    @Autowired
    TransactionLookupRequestProcessor transactionLookupRequestProcessor;

    @BeforeEach
    public void setUp() throws Exception {

        AdviceWithRouteBuilder mockAdvice = new AdviceWithRouteBuilder() {
            @Override
            public void configure() {
                replaceFromWith("direct:transaction");
                interceptSendToEndpoint("direct:transaction")
                        .unmarshal().json(JsonLibrary.Jackson, TransactionLookupWSRequest.class)
                        .process(transactionLookupRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .marshal().json(JsonLibrary.Jackson)
                        .to("mock:transactionResult");
            }
        };
        AdviceWith.adviceWith(defaultContext.getRouteDefinition("RT_transaction_01"), defaultContext, mockAdvice);
    }

    @Test
    @DisplayName("given transaction lookup json payload when fetching transaction details should execute transaction router without any exception")
    void testTransactionRouter_WhenReceiveMessage_ExecuteSuccessful() throws Exception {
        final File fileRequest = ResourceUtils.getFile("classpath:transaction-lookup/validRequest.json");
        final File fileExpected = ResourceUtils.getFile("classpath:transaction-lookup/validResponse.json");

        String transactionLookupInput = Files.readString(fileRequest.toPath());
        String resultTranLookup = Files.readString(fileExpected.toPath());

        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:transactionResult", MockEndpoint.class);
        resultEndpoint.expectedBodiesReceived(resultTranLookup);
        resultEndpoint.expectedMessageCount(1);

        template.sendBody("direct:transaction", transactionLookupInput);
        resultEndpoint.assertIsSatisfied();
    }

}