package com.wu.compliance.iwatch.orchestrator.accountmanagement.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.orchestrator.dto.response.ResponseBuilder;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.http.base.HttpOperationFailedException;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CustomerOnboardingCaseResolutionExceptionProcessorTest extends CamelTestSupport {

    @Produce("direct:startExceptions")
    protected ProducerTemplate template;
    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {

                onException(Exception.class)
                        .handled(true)
                        .process(new CustomerOnboardingCaseResolutionExceptionProcessor());

                from("direct:runtimeExceptionTest")
                        .to("mock:runtimeExceptionResult")
                        .throwException(new RuntimeException("Runtime Exception"));

                from("direct:httpOperationFailedException_400_Test")
                        .to("mock:httpExceptionResult_400")
                        .throwException(new HttpOperationFailedException("",400,"","",null,"http exception test 400"));

                from("direct:httpOperationFailedException_404_Test")
                        .to("mock:httpExceptionResult_404")
                        .throwException(new HttpOperationFailedException("",404,"","",null,"http exception test 404"));

                from("direct:validateHeaderTest")
                        .to("mock:headerValidationExceptionResult");

            }
        };
    }
    @Test
    @DisplayName("When exception occurs cases routing should give proper error result")
    public void testTriggerProcessor_RuntimeException_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:runtimeExceptionResult");
        Exchange exchange = getMandatoryEndpoint("direct:runtimeExceptionTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("exception test");
        exchange.getIn().setHeader("x-wu-correlationId", UUID.randomUUID().toString());
        exchange.getIn().setHeader("CamelHttpResponseCode", "500");
        ObjectMapper objectMapper = new ObjectMapper();
        DefaultResponse errorResponse = ResponseBuilder.buildUnknownErrorResponse((String) exchange.getIn().getHeader("x-wu-correlationId"), "Runtime Exception");
        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("exception test");

        Exchange result = template.send("direct:runtimeExceptionTest", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertEquals(result.getIn().getBody(), objectMapper.writeValueAsString(errorResponse));

    }
    @Test
    @DisplayName("When http exception occurs cases routing should give proper error result")
    public void testTriggerProcessor_HttpException_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:httpExceptionResult_400");
        Exchange exchange = getMandatoryEndpoint("direct:httpOperationFailedException_400_Test").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("http exception test");
        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("http exception test");
        Exchange result = template.send("direct:httpOperationFailedException_400_Test", exchange);
        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.BAD_REQUEST.value());
        assertEquals(result.getIn().getBody(), "http exception test 400");

    }

    @Test
    @DisplayName("When http exception 404 occurs cases routing should give proper error result")
    public void testTriggerProcessor_HttpException_404_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:httpExceptionResult_404");
        Exchange exchange = getMandatoryEndpoint("direct:httpOperationFailedException_404_Test").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("http exception test");
        exchange.getIn().setHeader("x-wu-correlationId", UUID.randomUUID().toString());
        exchange.getIn().setHeader("CamelHttpResponseCode", "500");
        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("http exception test");

        DefaultResponse errorResponse = ResponseBuilder.buildUnknownErrorResponse((String) exchange.getIn().getHeader("x-wu-correlationId"), "HTTP operation failed invoking  with statusCode: 404, redirectLocation: ");
        ObjectMapper objectMapper = new ObjectMapper();

        Exchange result = template.send("direct:httpOperationFailedException_404_Test", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertEquals(result.getIn().getBody(), objectMapper.writeValueAsString(errorResponse));

    }

}