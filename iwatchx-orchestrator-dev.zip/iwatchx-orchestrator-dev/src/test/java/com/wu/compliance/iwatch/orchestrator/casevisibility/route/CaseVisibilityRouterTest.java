package com.wu.compliance.iwatch.orchestrator.casevisibility.route;

import com.wu.compliance.iwatch.orchestrator.casevisibility.processor.CaseVisibilityRequestProcessor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

@SpringBootTest
class CaseVisibilityRouterTest extends CamelTestSupport {
    @Autowired
    CaseVisibilityRequestProcessor caseVisibilityRequestProcessor;

    @Autowired
    ProducerTemplate template;

    @Autowired
    SpringCamelContext defaultContext;

    @BeforeEach
    public void setUp() throws Exception {

        AdviceWithRouteBuilder mockAdvice = new AdviceWithRouteBuilder() {
            @Override
            public void configure() {
                replaceFromWith("direct:allVisibilityCases");
                interceptSendToEndpoint("direct:allVisibilityCases")
                        .process(caseVisibilityRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .to("mock:caseVisibilityResult");
            }
        };
        AdviceWith.adviceWith(defaultContext.getRouteDefinition("RT_Visibility_01"), defaultContext, mockAdvice);
    }

    @Test
    @DisplayName("given case visibility payload when visibility routing should execute visibility router without any exception")
    void testCasesRouter_WhenReceiveMessage_ExecuteSuccessful() throws Exception {
        final File fileRequest = ResourceUtils.getFile("classpath:visibility/validRequest.json");
        String caseJson = Files.readString(fileRequest.toPath());
        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:caseVisibilityResult", MockEndpoint.class);
        resultEndpoint.expectedMessageCount(1);
        Map<String, Object> headers = new HashMap<>();
        headers.put("x-wu-tenantpid", "WU");
        headers.put("x-wu-tenantsid", "CMT");
        headers.put("x-wu-genre","CJ");
        template.sendBodyAndHeaders("direct:allVisibilityCases", caseJson, headers);
        resultEndpoint.assertIsSatisfied();
    }
}