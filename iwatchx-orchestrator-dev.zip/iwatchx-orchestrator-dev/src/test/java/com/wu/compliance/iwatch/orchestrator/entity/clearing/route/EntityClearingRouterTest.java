package com.wu.compliance.iwatch.orchestrator.entity.clearing.route;

import com.westernunion.entityservice.EntityClearingRequest;
import com.wu.compliance.iwatch.orchestrator.entity.clearing.processor.EntityClearingRequestProcessor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.nio.file.Files;

@SpringBootTest
class EntityClearingRouterTest extends CamelTestSupport {

    @Autowired
    SpringCamelContext defaultContext;

    @Autowired
    ProducerTemplate template;

    @Autowired
    EntityClearingRequestProcessor entityClearingRequestProcessor;

    @BeforeEach
    public void setUp() throws Exception {

        AdviceWithRouteBuilder mockAdvice = new AdviceWithRouteBuilder() {
            @Override
            public void configure() {
                replaceFromWith("direct:entity-clearing");
                interceptSendToEndpoint("direct:entity-clearing")
                        .unmarshal().json(JsonLibrary.Jackson, EntityClearingRequest.class)
                        .process(entityClearingRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .marshal().json(JsonLibrary.Jackson)
                        .to("mock:entityClearingResult");
            }
        };
        AdviceWith.adviceWith(defaultContext.getRouteDefinition("RT_entityclearing_01"), defaultContext, mockAdvice);
    }

    @Test
    @DisplayName("given entity clearing json payload when clearing entities should execute entity clearing router without any exception")
    void testEntityClearingRouter_WhenReceiveMessage_ExecuteSuccessful() throws Exception {
        final File fileRequest = ResourceUtils.getFile("classpath:entity-clearing/validRequest.json");
        final File fileExpected = ResourceUtils.getFile("classpath:entity-clearing/validResponse.json");

        String entityClearingInput = Files.readString(fileRequest.toPath());
        String resultEntityClearing = Files.readString(fileExpected.toPath());

        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:entityClearingResult", MockEndpoint.class);
        resultEndpoint.expectedBodiesReceived(resultEntityClearing);
        resultEndpoint.expectedMessageCount(1);

        template.sendBody("direct:entity-clearing", entityClearingInput);
        resultEndpoint.assertIsSatisfied();
    }
}