package com.wu.compliance.iwatch.orchestrator.ctm.casecomment.route;

import com.wu.compliance.iwatch.orchestrator.common.SanitizationProcessor;
import com.wu.compliance.iwatch.orchestrator.ctm.casecomment.processor.CaseCommentRequestProcessor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;
import wu.ei.cis.csc.core.gsi.xsd.gsi.addcommentsrequest_2016_12.AddCommentsRequest20161212;

import java.io.File;
import java.nio.file.Files;
@SpringBootTest
class CaseCommentRouterTest extends CamelTestSupport {
    @Autowired
    SpringCamelContext defaultContext;

    @Autowired
    ProducerTemplate template;

    @Autowired
    CaseCommentRequestProcessor caseCommentRequestProcessor;

    @Autowired
    SanitizationProcessor sanitizationProcessor;

    @BeforeEach
    public void setUp() throws Exception {

        AdviceWithRouteBuilder mockAdvice = new AdviceWithRouteBuilder() {
            @Override
            public void configure() {
                replaceFromWith("direct:case-Comment");
                interceptSendToEndpoint("direct:case-Comment")
                        .process(sanitizationProcessor)
                        .unmarshal().json(JsonLibrary.Jackson, AddCommentsRequest20161212.class)
                        .process(caseCommentRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .marshal().json(JsonLibrary.Jackson)
                        .to("mock:ctm-Result");
            }
        };
        AdviceWith.adviceWith(defaultContext.getRouteDefinition("CTM_CaseComment_01"), defaultContext, mockAdvice);
    }
    @Test
    @DisplayName("given case comment json payload when sending comments to ctm should execute case comments router without any exception")
    void testCaseCommentRouter_WhenReceiveMessage_ExecuteSuccessful() throws Exception {
        final File fileRequest = ResourceUtils.getFile("classpath:ctm/casecomment/validRequest.json");
        final File fileExpected = ResourceUtils.getFile("classpath:ctm/casecomment/validResponse.json");

        String caseCommentInput = Files.readString(fileRequest.toPath());
        String resultCtm = Files.readString(fileExpected.toPath());

        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:ctm-Result", MockEndpoint.class);
        resultEndpoint.expectedBodiesReceived(resultCtm);
        resultEndpoint.expectedMessageCount(1);

        template.sendBody("direct:case-Comment", caseCommentInput);
        resultEndpoint.assertIsSatisfied();
    }
}