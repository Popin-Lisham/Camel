package com.wu.compliance.iwatch.orchestrator.customerprofile.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.http.base.HttpOperationFailedException;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CustomerProfileResponseProcessorTest extends CamelTestSupport {
    @Produce("direct:startExceptions")
    protected ProducerTemplate template;

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                onException(Exception.class)
                        .handled(true)
                        .process(new CustomerProfileExceptionProcessor());

                from("direct:CustomerProfileResponseTest")
                        .to("mock:customerProfileResponseResult")
                        .process(new CustomerProfileResponseProcessor());
            }
        };
    }

    @Test
    @DisplayName("When valid Customer Profile lookup response received then routing should give proper success result")
    public void testTriggerProcessor_CustomerProfileResponseProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:customerProfileResponseResult");
        Exchange exchange = getMandatoryEndpoint("direct:CustomerProfileResponseTest").createExchange(ExchangePattern.InOut);

        ObjectMapper objectMapper = new ObjectMapper();

        Object customerProfileResponse = exchange.getIn().getBody(Object.class);
        exchange.getIn().setBody(customerProfileResponse);

        resultEndpoint.expectedMessageCount(1);

        Exchange result = template.send("direct:CustomerProfileResponseTest", exchange);

        resultEndpoint.assertIsSatisfied();
        //assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertEquals(result.getIn().getBody(), customerProfileResponse);
    }
}
