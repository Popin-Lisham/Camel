package com.wu.compliance.iwatch.orchestrator.entity.lookup.route;

import com.westernunion.entityservice.EntityDetailsRequest;
import com.wu.compliance.iwatch.orchestrator.entity.lookup.processor.EntityLookupRequestProcessor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.nio.file.Files;

@SpringBootTest
class EntityLookupRouterTest extends CamelTestSupport {

    @Autowired
    SpringCamelContext defaultContext;

    @Autowired
    ProducerTemplate template;

    @Autowired
    EntityLookupRequestProcessor entityLookupRequestProcessor;

    @BeforeEach
    public void setUp() throws Exception {

        AdviceWithRouteBuilder mockAdvice = new AdviceWithRouteBuilder() {
            @Override
            public void configure() {
                replaceFromWith("direct:entity");
                interceptSendToEndpoint("direct:entity")
                        .unmarshal().json(JsonLibrary.Jackson, EntityDetailsRequest.class)
                        .process(entityLookupRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .marshal().json(JsonLibrary.Jackson)
                        .to("mock:entityResult");
            }
        };
        AdviceWith.adviceWith(defaultContext.getRouteDefinition("RT_entity_01"), defaultContext, mockAdvice);
    }

    @Test
    @DisplayName("given entity lookup json payload when fetching entity details should execute entity router without any exception")
    void testEntityLookupRouter_WhenReceiveMessage_ExecuteSuccessful() throws Exception {
        final File fileRequest = ResourceUtils.getFile("classpath:entity-lookup/validRequest.json");
        final File fileExpected = ResourceUtils.getFile("classpath:entity-lookup/validResponse.json");

        String entityLookupInput = Files.readString(fileRequest.toPath());
        String resultEntityLookup = Files.readString(fileExpected.toPath());

        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:entityResult", MockEndpoint.class);
        resultEndpoint.expectedBodiesReceived(resultEntityLookup);
        resultEndpoint.expectedMessageCount(1);

        template.sendBody("direct:entity", entityLookupInput);
        resultEndpoint.assertIsSatisfied();
    }
}