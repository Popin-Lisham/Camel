package com.wu.compliance.iwatch.orchestrator.entity.lookup.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.westernunion.entityservice.EntityServiceFault;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.orchestrator.entity.lookup.exception.EntityDataNotFoundException;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class EntityDataNotFoundExceptionProcessorTest extends CamelTestSupport {
    @Produce("direct:startExceptions")
    protected ProducerTemplate template;

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                onException(EntityDataNotFoundException.class)
                        .handled(true)
                        .process(new EntityDataNotFoundExceptionProcessor());

                from("direct:entityLookupDataNotFoundExceptionTest")
                        .to("mock:entityLookupDataNotFoundExceptionResult")
                        .throwException(new EntityDataNotFoundException());
            }
        };
    }

    @Test
    @DisplayName("When exception occurs entity lookup routing should give proper error result")
    public void testTriggerProcessor_EntityLookupDataNotFound_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:entityLookupDataNotFoundExceptionResult");
        Exchange exchange = getMandatoryEndpoint("direct:entityLookupDataNotFoundExceptionTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("exception test");

        ObjectMapper objectMapper = new ObjectMapper();
        EntityServiceFault entityServiceFault = new EntityServiceFault();
        entityServiceFault.setErrorMessage("No data found from entity lookup service");

        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("exception test");

        Exchange result = template.send("direct:entityLookupDataNotFoundExceptionTest", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.NOT_FOUND.value());
        assertEquals(((DefaultResponse)result.getIn().getBody()).getDescription(), "No data found from entity lookup service");
    }
}
