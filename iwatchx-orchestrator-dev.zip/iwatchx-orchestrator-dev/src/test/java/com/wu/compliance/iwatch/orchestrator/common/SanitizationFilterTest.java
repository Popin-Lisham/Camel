package com.wu.compliance.iwatch.orchestrator.common;

import com.google.gson.Gson;
import com.wu.compliance.iwatch.orchestrator.common.Filter.SanitizationFilter;
import io.netty.handler.codec.http.HttpResponseStatus;
import org.apache.catalina.connector.RequestFacade;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletResponse;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.*;

public class SanitizationFilterTest {

    ServletRequest servletRequest;
    ServletResponse servletResponse;
    FilterChain filterChain;
    SanitizationFilter sanitizationFilter;

    @BeforeEach
    public void eachTestSetup() {
        servletRequest = mock(RequestFacade.class);
        servletResponse = mock(ServletResponse.class);
        filterChain = mock(FilterChain.class);
        sanitizationFilter = new SanitizationFilter(List.of("<a" ,"<script ","<script>"));
    }

    @Test
    @DisplayName("Given a request Uri Contains untrusted data then return Bad request response and should not continue with filter chain")
    void shouldReturnBadRequestWhenUriContainsUntrustedData() throws ServletException, IOException {

        MockHttpServletResponse httpResponse = new MockHttpServletResponse();
        when(((RequestFacade) servletRequest).getRequestURI()).thenReturn("/test/status<a ");

        sanitizationFilter.doFilter(servletRequest, httpResponse, filterChain);

        var responseObject = new Gson().fromJson(httpResponse.getContentAsString(), Map.class);

        assertThat(responseObject).isNotNull();
        assertThat(httpResponse.getStatus()).isEqualTo(HttpResponseStatus.BAD_REQUEST.code());
        assertThat(responseObject.get("description")).isEqualTo("Request was rejected because the URI contains untrusted data");

        verify(filterChain, times(0)).doFilter(servletRequest,httpResponse);
        verifyNoInteractions(filterChain);
    }

    @Test
    @DisplayName("Given a request Uri not Contains untrusted data then request should continue with next filter chain")
    void shouldContinueWithNextStepWhenUriNotContainsUntrustedData() throws ServletException, IOException {

        when(((RequestFacade) servletRequest).getRequestURI()).thenReturn("/test/status");

        sanitizationFilter.doFilter(servletRequest, servletResponse, filterChain);

        verify(filterChain, times(1)).doFilter(servletRequest,servletResponse);
        verifyNoInteractions(servletResponse);
    }



}
