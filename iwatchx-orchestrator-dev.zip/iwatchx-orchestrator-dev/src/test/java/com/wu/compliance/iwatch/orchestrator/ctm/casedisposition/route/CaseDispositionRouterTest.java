package com.wu.compliance.iwatch.orchestrator.ctm.casedisposition.route;

import com.wu.compliance.iwatch.orchestrator.ctm.casedisposition.processor.CaseDispositionRequestProcessor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;
import wu.ei.cis.csc.core.gsi.xsd.gsi.gsitxndecisionrequest_2016_12.GSITxnDecisionRequest20161212;

import java.io.File;
import java.nio.file.Files;

@SpringBootTest
class CaseDispositionRouterTest  extends CamelTestSupport {
    @Autowired
    SpringCamelContext defaultContext;

    @Autowired
    ProducerTemplate template;

    @Autowired
    CaseDispositionRequestProcessor caseDispositionRequestProcessor;

    @BeforeEach
    public void setUp() throws Exception {

        AdviceWithRouteBuilder mockAdvice = new AdviceWithRouteBuilder() {
            @Override
            public void configure() {
                replaceFromWith("direct:case-Disposition");
                interceptSendToEndpoint("direct:case-Disposition")
                        .unmarshal().json(JsonLibrary.Jackson, GSITxnDecisionRequest20161212.class)
                        .process(caseDispositionRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .marshal().json(JsonLibrary.Jackson)
                        .to("mock:ctmResult");
            }
        };
        AdviceWith.adviceWith(defaultContext.getRouteDefinition("CTM_Disposition_01"), defaultContext, mockAdvice);
    }
    @Test
    @DisplayName("given case disposition json payload when sending comments to ctm should execute case disposition router without any exception")
    void testCaseDispositionRouter_WhenReceiveMessage_ExecuteSuccessful() throws Exception {
        final File fileRequest = ResourceUtils.getFile("classpath:ctm/casedisposition/validRequest.json");
        final File fileExpected = ResourceUtils.getFile("classpath:ctm/casedisposition/validResponse.json");

        String caseDispositionInput = Files.readString(fileRequest.toPath());
        String resultCtm = Files.readString(fileExpected.toPath());

        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:ctmResult", MockEndpoint.class);

        resultEndpoint.expectedBodiesReceived(resultCtm);
        resultEndpoint.expectedMessageCount(1);

        template.sendBody("direct:case-Disposition", caseDispositionInput);
        resultEndpoint.assertIsSatisfied();

    }
}