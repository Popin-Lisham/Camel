package com.wu.compliance.iwatch.orchestrator.ctm.casecomment.processor;

import com.example.xmlns._1482216288989.FaultErrorMessageV100;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.compliance.iwatch.orchestrator.common.ConnectionErrorHeader;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import wu.ei.cis.csc.core.gsi.xsd.wu.faulterrormessage_2016_12.FaultErrorMessage20161212;

import static org.junit.jupiter.api.Assertions.assertEquals;


class CaseCommentExceptionProcessorTest extends CamelTestSupport {

    @Produce("direct:startExceptions")
    protected ProducerTemplate template;

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                FaultErrorMessage20161212 faultInfo = new FaultErrorMessage20161212();
                faultInfo.setErrorText("Error in ctm add comment request");

                onException(Exception.class)
                        .handled(true)
                        .process(new CaseCommentExceptionProcessor(new ConnectionErrorHeader()));

                from("direct:caseCommentRuntimeExceptionTest")
                        .to("mock:caseCommentRuntimeExceptionResult")
                        .throwException(new RuntimeException("Runtime Exception"));

                from("direct:caseCommentFaultExceptionTest")
                        .to("mock:caseCommentFaultExceptionTestResult")
                        .throwException(new FaultErrorMessageV100("", faultInfo));

            }
        };
    }

    @Test
    @DisplayName("When exception occurs case comment routing should give proper error result")
    public void testTriggerProcessor_RuntimeException_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:caseCommentRuntimeExceptionResult");
        Exchange exchange = getMandatoryEndpoint("direct:caseCommentRuntimeExceptionTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("exception test");
        ObjectMapper objectMapper = new ObjectMapper();
        FaultErrorMessage20161212 commentFault = new FaultErrorMessage20161212();
        commentFault.setErrorText("An error occurred while trying to access Tibco CSL CTM Service.");
        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("exception test");

        Exchange result = template.send("direct:caseCommentRuntimeExceptionTest", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertEquals(objectMapper.writeValueAsString(result.getIn().getBody()), objectMapper.writeValueAsString(commentFault));

    }

    @Test
    @DisplayName("When http exception occurs case comment routing should give proper error result")
    public void testTriggerProcessor_HttpException_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:caseCommentRuntimeExceptionResult");
        Exchange exchange = getMandatoryEndpoint("direct:caseCommentRuntimeExceptionTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("Fault exception test");
        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("Fault exception test");

        ObjectMapper objectMapper = new ObjectMapper();
        FaultErrorMessage20161212 faultInfo = new FaultErrorMessage20161212();
        faultInfo.setErrorText("An error occurred while trying to access Tibco CSL CTM Service.");

        Exchange result = template.send("direct:caseCommentRuntimeExceptionTest", exchange);
        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertEquals(objectMapper.writeValueAsString(result.getIn().getBody()), objectMapper.writeValueAsString(faultInfo));

    }

}