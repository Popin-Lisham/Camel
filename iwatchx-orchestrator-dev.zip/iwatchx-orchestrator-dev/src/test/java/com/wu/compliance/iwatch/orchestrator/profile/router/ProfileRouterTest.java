package com.wu.compliance.iwatch.orchestrator.profile.router;

import com.wu.compliance.iwatch.orchestrator.profile.processor.ProfileRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.profile.processor.ProfileResponseProcessor;
import com.wu.compliance.iwatch.orchestrator.profile.route.ProfileRouter;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

@SpringBootTest
class ProfileRouterTest extends CamelTestSupport {
    @Autowired
    ProfileRouter profileRouter;

    @Autowired
    SpringCamelContext defaultContext;

    @Autowired
    ProducerTemplate template;

    @Autowired
    private ProfileRequestProcessor profileRequestProcessor;

    @Autowired
    private ProfileResponseProcessor profileResponseProcessor;

    private String profileJson;

    @BeforeEach
    public void setUp() throws Exception {
        final File file = ResourceUtils.getFile("classpath:profile/validRequest.json");
        profileJson = Files.readString(file.toPath());
        AdviceWithRouteBuilder mockAdvice = new AdviceWithRouteBuilder() {
            @Override
            public void configure() {
                replaceFromWith("direct:allProfiles");
                interceptSendToEndpoint("direct:allProfiles")
                        .process(profileRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .to("mock:profileResult")
                        .process(profileResponseProcessor)
                        .marshal().json(JsonLibrary.Jackson);
            }
        };
        AdviceWith.adviceWith(defaultContext.getRouteDefinition("RT_Profile_01"), defaultContext, mockAdvice);
    }

    @Test
    @DisplayName("given profile payload when profile routing should execute profile router without any exception")
    void testProfileRouter_WhenReceiveMessage_ExecuteSuccessful() throws Exception {
        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:profileResult", MockEndpoint.class);
        resultEndpoint.expectedBodiesReceived(profileJson);
        resultEndpoint.expectedMessageCount(1);
        Map<String, Object> headers = new HashMap<>();
        headers.put("x-wu-tenantpid", "WU");
        headers.put("x-wu-tenantsid", "CMT");
        template.sendBodyAndHeaders("direct:allProfiles", profileJson, headers);
        resultEndpoint.assertIsSatisfied();
    }
}
