package com.wu.compliance.iwatch.orchestrator.entity.lookup.processor;

import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;

class EntityLookupExceptionProcessorTest extends CamelTestSupport {

    @Produce("direct:startExceptions")
    protected ProducerTemplate template;

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                onException(Exception.class)
                        .handled(true)
                        .process(new EntityLookupExceptionProcessor());

                from("direct:entityLookupRuntimeExceptionTest")
                        .to("mock:entityLookupRuntimeExceptionResult")
                        .throwException(new RuntimeException("Runtime Exception"));
            }
        };
    }

    @Test
    @DisplayName("When exception occurs entity lookup routing should give proper error result")
    public void testTriggerProcessor_RuntimeException_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:entityLookupRuntimeExceptionResult");
        Exchange exchange = getMandatoryEndpoint("direct:entityLookupRuntimeExceptionTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("exception test");

        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("exception test");

        Exchange result = template.send("direct:entityLookupRuntimeExceptionTest", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertEquals(((DefaultResponse) result.getIn().getBody()).getDescription(), "An error occurred while processing entity lookup request.");
    }
}