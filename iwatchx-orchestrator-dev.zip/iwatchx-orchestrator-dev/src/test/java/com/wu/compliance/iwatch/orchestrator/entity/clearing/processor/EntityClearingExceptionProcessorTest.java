package com.wu.compliance.iwatch.orchestrator.entity.clearing.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.westernunion.entityservice.EntityServiceFault;
import com.westernunion.entityservice.EntityServiceFaultException;
import com.wu.compliance.iwatch.orchestrator.entity.lookup.processor.EntityLookupExceptionProcessor;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;


class EntityClearingExceptionProcessorTest extends CamelTestSupport {

    @Produce("direct:startExceptions")
    protected ProducerTemplate template;

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                EntityServiceFault faultInfo = new EntityServiceFault();
                faultInfo.setErrorDescription("Test Fault Description");

                onException(Exception.class)
                        .handled(true)
                        .process(new EntityClearingExceptionProcessor());

                from("direct:entityClearingRuntimeExceptionTest")
                        .to("mock:entityClearingRuntimeExceptionResult")
                        .throwException(new RuntimeException("Runtime Exception"));

                from("direct:entityClearingFaultExceptionTest")
                        .to("mock:entityClearingFaultExceptionTestResult")
                        .throwException(new EntityServiceFaultException("", faultInfo));

            }
        };
    }

    @Test
    @DisplayName("When exception occurs at entity clearing route should give proper error result")
    void testTriggerProcessor_RuntimeException_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:entityClearingRuntimeExceptionResult");
        Exchange exchange = getMandatoryEndpoint("direct:entityClearingRuntimeExceptionTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("exception test");
        ObjectMapper objectMapper = new ObjectMapper();
        EntityServiceFault entityServiceFault = new EntityServiceFault();
        entityServiceFault.setErrorMessage("An error occurred while trying to access entity clearing service.");
        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("exception test");

        Exchange result = template.send("direct:entityClearingRuntimeExceptionTest", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertEquals(objectMapper.writeValueAsString(result.getIn().getBody()), objectMapper.writeValueAsString(entityServiceFault));

    }

    @Test
    @DisplayName("When http exception occurs at entity clearing route should give proper error result")
    void testTriggerProcessor_HttpException_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:entityClearingFaultExceptionTestResult");
        Exchange exchange = getMandatoryEndpoint("direct:entityClearingFaultExceptionTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("Fault exception test");
        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("Fault exception test");

        ObjectMapper objectMapper = new ObjectMapper();
        EntityServiceFault faultInfo = new EntityServiceFault();
        faultInfo.setErrorDescription("Test Fault Description");

        Exchange result = template.send("direct:entityClearingFaultExceptionTest", exchange);
        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertEquals(objectMapper.writeValueAsString(result.getIn().getBody()), objectMapper.writeValueAsString(faultInfo));

    }
}
