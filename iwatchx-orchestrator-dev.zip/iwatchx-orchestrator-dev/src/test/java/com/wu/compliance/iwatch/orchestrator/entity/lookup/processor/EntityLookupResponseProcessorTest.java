package com.wu.compliance.iwatch.orchestrator.entity.lookup.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.westernunion.entityservice.EntityDetailsResponse;
import com.westernunion.entityservice.EntityHits;
import com.westernunion.entityservice.Header;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.orchestrator.entity.lookup.exception.EntityDataNotFoundException;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class EntityLookupResponseProcessorTest extends CamelTestSupport {
    @Produce("direct:startExceptions")
    protected ProducerTemplate template;

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                onException(EntityDataNotFoundException.class)
                        .handled(true)
                        .process(new EntityDataNotFoundExceptionProcessor());

                from("direct:entityDetailsResponseTest")
                        .to("mock:entityDetailsResponseResult")
                        .process(new EntityLookupResponseProcessor());
            }
        };
    }

    @Test
    @DisplayName("When valid entity lookup response received then routing should give proper success result")
    public void testTriggerProcessor_EntityResponseProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:entityDetailsResponseResult");
        Exchange exchange = getMandatoryEndpoint("direct:entityDetailsResponseTest").createExchange(ExchangePattern.InOut);

        ObjectMapper objectMapper = new ObjectMapper();

        Header header = new Header();
        header.setCorrelationId("MOCK_CORRELATION_ID");

        EntityDetailsResponse entityDetailsResponse = new EntityDetailsResponse();
        entityDetailsResponse.setResponseMessage("SUCCESS");
        entityDetailsResponse.setHeader(header);
        entityDetailsResponse.setEntityHits(new EntityHits());
        exchange.getIn().setBody(entityDetailsResponse);

        resultEndpoint.expectedMessageCount(1);

        Exchange result = template.send("direct:entityDetailsResponseTest", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(objectMapper.writeValueAsString(result.getIn().getBody()), objectMapper.writeValueAsString(entityDetailsResponse));
    }

    @Test
    @DisplayName("When valid entity lookup empty response received then routing should throw NoDataFound exception")
    public void testTriggerProcessor_EntityResponseProcessor_ThrowNoDataFoundException() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:entityDetailsResponseResult");
        Exchange exchange = getMandatoryEndpoint("direct:entityDetailsResponseTest").createExchange(ExchangePattern.InOut);

        Header header = new Header();
        header.setCorrelationId("MOCK_CORRELATION_ID");

        EntityDetailsResponse entityDetailsResponse = new EntityDetailsResponse();
        entityDetailsResponse.setResponseMessage("SUCCESS");
        entityDetailsResponse.setHeader(header);
        exchange.getIn().setBody(entityDetailsResponse);

        resultEndpoint.expectedMessageCount(1);

        Exchange result = template.send("direct:entityDetailsResponseTest", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.NOT_FOUND.value());
        assertEquals(((DefaultResponse) result.getIn().getBody()).getDescription(), "No data found from entity lookup service");
    }
}
