package com.wu.compliance.iwatch.orchestrator.customerprofile.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.http.base.HttpOperationFailedException;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import static org.junit.jupiter.api.Assertions.assertEquals;

class CustomerProfileUpdateVerificationFlagRequestProcessorTest extends CamelTestSupport {
    @Produce("direct:startExceptions")
    protected ProducerTemplate template;

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                onException(Exception.class)
                        .handled(true)
                        .process(new CustomerProfileExceptionProcessor());

                from("direct:CustomerProfileUpdateVerificationFlagRequestTest")
                        .to("mock:CustomerProfileUpdateVerificationFlagRequestResult")
                        .process(new CustomerProfileUpdateVerificationFlagRequestProcessor());
            }
        };
    }

    @Test
    @DisplayName("When valid Customer Profile lookup response received then routing should give proper success result")
    public void testTriggerProcessor_CustomerProfileUpdateVerificationFlagRequest_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:CustomerProfileUpdateVerificationFlagRequestResult");
        Exchange exchange = getMandatoryEndpoint("direct:CustomerProfileUpdateVerificationFlagRequestTest").createExchange(ExchangePattern.InOut);

        ObjectMapper objectMapper = new ObjectMapper();

        String HTTP_URI_initial = (String)exchange.getIn().getHeader("CamelHttpUri");
        String HTTP_URI_removed = (String)exchange.getIn().removeHeader("CamelHttpUri");
        String HTTP_URI_after = (String)exchange.getIn().getHeader("CamelHttpUri");

        resultEndpoint.expectedMessageCount(1);

        Exchange result = template.send("direct:CustomerProfileUpdateVerificationFlagRequestTest", exchange);

        resultEndpoint.assertIsSatisfied();
        assertEquals(HTTP_URI_initial, HTTP_URI_removed);
        assertEquals(null, HTTP_URI_after);
    }
}