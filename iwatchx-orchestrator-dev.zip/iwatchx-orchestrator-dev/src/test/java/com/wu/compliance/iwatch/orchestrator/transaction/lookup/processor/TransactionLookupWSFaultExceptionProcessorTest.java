package com.wu.compliance.iwatch.orchestrator.transaction.lookup.processor;

import com.westernunion.transactionlookupservice.TransactionLookupWSFault;
import com.westernunion.transactionlookupservice.TransactionLookupWSFaultException;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.microcommonapi.json.JacksonObjectWriter;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TransactionLookupWSFaultExceptionProcessorTest extends CamelTestSupport {
    @Produce("direct:startExceptions")
    protected ProducerTemplate template;

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                TransactionLookupWSFault faultInfo = new TransactionLookupWSFault();
                faultInfo.setErrorCode("TEST_ERROR_CODE");
                faultInfo.setErrorMessage("SERVICE FAILED TO RESPOND. PLEASE TRY AGAIN");
                JacksonObjectWriter jacksonObjectWriter = new JacksonObjectWriter();

                onException(TransactionLookupWSFaultException.class)
                        .handled(true)
                        .process(new TransactionLookupWSFaultExceptionProcessor(jacksonObjectWriter));

                from("direct:txnLookupFaultExceptionTest")
                        .to("mock:txnLookupFaultExceptionTestResult")
                        .throwException(new TransactionLookupWSFaultException("Fault Exception", faultInfo));

            }
        };
    }

    @Test
    @DisplayName("When http exception occurs transaction lookup routing should give proper error result")
    public void testTriggerProcessor_TxnLookupFaultException_ExceptionProcessor_shouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:txnLookupFaultExceptionTestResult");
        Exchange exchange = getMandatoryEndpoint("direct:txnLookupFaultExceptionTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("Fault exception test");
        resultEndpoint.expectedMessageCount(1);
        resultEndpoint.expectedBodiesReceived("Fault exception test");

        Exchange result = template.send("direct:txnLookupFaultExceptionTest", exchange);
        resultEndpoint.assertIsSatisfied();
        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.SERVICE_UNAVAILABLE.value());
        assertEquals(((DefaultResponse) result.getIn().getBody()).getDescription(), "Fault received from transaction lookup Service : TEST_ERROR_CODE : SERVICE FAILED TO RESPOND. PLEASE TRY AGAIN");

    }
}
