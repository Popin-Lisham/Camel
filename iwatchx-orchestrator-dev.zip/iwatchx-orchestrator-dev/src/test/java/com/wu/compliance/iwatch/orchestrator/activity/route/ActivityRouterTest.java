package com.wu.compliance.iwatch.orchestrator.activity.route;


import com.wu.compliance.iwatch.orchestrator.activity.processor.ActivityRequestProcessor;
import com.wu.compliance.iwatch.orchestrator.activity.processor.ActivityResponseProcessor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

@SpringBootTest
public class ActivityRouterTest extends CamelTestSupport {
    @Autowired
    ActivityRouter activityRouter;

    @Autowired
    SpringCamelContext defaultContext;

    @Autowired
    ProducerTemplate template;

    @Autowired
    private ActivityRequestProcessor activityRequestProcessor;

    @Autowired
    private ActivityResponseProcessor activityResponseProcessor;

    private String activityJson;

    @BeforeEach
    public void setUp() throws Exception {
        final File file = ResourceUtils.getFile("classpath:activity/validRequest.json");
        activityJson = Files.readString(file.toPath());
        AdviceWithRouteBuilder mockAdvice = new AdviceWithRouteBuilder() {
            @Override
            public void configure() {
                replaceFromWith("direct:allActivity");
                interceptSendToEndpoint("direct:allActivity")
                        .process(activityRequestProcessor)
                        .skipSendToOriginalEndpoint()
                        .to("mock:activityResult")
                        .process(activityResponseProcessor)
                        .marshal().json(JsonLibrary.Jackson);
            }
        };
        AdviceWith.adviceWith(defaultContext.getRouteDefinition("RT_Activity_01"), defaultContext, mockAdvice);
    }

    @Test
    @DisplayName("given activity payload when activity routing should execute activity router without any exception")
    void testActivityRouter_WhenReceiveMessage_ExecuteSuccessful() throws Exception {
        MockEndpoint resultEndpoint = defaultContext.getEndpoint("mock:activityResult", MockEndpoint.class);
        resultEndpoint.expectedBodiesReceived(activityJson);
        resultEndpoint.expectedMessageCount(1);
        Map<String, Object> headers = new HashMap<>();
        headers.put("x-wu-tenantpid", "WU");
        headers.put("x-wu-tenantsid", "CMT");
        template.sendBodyAndHeaders("direct:allActivity", activityJson, headers);
        resultEndpoint.assertIsSatisfied();
    }
}
