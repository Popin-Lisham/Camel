package com.wu.compliance.iwatch.orchestrator.profile.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.microcommonapi.dto.ErrorDetail;
import com.wu.compliance.iwatch.orchestrator.common.CommonValidationException;
import com.wu.compliance.iwatch.orchestrator.common.InvalidHeaderProcessor;
import com.wu.compliance.iwatch.orchestrator.dto.response.ResponseBuilder;
import org.apache.camel.*;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ProfileProcessorTest extends CamelTestSupport {

    @EndpointInject("mock:result")
    protected MockEndpoint resultEndpoint;

    @Produce("direct:start")
    protected ProducerTemplate template;

    private String badProfileJson;

    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                onException(RuntimeException.class)
                        .handled(true)
                        .process(new ProfileExceptionProcessor());

                onException(CommonValidationException.class)
                        .handled(true)
                        .process(new InvalidHeaderProcessor());

                interceptSendToEndpoint("mock:badRequestResult")
                        .throwException(new CommonValidationException(List.of(new ErrorDetail("tenantpid", "must not be blank")), ""));

                from("direct:exceptionTest")
                        .to("mock:exceptionResult")
                        .throwException(new RuntimeException("Exception"));

                from("direct:badRequestTest")
                        .to("mock:badRequestResult");
            }
        };
    }

    @Test
    @DisplayName("Given profile payload when profile routing with runtime exception should execute profile exception processor logic")
    public void WhenRuntimeException_ProfileExceptionProcessor_ShouldExecute() throws Exception {
        MockEndpoint resultEndpoint = getMockEndpoint("mock:exceptionResult");
        Exchange exchange = getMandatoryEndpoint("direct:badRequestTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("exception test");
        exchange.getIn().setHeader("x-wu-correlationId", UUID.randomUUID().toString());

        resultEndpoint.expectedMessageCount(1);

        template.send("direct:exceptionTest", exchange);

        resultEndpoint.assertIsSatisfied();
    }

    @Test
    @DisplayName("Given profile payload when profile routing with empty headers should execute profile validation processor logic")
    public void WhenEmptyHeader_ProfileValidationProcessor_ShouldExecute() throws Exception {

        MockEndpoint resultEndpoint = getMockEndpoint("mock:badRequestResult");
        ObjectMapper objectMapper = new ObjectMapper();
        Exchange exchange = getMandatoryEndpoint("direct:badRequestTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody("predicate exception test");
        exchange.getIn().setHeader("x-wu-correlationId", UUID.randomUUID().toString());
        exchange.getIn().setHeader("CamelHttpResponseCode", 400);

        DefaultResponse errorResponse = ResponseBuilder.buildBadRequestResponse((String) exchange.getIn().getHeader("x-wu-correlationId"),List.of(new ErrorDetail("tenantpid","must not be blank")));

        Exchange result = template.send("direct:badRequestTest", exchange);

        resultEndpoint.assertIsSatisfied();

        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.BAD_REQUEST.value());
        assertEquals(objectMapper.writeValueAsString(result.getIn().getBody()), objectMapper.writeValueAsString(errorResponse));
    }
}
