package com.wu.compliance.iwatch.orchestrator.cases.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.orchestrator.dto.response.ResponseBuilder;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class CJCasesTypeErrorProcessorTest extends CamelTestSupport {

    @Produce("direct:startCaseTypeError")
    protected ProducerTemplate template;
    @Override
    protected RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {

                from("direct:caseTypeErrorTest")
                        .process(new CJCaseRequestProcessor())
                        .choice()
                        .when().simple("${header.classificationBusinessGroup} == 'KYC'")
                        .to("direct:error")
                        .end();

                from("direct:error")
                        .transform().constant("Not able to route as caseType.type value is unknown")
                        .process(new CJCaseTypeErrorProcessor())
                        .marshal().json(JsonLibrary.Jackson);


            }
        };
    }
    @Test
    @DisplayName("When exception occurs cases routing should give proper error result")
    public void testTriggerProcessor_RuntimeException_ExceptionProcessor_shouldExecute() throws Exception {
        final File fileRequest = ResourceUtils.getFile("classpath:cases/cjInvalidRequest.json");
        String caseJson = Files.readString(fileRequest.toPath());
        Exchange exchange = getMandatoryEndpoint("direct:caseTypeErrorTest").createExchange(ExchangePattern.InOut);
        exchange.getIn().setBody(caseJson);
        Map<String, Object> headers = new HashMap<>();
        headers.put("classificationBusinessGroup" , "KYC");
        exchange.getIn().setBody(caseJson);
        exchange.getIn().setHeaders(headers);
        ObjectMapper objectMapper = new ObjectMapper();
        DefaultResponse errorResponse = ResponseBuilder.buildUnknownErrorResponse("dummyTraceId", "Not able to route as caseType.type value is unknown");

        Exchange result = template.send("direct:caseTypeErrorTest", exchange);

        assertEquals(result.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE), HttpStatus.BAD_REQUEST.value());
        //assertEquals(objectMapper.writeValueAsString(result.getIn().getBody()), objectMapper.writeValueAsString(errorResponse));

    }
}
