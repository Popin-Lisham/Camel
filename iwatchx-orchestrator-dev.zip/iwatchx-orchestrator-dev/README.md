## Orchestrator Service

A Orchestration layer acts as an interface between iWatchX and all the other external applications. It provides routing capabilities for different services and connectors for event sourcing.

[![Quality Gate Status](https://sonarqube.sharedservices.awswuintranet.net/api/project_badges/measure?project=com.wu.compliance.iwatch%3Aiwatchx-orchestrator&metric=alert_status)](https://sonarqube.sharedservices.awswuintranet.net/dashboard?id=com.wu.compliance.iwatch%3Aiwatchx-orchestrator)
[![Maintainability Rating](https://sonarqube.sharedservices.awswuintranet.net/api/project_badges/measure?project=com.wu.compliance.iwatch%3Aiwatchx-orchestrator&metric=sqale_rating)](https://sonarqube.sharedservices.awswuintranet.net/dashboard?id=com.wu.compliance.iwatch%3Aiwatchx-orchestrator)
[![Bugs](https://sonarqube.sharedservices.awswuintranet.net/api/project_badges/measure?project=com.wu.compliance.iwatch%3Aiwatchx-orchestrator&metric=bugs)](https://sonarqube.sharedservices.awswuintranet.net/dashboard?id=com.wu.compliance.iwatch%3Aiwatchx-orchestrator)
[![Code Smells](https://sonarqube.sharedservices.awswuintranet.net/api/project_badges/measure?project=com.wu.compliance.iwatch%3Aiwatchx-orchestrator&metric=code_smells)](https://sonarqube.sharedservices.awswuintranet.net/dashboard?id=com.wu.compliance.iwatch%3Aiwatchx-orchestrator)
[![Coverage](https://sonarqube.sharedservices.awswuintranet.net/api/project_badges/measure?project=com.wu.compliance.iwatch%3Aiwatchx-orchestrator&metric=coverage)](https://sonarqube.sharedservices.awswuintranet.net/dashboard?id=com.wu.compliance.iwatch%3Aiwatchx-orchestrator)
[![Lines of Code](https://sonarqube.sharedservices.awswuintranet.net/api/project_badges/measure?project=com.wu.compliance.iwatch%3Aiwatchx-orchestrator&metric=ncloc)](https://sonarqube.sharedservices.awswuintranet.net/dashboard?id=com.wu.compliance.iwatch%3Aiwatchx-orchestrator)

[[Build Details]](https://jenkins.sharedservices.awswuintranet.net/job/Compliance-CMP/job/iWatchX/view/PROD/job/PROD/job/iWatchX-Orchestrator/)
[[Artifact Details]](https://artifactory.wuintranet.net/artifactory/webapp/#/artifacts/browse/tree/General/oneplatform-docker/wu/service/iwatchx-modernization/iwatchx-orchestrator)

## Flow

External Application outside Pharos calls the orchestrator service . Orchestrator service then routes the request to specific Pharos Microservices and sends the output to external applications and vice versa.

Swagger-url: `https://pharos.dev.compliancenonprod.awswuintranet.net:8086/swagger-ui.html#/`

## API Endpoints 

**1. PUT : `{{host:port}}/v1/iwx/cj/gateway/activities/{activityRefId}/status`**

API for fetching the status of the cases using activityRefId as follows :

**API Input**

```json
{
    "activityRefId": "2121888600187267",
    "activityType": "Remitance KDF1"
}
```

**Output**

Response for valid activityRefId and activityType :

```json
[
    {
        "caseId": "GSI::a823ea81-b743-4070-b851-a3229a70dd6c",
        "caseRefNo": "CC21CN0806OT",
        "caseType": "GSI",
        "status": {
            "phase": "Standard Investigation",
            "stage": "Concluded",
            "subprocess": "",
            "id": "SI.CON.CC",
            "modifiedTimestamp": "2021-08-06T11:47:46.827Z"
        },
        "disposition": {
            "action": "Return Funds",
            "reason": "Interdiction Match (INT)",
            "value": "Declined"
        },
        "subject": {
            "id": "3000000000011105703",
            "name": "KCGFST UTASVRL"
        },
        "caseCreatedDate": "2021-08-06T11:40:35.070947Z"
    },
    {
        "caseId": "GSI::617ef777-74b6-45cf-8b29-6ac01594e3a3",
        "caseRefNo": "CC21CN0809PH",
        "caseType": "GSI",
        "status": {
            "phase": "Standard Investigation",
            "stage": "Concluded",
            "subprocess": "",
            "id": "SI.CON.CC",
            "modifiedTimestamp": "2021-08-09T07:17:39.914Z"
        },
        "disposition": {
            "action": null,
            "reason": "Case Not Applicable (CNA)",
            "value": "Not Set"
        },
        "subject": {
            "id": "3000000000011105703",
            "name": "KCGFST UTASVRL"
        },
        "caseCreatedDate": "2021-08-09T06:47:30.696829Z"
    }
]
```

**2. GET: `{{host:port}}/v1/iwx/cj/gateway/cases/{caseId}/status`**

API for fetching the status of the case as follows :

**Output**

Response for valid caseId :

```json
{
    "caseId": "GSI::a823ea81-b743-4070-b851-a3229a70dd6c",
    "caseRefNo": "CC21CN0806OT",
    "caseType": "GSI",
    "status": {
        "phase": "Standard Investigation",
        "stage": "Concluded",
        "subprocess": "",
        "id": "SI.CON.CC",
        "modifiedTimestamp": "2021-08-06T11:47:46.827Z"
    },
    "disposition": {
        "action": "Return Funds",
        "reason": "Interdiction Match (INT)",
        "value": "Declined"
    },
    "subject": {
        "id": "3000000000011105703",
        "name": "KCGFST UTASVRL"
    },
    "caseCreatedDate": "2021-08-06T11:40:35.070947Z"
}
```

**3. POST: `{{host:port}}/v1/iwx/cj/gateway/ctm/comment`**

API for sending the case comment to CTM as follows : 

**API Input**
```json
{
    "brand": "WU",
    "comments20131215": {
        "line1": "iWatchX GSI GSI::09643e5a-7b29-460e-85e6-9a0f04ec6949 with Ref# 12345",
        "line2": "created on 2020-10-14T06:20:51.230511Z for S"
    },
    "iwatchCaseID": "1232313AAAA",
    "iwatchUserName": "test",
    "longMTCN": "1234567891234567",
    "channel20161212": {
        "applicationName": "IWATCH",
        "channelName": "IWATCH",
        "channelType": "CSC",
        "channelVersion": "4990"
    }
}
```

**Output**

Response from the CTM :

```json
{
    "longMTCN": "1234567891234567",
    "channel20161212": {
        "applicationName": "IWATCH",
        "channelName": "IWATCH",
        "channelType": "CSC",
        "channelVersion": "4910"
    },
    "error20161212": {
        "advisoryText": null,
        "errorText": "U2540 - SYSTEM ERROR - PLEASE RETRANSMIT",
        "exceptionMessage": null,
        "functionCode": null,
        "replyCode": "100",
        "requestBuffer": null,
        "responseBuffer": null,
        "translatedDASErrorText": null
    },
    "iwatchCaseID": "1232313AAAA",
    "iwatchUserName": "test"
}
```

**4. POST : `{{host:port}}/v1/iwx/cj/gateway/cases`**

API for creating the cases as follows :

**API Input**
```json
{
    "activityType": {
        "id": "1",
        "value": "Remitance KDF1"
    },
    "subject": {
        "id": "3000000000010887980",
        "type": "consumer"
    },
    "actTimestamp": "2021-06-29-00:11",
    "activityRefNo": "2118285092672010",
    "attemptId": "3400000000007561912",
    "tranSurKey": "5000000000636547496",
    "transactionSide": "S",
    "hitSide": "S"
}
```

**Output**

Response for successfully published case creation message to the queue.

```json
{
    "traceId": "123",
    "code": "WUIWXCJIS2000",
    "description": null,
    "message": {
        "title": "iWatchX",
        "text": "Case creation message successfully published to the queue."
    },
    "errorDetails": null
}
```

**5. POST : `{{host:port}}/v1/iwx/cj/gateway/entities/clearing`**

API for clearing the entity information as follows: 

**API Input**
```json
{
    "header": {
        "source": "Pharos",
        "correlationId": "testCorrelationId_2024888300342596",
        "timestamp": "2021-03-31T09:00:00.000Z"
    },
    "versionNumber": "",
    "clientId": "",
    "clientPwd": "",
    "galacticId": "3000000000009188699",
    "txnSide": "S",
    "referenceNumber": "2024888300342596",
    "referenceType": "MTCN",
    "lstClearedEntities": {
        "clrEntity": [
            {
                "entityType": "SENDER",
                "entityIds": {
                    "entityId": [
                        "3005002081"
                    ]
                }
            }
        ]
    },
    "siteId": "IWATCH",
    "userId": "iwx",
    "userName": "System"
}
```

**Output**

Response for successfully whitelisted entities :

```json
{
    "header": {
        "source": "Pharos",
        "appName": null,
        "hostName": null,
        "timestamp": 1617181200000,
        "correlationId": "testCorrelationId_2024888300342596",
        "transactionId": null
    },
    "versionNumber": "2.0",
    "clientId": "IWATCH",
    "status": "SUCCESS",
    "responseMessage": "ENTITIES WHITELISTED SUCCESSFULLY"
}
```

**6. POST : `{{host:port}}/v1/iwx/cj/gateway/ctm/disposition`**

API for sending case disposition action to CTM as follows: 

**API Input**
```json
{
    "brand": "WU",
    "comments20131215": {
        "line1": "iWatchX GSI GSI::09643e5a-7b29-460e-85e6-9a0f04ec6949 with Ref# 12345",
        "line2": "created on 2020-10-14T06:20:51.230511Z for S"
    },
    "iwatchCaseID": "1232313AAAA",
    "iwatchUserName": "NA",
    "longMTCN": "1234567891234567",
    "paymentType": "C",
    "callBackFlag": "Y",
    "decision": "RTQ",
    "queueName": "BRIDFAC",
    "reasonDescription": "RTQ",
    "channel20161212": {
        "applicationName": "IWATCH",
        "channelName": "IWATCH",
        "channelType": "CSC",
        "channelVersion": "4990"
    }
}
```

**Output**

Response for successfully sent case disposition action to CTM :

```json
{
    "brand": null,
    "callBackFlag": "Y",
    "decision": "RTQ",
    "investigativeGroupType": null,
    "longMTCN": "1234567891234567",
    "pinNumber": null,
    "queueName": "BRIDFAC",
    "channel20161212": {
        "applicationName": "IWATCH",
        "channelName": "IWATCH",
        "channelType": "CSC",
        "channelVersion": "4990"
    },
    "error20161212": {
        "advisoryText": null,
        "errorText": null,
        "exceptionMessage": null,
        "functionCode": null,
        "replyCode": "1",
        "requestBuffer": null,
        "responseBuffer": null,
        "translatedDASErrorText": null
    },
    "iwatchCaseID": "1232313AAAA",
    "iwatchUserName": "NA"
}
```

**7. POST : `{{host:port}}/v1/iwx/cj/gateway/profileattachments`**

API for sending profile attachment information to queue listener as follows: 

**API Input**
```json
{
    "subject": {
        "id": "[SML]3000000000010111077",
        "type": "Customer"
    },
    "caseId": "R20061750892363",
    "customerId": "837A49113",
    "docRefNum": "CHIDA0C0AE32FDA222",
    "name": "PASSPORT.jpeg",
    "size": "173KB",
    "mime": "image/jpeg",
    "type": "PASSPORT",
    "subtype": "Personal Identity",
    "validation": {
        "status": "FAILED",
        "reason": "Unable to read image data"
    },
    "source": "WUPOS",
    "ocr": {
        "id": "DAS421958",
        "issuingCountry": "DE",
        "expDate": "01.07.2014",
        "issueDate": "01.07.2009",
        "dob": "12.08.1964",
        "pob": "BERLIN",
        "nameOnId": "PAUL ADRIAN RAICU",
        "issuingAuthority": "DE"
    }
}
```

**Output**

Response for iWatch queue listener :

```json
{
    "traceId": "123",
    "code": "WUIWXORCH2000",
    "description": "",
    "message": {
        "title": "iWatchX",
        "text": "Message successfully published to the queue."
    },
    "errorDetails": null
}
```

**8. POST : `{{host:port}}/v1/iwx/cj/gateway/activity/status`**

API for sending activity status information as follows:

**API Input**

```json
{
    "TRNS_SUR_KEY": "147896325",
    "MTCN16": "1234567812345675",
    "MTCN": "316236",
    "TRNS_TS": "2020-12-01 10:30:57.000",
    "ATTEMPTID": "testAttemptId",
    "QUEUE_NAME": "BRIDFAC3",
    "TRANSACTIONSTATE": "PAID",
    "SEND_UPDATE_TIMESTAMP": "2020-12-01 10:30:57.000",
    "PAY_UPDATE_TIMESTAMP": "2020-12-01 10:30:57.000",
    "GSI_CASE_CREATED": "Y",
    "STATUS": "PFC",
    "ATTEMPT_TIMESTAMP": "2020-12-01 10:40:57.000"
}
```
**Output**

Response for successfully published activity status in the iWatch queue:

```json
{
    "traceId": "123",
    "code": "WUIWXORCH2000",
    "description": "",
    "message": {
        "title": "iWatchX",
        "text": "Message successfully published to the queue."
    },
    "errorDetails": null
}
```

**9. POST : `{{host:port}}/v1/iwx/cj/gateway/activities`**

API for fetching transaction information from RTRA as follows:

**API Input**

```json
{
    "header": {
        "source": "iWatch Interim Service",
        "correlationId": "2018281792238006"
    },
    "txnMtcn": "2118285092672010",
    "txnAttemptID": "3400000000007561912",
    "txnSurKey": "5000000000636547496",
    "txnSide": "S"
}
```

**Output**

Response for successfully fetched transaction details :

```json
{
    "header": {
        "source": "iWatch Interim Service",
        "appName": null,
        "hostName": null,
        "timestamp": null,
        "correlationId": "2018281792238006",
        "transactionId": null,
        "locale": null
    },
    "versionNumber": "4.0",
    "partnerId": "IWATCH",
    "transactionDetails": {
        "mtcn": "5092672010",
        "transactionDate": "2021-07-01 08:33:12.32",
        "agentCountryName": "MYS",
        "occupation": "AIRLINE/MARITIME EMPLOYEE",
        "tpOccupation": "",
        "purposeOfTransaction": "",
        "attemptId": "3400000000007561912",
        "transactionType": "10",
        "transactionSurrKey": "5000000000636547496",
        "sendCountry": "MALAYSIA",
        "payCountry": "MALAYSIA",
        "relationShip": "FAMILY",
        "tpRelationShip": "",
        "parish": "",
        "tpParish": "",
        "organization": "",
        "tpOrganization": "",
        "otherOccupation": "",
        "product": "CC",
        "amountUSD": "484.8484",
        "usCharges": "1260.60584",
        "moneyTransferType": "WMN",
        "combinedLocalCharges": "5200.0",
        "localCharges": "5200",
        "deliveryServiceCharge": "0",
        "agentAccountNumber": "AZD010302",
        "recordingChannel": "AG",
        "intendedPayChannel": "AG",
        "payIn": "CA",
        "sendBrand": "WU",
        "payBrand": "",
        "speedOfDelivery": "00",
        "wuInterface": "CC",
        "intendedPayOut": "CA",
        "sendConsumerInfo": "",
        "payConsumerInfo": "",
        "sendDeviceId": "",
        "payDeviceId": "",
        "additionalTxnFields": null,
        "consumers": {
            "consumerEntry": [
                {
                    "consumerType": "CREDIT",
                    "consumer": {
                        "name": null,
                        "firstName": null,
                        "lastName": null,
                        "nameType": null,
                        "galacticID": null,
                        "address": null,
                        "dob": null,
                        "email": null,
                        "idType": null,
                        "phoneNo": null,
                        "cntryOfBirth": null,
                        "nationality": null,
                        "city": null,
                        "stateProvince": null,
                        "postalCode": null,
                        "gender": null,
                        "cityOfBirth": null,
                        "idNumber": null,
                        "idIssuer": null,
                        "idIssuingCountry": null,
                        "idExpDate": null,
                        "idIssuingAgency": null,
                        "idIssueDate": null,
                        "ccName": "",
                        "ccNumber": "",
                        "ccExpDate": "",
                        "corpTaxNum": null,
                        "otherOccupation": null,
                        "zip": null,
                        "remarks": null,
                        "ssntxid": null,
                        "wuCardNumber": null,
                        "smsFlag": null,
                        "additionalConsumerFields": null,
                        "idTypeNormCode": null,
                        "secondIdTypeNormCode": null,
                        "country": null,
                        "addressLine2": null,
                        "2NdIdNumber": null,
                        "2NdIdIssuer": null,
                        "2NdIdType": null,
                        "2NdIdExpDate": null,
                        "2NdIdIssueDate": null,
                        "2NdIdIssuingAgency": null,
                        "2NdIdIssuingCountry": null
                    }
                }
            ]
        },
        "sendingAgentState": "W P  KUALA LUMPUR",
        "expectedPayoutState": "CA",
        "recordingDate": "2021-07-01 08:33:12.32",
        "expectedPayoutCountry": "MYS",
        "amountLocal": "2000",
        "sendCountryCode": "MYS",
        "payCountryCode": "MYS",
        "agentAccountnumberSend": "AZD010302",
        "agentAccountnumberPay": null,
        "agentCountryCodePay": null,
        "payingAgentState": null,
        "roundedAmount": "4.85"
    },
    "responseMessage": null
}
```

**10. POST : `{{host:port}}/v1/iwx/cj/gateway/entities`**

API for fetching entity information from RTRA as follows:

**API Input**

```json
{
    "header": {
        "source": "iWatch Interim Service",
        "correlationId": "2018281792238006"
    },
    "referenceNumber": "2018281792238006",
    "txnAttemptID": "3400000000004703621",
    "txnSurKey": "5000000000527383492",
    "txnSide": "S"
}
```

**Output**

Response for successfully retrieved entity information :

```json
{
    "header": {
        "source": "iWatch Interim Service",
        "appName": null,
        "hostName": null,
        "timestamp": null,
        "correlationId": "2018281792238006",
        "transactionId": null
    },
    "versionNumber": "2.0",
    "clientId": "IWATCH",
    "entityHits": {
        "entityHitsEntry": [
            {
                "entityType": "SENDER",
                "nameTypeCode": null,
                "nameIdentifier": null,
                "entityEntry": [
                    {
                        "listType": "PFC",
                        "entity": [
                            {
                                "entityId": "3100001626",
                                "entityName": "SANNIDHI SRI",
                                "entityCategory": "1",
                                "nameMatchType": "GNR",
                                "nameMatchPercent": "100",
                                "entityMessage1": "<CAT 1> RFS & RFD TXN",
                                "markers": "<GID:Y><COUNTRY:MYS><STATE:KEDAH>",
                                "address1": "ADDRESS /ADDRESS City: ALOR SETAR",
                                "dob": "P:10/11/1993",
                                "phone": "607894561230",
                                "idNumber": "ID-A:ASD111/ID-PAS:ASD111/ID-PAS:ASD111",
                                "city": "ALOR SETAR",
                                "source": "WU",
                                "univSpecId": "NA",
                                "additionalComments": null,
                                "countryName": null,
                                "pepEntityLevel": null,
                                "isTrueMatch": null,
                                "mtcn": null,
                                "attemptId": null,
                                "sourceCode": "WU"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "responseMessage": null,
    "hasMore": false,
    "paginationIndex": "",
    "entityType": null
}
```

**11. POST : `{{host:port}}/v1/iwx/cj/gateway/ctm/acknowledge`**

API for sending the CTM Acknowledgement as follows :

**API Input**

```json
{
    "queueName": "WU",
    "caseId": "GSI::2700ff78-55bc-4580-977e-791e08fe22b8",
    "response": {
        "code": "SUCCESS",
        "description": ""
    },
    "refId": "2105584020669076",
    "decision": "REL",
    "userName": "TIBCO",
    "reInstatedRefId": "2105584020669076"
}
```

**Output**

Response for successfully sent case disposition request :

```json
{
    "traceId": "123",
    "code": "WUIWXCAI2000",
    "description": "Case disposition action request has been successfully processed.",
    "message": {
        "title": "Pharos",
        "text": "Success"
    },
    "errorDetails": null
}
```

**12. POST : `{{host:port}}/v1/iwx/cj/gateway/cases/profileattachments`**
    
API for saving profile attachment details as follows :

**API Input**

```json
{
    "caseRefNo": "CC21CO0816MZ",
    "customerId": "CC21CO0816MZ",
    "docRefNum": "OTXXXXCC407276748AE1",
    "name": "CC21CO0816MZ",
    "size": "173KB",
    "mime": "image/jpeg",
    "type": "ov",
    "subType": "Personal Identity",
    "validation": {
        "status": "pass",
        "refId": "12345",
        "reason": {
            "code": "000",
            "description": "000"
        }
    },
    "verification": {
        "status": "pass",
        "refId": "12345",
        "reason": {
            "code": "000",
            "description": "000"
        }
    },
    "source": "opendut",
    "ocr": {
        "issuingCountry": "DE",
        "expDate": "01.07.2014",
        "issueDate": "01.07.2009",
        "dob": "12.08.1964",
        "pob": "BERLIN",
        "nameOnId": "CC21AW0318GA",
        "issuingAuthority": "DE"
    }
}
```

**Output**

Response when profile attachment details saved successfully :

```json
{
    "traceId": "123",
    "code": "WUIWXPACL2000",
    "description": "Profile attachment message successfully published to the queue.",
    "message": {
        "title": "Pharos",
        "text": "Success"
    },
    "errorDetails": null
}
```


## Setup Steps in Local

1. Clone git repository: https://gitlab.wuintranet.net/iWatch-modernization/iwatchx-orchestrator
2. Your local system should have below Software installed:
    ```
    i) Git for Windows (for version control)
    ii) Intellij IDEA
    iii) JDK 11 and above for Java
   ```
3. Import cloned project in IDE.
4. Open `Edit Configurations` from `Run` menu and under `Environment variables` tab add below properties:

    ```
   CONJUR_AUTHN_LOGIN=host/CMTCMPL_SB_Local;CONJUR_AUTHN_API_KEY=3xjq80b1kqyn2nwrtv1a2wppez31yh22g71e16y0m141mb1x17e04zs
    ```
   
5. Follow below steps for running the application locally :
    1. Keep application.properties file blank.
    2. Replace the following line in the bootstrap.properties file :
        
        ```   
        spring.cloud.config.uri=http://ecsdemo-lb-config-nserver-97f237b91d6d7f01.elb.us-east-1.amazonaws.com/     
        ```
       
6. Run the main application file from IDE with this settings.
 
 
## Event codes

Event codes will be returned from specific Microservice.


## Interaction with other systems

### RTRA 

Orchestrator calls RTRA for Transaction lookup, Entity Lookup and Entity clearing services.

### iWatch

iWatch calls Orchestrator to create cases in the Pharos.

### CTM

Orchestrator calls CTM for sending the notifications, comments and action status.

### RabbitMQ

The Orchestrator sends the activity status change request and Profile Attachment metadata message to RabbitMQ.

### Interim Service 

Orchestrator sends the case creation request to Interim service also Interim service in turn calls transaction & entity lookup services via Orchestrator. 

### Compliance Visibility Service

Orchestrator calls Visibility Service and the response of Visibility Service is reached to CTM via Orchestrator.

## Testing 

Testing service details would be captured from ‘test’ project which uses following files for its respective route.
   1. validResponse.json
   2. validRequest.json


